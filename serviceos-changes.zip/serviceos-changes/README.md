# serviceos-changes — BOS Mobile + BOS Web Production Optimization (Phases 0–5)

Cumulative, production-ready changes targeting **`bosmobile/` (the BOS mobile app)**,
**BOS web (`src/components/bos/`)** and the shared commerce backend — on top of
`origin/main @ 492816d4`, delivered as 5 commits.

> This build supersedes the previous serviceos-changes.zip whose mobile layer had
> mistakenly targeted `bgosmobile/` (the growth-suite companion app). bgosmobile is
> untouched here except two lint/typecheck hygiene fixes.

## What's inside
| Entry | Purpose |
|---|---|
| `serviceos.patch` | Single cumulative patch (`git apply`) covering the full changeset |
| `files/` | Post-change copies of every touched file (overlay onto repo root) |
| `manifest.json` | Commit list, changed/deleted/renamed paths, stats |

## Commits included
1. `4295f7cb` fix(security): production integrity hardening — Phase 0
2. `ac49f70a` feat(bos): Vyapar-parity web polish — Phase 1
3. `7f6e79f8` feat(mobile): BOS money layer — invoice detail, partial payments, banks & cheques, Vyapar filters — Phase 2
4. `ca368387` feat(bos): growth-suite parity — marketing gallery, GBP/WhatsApp integration panels, online-store checklist — Phase 3
5. `f7229ba7` feat(web): UX system pass — honest stats, date filters, empty CTAs — Phase 4

## How to apply
**Option A — patch (recommended):**
```bash
git apply --check serviceos.patch   # dry-run against 492816d4
git apply serviceos.patch
git add -A && git commit -m "feat: BOS mobile + web production optimization (Phases 0-5)"
```

**Option B — file overlay:**
```bash
cp -r files/* /path/to/repo/
# Then remove the 3 deleted files manually (see manifest.json "deleted"):
git rm src/app/api/seed-demo/route.ts src/app/api/seed-missing-data/route.ts src/app/api/seed-whatsapp-crm/route.ts
```

**After applying:**
```bash
bun install && bunx prisma generate && bunx prisma db push
node scripts/backfill-invoice-payments.mjs   # one-time backfill of invoice payment status
cd bosmobile && bun run typecheck            # should be clean
cd .. && bun run lint                        # 0 errors
```

## Key changes by phase
- **Phase 0 — Security & data integrity:** 3 unauthenticated seed routes deleted,
  `seed-abc-plumbing` moved under superadmin, `demo-login` fail-closed; Airwallex
  provider fail-closed (no mock success); `AiCustomer.gstin` + `AiInvoiceItem.gstRate`
  columns (fixes the GST-invoice 500); analytics de-hardcoded; CRM invoice PATCH
  recalculates totals server-side; `/api/invoices/[id]/payments` (CRM family);
  payments backfill script.
- **Phase 1 — BOS web Vyapar parity:** `/api/commerce/banks` + `/api/commerce/cheques`
  (+`[id]`) endpoints; BOS web Cheque Register / Bank Accounts / Cash-in-Hand on real
  persistence (fixtures deleted); invoice list stats header + date-range chips;
  CSV export; illustrated empty states with CTAs; per-line TAX columns.
- **Phase 2 — bosmobile money layer (the corrected target):**
  - New invoice detail screen (`app/invoice/[id]`): status pipeline (DRAFT→SENT),
    line items with per-line GST, payment history, PDF/print/WhatsApp share.
  - Partial payments: new `PaymentSheet` + `POST/GET /api/commerce/invoices/[id]/payments`
    (honest PARTIALLY_PAID→PAID transitions, overpay guard, reference idempotency).
  - Vyapar Sale-Invoices header: Total Sales / Received / Balance KPIs over the
    filtered period + period chips + custom date-range sheet.
  - Per-line GST % input in the create form; place-of-supply IGST routing
    (B2C without GSTIN defaults to CGST+SGST — fixed a misclassification bug).
  - New Banks (Cash & Bank accounts) + Cheque Register screens; More-hub entries.
  - Reports: custom date range via `period=custom&customStart&customEnd`.
  - Shared money kit: KpiTile/KpiRow, FilterChips, DateRangeSheet (pure-RN calendar,
    zero native deps), PaymentSheet; `src/lib/money.ts` (en-IN formatting, GST split,
    stable invoice URLs).
  - GST PDF helper: per-line rates, IGST table variant, real Balance Due (was total),
    UPI QR amount = balance due.
  - Fake data removed: bookings hardcoded EVENT_TYPES, engage share URL,
    gptform.com links, Google sign-in user/tenant fabrication (honest failure).
- **Phase 3 — Growth hub parity:** Google Business Profile manager card, marketing
  poster gallery with chips, WhatsApp connect wizard card, online-store checklist.
- **Phase 4 — UX system pass:** honest stats everywhere, date filters, empty-state CTAs,
  data-table empty CTA, skeleton/loading states.

## Verification performed
- `bun run lint`: 0 errors (121 pre-existing warnings).
- `bosmobile` + `bgosmobile` `tsc --noEmit`: clean.
- API-verified on a seeded sandbox: GST invoice POST with customer GSTIN (was a 500),
  per-line gstRate persisted, partial payment flows (partial → duplicate no-op →
  settle → PAID → history), banks (masked numbers) & cheques (global summary) endpoints.
- Browser-verified: login → BOS web invoices workstation (Vyapar split preview,
  stats header, real invoice list) → Day Book Cheques & Bank Register rendering the
  real persisted cheque.

## Notes
- `prisma/schema.prisma` targets **PostgreSQL** (provider unchanged) — run
  `bunx prisma db push` after applying.
- `src/app/api/seed-abc-plumbing/route.ts` renamed to
  `src/app/api/superadmin/seed-abc-plumbing/route.ts` (superadmin-gated).
- bgosmobile receives only `images.d.ts` + an asset-import hygiene fix (no features —
  the money layer belongs to bosmobile).
