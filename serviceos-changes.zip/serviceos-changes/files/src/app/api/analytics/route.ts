import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { cache } from '@/lib/cache'

// GET /api/analytics - Get analytics data
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    // ─── Auth ────────────────────────────────────────────────────
    const authUser = await getAuthUser()
    if (!authUser) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }
    const { searchParams } = new URL(request.url)
    const metric = searchParams.get('metric') || 'overview'
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const range = searchParams.get('range') || '30d'
    const groupBy = searchParams.get('groupBy') || 'day'

    // Build date filters from explicit dates or range shorthand
    const dateFilter: Record<string, unknown> = {}
    if (startDate) {
      dateFilter.gte = new Date(startDate)
    } else if (range && range !== 'all') {
      const now = new Date()
      if (range === 'today' || range === '1d') {
        dateFilter.gte = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0)
      } else if (range === 'month' || range === 'this_month') {
        dateFilter.gte = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0)
      } else if (range === 'year' || range === 'this_year') {
        dateFilter.gte = new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0)
      } else {
        const rangeDays: Record<string, number> = { '7d': 7, '30d': 30, '90d': 90, '1y': 365, '12m': 365 }
        const days = rangeDays[range] || 30
        dateFilter.gte = new Date(now.getTime() - days * 24 * 60 * 60 * 1000)
      }
    }
    if (endDate) {
      dateFilter.lte = new Date(endDate)
    }

    // ─── Tenant scoping (mirrors /api/deals pattern) ──────────────
    // The caller's tenantId is the source of truth — never show cross-
    // tenant analytics. Super-admins may pass ?tenantId= to scope to a
    // specific tenant. Authenticated users without a tenant get a
    // never-match filter so every aggregate returns zero (preserves the
    // response shape per metric without leaking other tenants' data).
    let tenantFilter: Record<string, unknown>
    if (authUser.isSuperAdmin) {
      const queryTenantId = searchParams.get('tenantId')
      tenantFilter = queryTenantId ? { tenantId: queryTenantId } : {}
    } else if (authUser.tenantId) {
      tenantFilter = { tenantId: authUser.tenantId }
    } else {
      tenantFilter = { tenantId: '__NO_TENANT__' }
    }

    // ─── Resolve tenantId → workspaceIds ─────────────────────────────
    // Job and Employee have NO `tenantId` column (only `workspaceId`).
    // Spreading `{ tenantId }` into a Job/Employee query throws
    // "Unknown argument `tenantId`" → 500 → entire handler returns
    // { error: 'Internal server error' }. To fix this we resolve the
    // tenant's Workspaces ONCE here and pass a separate `workspaceFilter`
    // into each handler, then use it for Job/Employee queries.
    //
    // Pattern mirrors `/api/dashboard/bootstrap/route.ts` lines 138-144.
    let workspaceIds: string[] = []
    const tenantIdForLookup = typeof tenantFilter.tenantId === 'string' ? tenantFilter.tenantId : null
    if (tenantIdForLookup) {
      try {
        const tenantWorkspaces = await db.workspace.findMany({
          where: { tenantId: tenantIdForLookup },
          select: { id: true },
        })
        workspaceIds = tenantWorkspaces.map((w: { id: string }) => w.id)
      } catch (err) {
        console.error('[analytics] workspace.findMany failed:', err)
      }
    }
    // Filter used for Job and Employee queries. If the tenant has no
    // Workspaces registered, `{ id: '__NO_WORKSPACE__' }` is a never-match
    // sentinel (preserves the response shape — handlers still get arrays/zeros).
    const workspaceFilter: Record<string, unknown> =
      workspaceIds.length > 0
        ? { workspaceId: { in: workspaceIds } }
        : { id: '__NO_WORKSPACE__' }

    // PERF-P3: Server-side in-memory cache (60s TTL). The reports view fires
    // 6-7 analytics queries on mount, and each handler runs multiple Prisma
    // aggregates. Without caching, every tab switch or date-range change
    // triggers a full re-computation. The cache key is scoped by tenant +
    // metric + date params so different tenants/users never share cached data.
    // 60s is the right balance: the frontend staleTime is 30s, so by the time
    // React Query refetches, the server cache may still be warm (saving the
    // DB round-trip) but isn't stale enough to show outdated dashboards.
    const cacheKey = `analytics:${tenantIdForLookup || 'none'}:${metric}:${range}:${startDate || ''}:${endDate || ''}:${groupBy}`
    const cached = cache.get<unknown>(cacheKey)
    if (cached) {
      return NextResponse.json(cached)
    }

    // Route to different metric handlers
    let result: NextResponse
    switch (metric) {
      case 'revenue_trends':
        result = await handleRevenueTrends(dateFilter, tenantFilter, workspaceFilter, groupBy)
        break
      case 'job_stats':
        result = await handleJobStats(dateFilter, tenantFilter, workspaceFilter)
        break
      case 'employee_productivity':
        result = await handleEmployeeProductivity(dateFilter, tenantFilter, workspaceFilter)
        break
      case 'lead_conversion':
        result = await handleLeadConversion(dateFilter, tenantFilter)
        break
      case 'whatsapp_analytics':
        result = await handleWhatsAppAnalytics(dateFilter, tenantFilter)
        break
      case 'journey_analytics':
        result = await handleJourneyAnalytics(dateFilter, tenantFilter)
        break
      case 'overview':
      default:
        result = await handleOverview(dateFilter, tenantFilter, workspaceFilter)
        break
    }

    // Cache the response for 60 seconds. The handlers return NextResponse
    // objects — we cache the JSON body so the cache is transport-agnostic.
    // Extract the JSON body before caching.
    if (result instanceof NextResponse) {
      try {
        const body = await result.clone().json()
        cache.set(cacheKey, body, 60_000)
      } catch {
        // If we can't extract the body (e.g. it's a stream), skip caching.
      }
    }

    return result
  } catch (error) {
    console.error('Error fetching analytics:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

/**
 * Overview: aggregate counts and key metrics
 */
async function handleOverview(
  dateFilter: Record<string, unknown>,
  tenantFilter: Record<string, unknown>,
  workspaceFilter: Record<string, unknown>
) {
  // ─── Per-query isolation ───────────────────────────────────────────
  // Mirror the bootstrap pattern: each query is wrapped so a single
  // failure (e.g. Supabase adapter missing `_sum` in groupBy) doesn't
  // kill the entire Overview response. Errors are logged with the
  // query name so they surface in dev.log.
  const safe = async <T>(name: string, q: Promise<T>, fallback: T): Promise<T> => {
    try { return await q } catch (err) { console.error(`[analytics/overview] query "${name}" failed:`, err); return fallback }
  }

  const [
    totalJobs,
    completedJobs,
    activeLeads,
    totalRevenue,
    totalCustomers,
    totalEmployees,
    recentJobs,
  ] = await Promise.all([
    // Job has only `workspaceId` (no `tenantId`) → must use workspaceFilter.
    safe('job.count', db.job.count({ where: { ...workspaceFilter, ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}) } }), 0),
    safe('job.count.completed', db.job.count({ where: { ...workspaceFilter, status: 'completed', ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}) } }), 0),
    // Lead has `tenantId` → use tenantFilter.
    safe('lead.count.active', db.lead.count({ where: { ...tenantFilter, status: { in: ['new', 'contacted', 'qualified'] } } }), 0),
    safe('invoice.aggregate.paid', db.invoice.aggregate({
      where: { ...tenantFilter, status: 'paid', ...(Object.keys(dateFilter).length ? { paidAt: dateFilter } : {}) },
      _sum: { total: true },
    }), { _sum: { total: 0 } as { _sum: { total: number | null } } }),
    // Customer has BOTH tenantId and workspaceId; tenantId is canonical.
    // (Previously this used `tenantFilter.workspaceId` which was always
    // undefined → returned `{}` → leaked ALL customers across tenants.)
    safe('customer.count', db.customer.count({ where: { ...tenantFilter, ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}) } }), 0),
    // Employee has only `workspaceId` (no `tenantId`) → must use workspaceFilter.
    // (Previously this had NO `where` clause at all → returned a GLOBAL count
    // across ALL tenants — a cross-tenant data leak. The "129 team members"
    // symptom was this count being global.)
    safe('employee.count', db.employee.count({ where: workspaceFilter }), 0),
    safe('job.findMany.recent', db.job.findMany({
      where: { ...workspaceFilter, ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}) },
      take: 10,
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, status: true, customerName: true, createdAt: true },
    }), [] as { id: string; title: string; status: string; customerName: string | null; createdAt: Date | string }[]),
  ])

  return NextResponse.json({
    metric: 'overview',
    totalJobs,
    completedJobs,
    activeLeads,
    // Defensive access — adapter may drop `_sum`.
    totalRevenue: totalRevenue._sum?.total ?? 0,
    totalCustomers,
    totalEmployees,
    completionRate: totalJobs > 0 ? Math.round((completedJobs / totalJobs) * 100) : 0,
    recentJobs,
  })
}

/**
 * Revenue trends: revenue data grouped by time period
 */
async function handleRevenueTrends(
  dateFilter: Record<string, unknown>,
  tenantFilter: Record<string, unknown>,
  _workspaceFilter: Record<string, unknown>,
  groupBy: string
) {
  // Try to get data from AnalyticsSnapshot first
  const snapshots = await db.analyticsSnapshot.findMany({
    where: {
      metric: 'revenue',
      ...tenantFilter,
      ...(Object.keys(dateFilter).length ? { date: dateFilter } : {}),
    },
    orderBy: { date: 'asc' },
  })

  if (snapshots.length > 0) {
    return NextResponse.json({
      metric: 'revenue_trends',
      groupBy,
      data: snapshots.map(s => ({
        date: s.date,
        value: s.value,
        dimensions: JSON.parse(s.dimensionsJson || '{}'),
      })),
    })
  }

  // Fallback: compute from invoices (Invoice has `tenantId` → tenantFilter is correct)
  const invoices = await db.invoice.findMany({
    where: {
      status: 'paid',
      ...tenantFilter,
      ...(Object.keys(dateFilter).length ? { paidAt: dateFilter } : {}),
    },
    orderBy: { paidAt: 'asc' },
    select: { total: true, paidAt: true },
  })

  // Group by date
  const grouped = new Map<string, number>()
  for (const inv of invoices) {
    if (!inv.paidAt) continue
    const key = formatDateKey(inv.paidAt, groupBy)
    grouped.set(key, (grouped.get(key) || 0) + inv.total)
  }

  const data = Array.from(grouped.entries()).map(([date, value]) => ({
    date,
    value: Math.round(value * 100) / 100,
  }))

  const totalRevenue = data.reduce((sum, d) => sum + d.value, 0)

  return NextResponse.json({
    metric: 'revenue_trends',
    groupBy,
    totalRevenue: Math.round(totalRevenue * 100) / 100,
    data,
  })
}

/**
 * Job stats: status distribution and counts
 */
async function handleJobStats(
  dateFilter: Record<string, unknown>,
  _tenantFilter: Record<string, unknown>,
  workspaceFilter: Record<string, unknown>
) {
  // Job has only `workspaceId` (no `tenantId`) → use workspaceFilter.
  const where = {
    ...workspaceFilter,
    ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}),
  }

  const [
    statusCounts,
    priorityCounts,
    avgCompletionTime,
  ] = await Promise.all([
    db.job.groupBy({
      by: ['status'],
      where,
      _count: { id: true },
    }),
    db.job.groupBy({
      by: ['priority'],
      where,
      _count: { id: true },
    }),
    // Jobs with both start and end times for avg completion
    db.job.findMany({
      where: {
        ...where,
        actualStartTime: { not: null },
        actualEndTime: { not: null },
      },
      select: { actualStartTime: true, actualEndTime: true },
    }),
  ])

  // Calculate average completion time
  let avgDurationMs = 0
  if (avgCompletionTime.length > 0) {
    const totalMs = avgCompletionTime.reduce((sum, job) => {
      if (job.actualStartTime && job.actualEndTime) {
        return sum + (new Date(job.actualEndTime).getTime() - new Date(job.actualStartTime).getTime())
      }
      return sum
    }, 0)
    avgDurationMs = totalMs / avgCompletionTime.length
    if (!isFinite(avgDurationMs)) avgDurationMs = 0
  }

  const statusDistribution: Record<string, number> = {}
  for (const item of statusCounts) {
    statusDistribution[item.status] = item._count.id
  }

  const priorityDistribution: Record<string, number> = {}
  for (const item of priorityCounts) {
    priorityDistribution[item.priority] = item._count.id
  }

  return NextResponse.json({
    metric: 'job_stats',
    statusDistribution,
    priorityDistribution,
    avgCompletionTimeMs: Math.round(avgDurationMs),
    avgCompletionTimeHours: Math.round((avgDurationMs / (1000 * 60 * 60)) * 10) / 10,
    total: Object.values(statusDistribution).reduce((a, b) => a + b, 0),
  })
}

/**
 * Employee productivity: completed jobs, ratings, avg completion time per employee
 */
async function handleEmployeeProductivity(
  dateFilter: Record<string, unknown>,
  _tenantFilter: Record<string, unknown>,
  workspaceFilter: Record<string, unknown>
) {
  // Employee has only `workspaceId` (no `tenantId`) → must use workspaceFilter.
  // (Previously this had NO `where` clause → leaked ALL employees across tenants.)
  const employees = await db.employee.findMany({
    where: workspaceFilter,
    select: {
      id: true,
      name: true,
      role: true,
      rating: true,
      completedJobs: true,
      status: true,
    },
  })

  // Get completed jobs per employee in the date range.
  // Job has only `workspaceId` → use workspaceFilter here too.
  const jobCounts = await db.job.groupBy({
    by: ['assigneeId'],
    where: {
      status: 'completed',
      assigneeId: { in: employees.map(e => e.id) },
      ...workspaceFilter,
      ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}),
    },
    _count: { id: true },
  })

  const jobCountMap = new Map<string, number>()
  for (const item of jobCounts) {
    if (item.assigneeId) {
      jobCountMap.set(item.assigneeId, item._count.id)
    }
  }

  const productivity = employees.map(emp => ({
    id: emp.id,
    name: emp.name,
    role: emp.role,
    status: emp.status,
    rating: emp.rating,
    totalCompletedJobs: emp.completedJobs,
    completedInPeriod: jobCountMap.get(emp.id) || 0,
  }))

  // Sort by completed in period descending
  productivity.sort((a, b) => b.completedInPeriod - a.completedInPeriod)

  return NextResponse.json({
    metric: 'employee_productivity',
    employees: productivity,
  })
}

/**
 * Lead conversion: conversion rates by source and status
 */
async function handleLeadConversion(
  dateFilter: Record<string, unknown>,
  tenantFilter: Record<string, unknown>
) {
  const where = {
    ...tenantFilter,
    ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}),
  }

  const [
    totalLeads,
    convertedLeads,
    leadsBySource,
    leadsByStatus,
  ] = await Promise.all([
    db.lead.count({ where }),
    db.lead.count({ where: { ...where, status: 'won' } }),
    db.lead.groupBy({
      by: ['source'],
      where,
      _count: { id: true },
    }),
    db.lead.groupBy({
      by: ['status'],
      where,
      _count: { id: true },
    }),
  ])

  const conversionRate = totalLeads > 0
    ? Math.round((convertedLeads / totalLeads) * 100)
    : 0

  const bySource: Record<string, number> = {}
  for (const item of leadsBySource) {
    bySource[item.source] = item._count.id
  }

  const byStatus: Record<string, number> = {}
  for (const item of leadsByStatus) {
    byStatus[item.status] = item._count.id
  }

  return NextResponse.json({
    metric: 'lead_conversion',
    totalLeads,
    convertedLeads,
    conversionRate,
    bySource,
    byStatus,
  })
}

/**
 * WhatsApp analytics: response times, conversation volumes, intent distribution
 */
async function handleWhatsAppAnalytics(
  dateFilter: Record<string, unknown>,
  tenantFilter: Record<string, unknown>
) {
  const where = {
    ...tenantFilter,
    type: 'whatsapp',
    ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}),
  }

  const [
    totalConversations,
    activeConversations,
    conversationsByIntent,
    recentConversations,
  ] = await Promise.all([
    db.conversation.count({ where: tenantFilter }),
    db.conversation.count({ where: { ...tenantFilter, status: 'active' } }),
    db.conversation.groupBy({
      by: ['intentDetected'],
      where: { ...tenantFilter, intentDetected: { not: null } },
      _count: { id: true },
    }),
    db.conversation.findMany({
      where: tenantFilter,
      take: 50,
      orderBy: { lastMessageAt: 'desc' },
      select: { id: true, currentStage: true, intentDetected: true, lastMessageAt: true, createdAt: true },
    }),
  ])

  const intentDistribution: Record<string, number> = {}
  for (const item of conversationsByIntent) {
    if (item.intentDetected) {
      intentDistribution[item.intentDetected] = item._count.id
    }
  }

  // ── REAL avg response time ─────────────────────────────────────────
  // Computed from the actual message stream: for each sampled inbound
  // message, find the next outbound (staff/agent) reply in the same
  // conversation and average the gap. Falls back to null when there is
  // no measurable data (never a fabricated number).
  let avgResponseTimeMin: number | null = null
  try {
    const sample = await db.inboxMessage.findMany({
      where: { conversation: tenantFilter },
      orderBy: { createdAt: 'desc' },
      take: 1000,
      select: { conversationId: true, direction: true, createdAt: true },
    })
    // Rebuild chronological order per conversation.
    const byConversation = new Map<string, { direction: string; createdAt: Date }[]>()
    for (let i = sample.length - 1; i >= 0; i--) {
      const m = sample[i]
      let list = byConversation.get(m.conversationId)
      if (!list) {
        list = []
        byConversation.set(m.conversationId, list)
      }
      list.push({ direction: m.direction, createdAt: m.createdAt })
    }
    let gapTotalMs = 0
    let gapCount = 0
    const MAX_GAP_MS = 7 * 24 * 60 * 60 * 1000 // ignore stale threads > 7d
    for (const messages of byConversation.values()) {
      for (let i = 0; i < messages.length - 1; i++) {
        if (messages[i].direction === 'inbound') {
          for (let j = i + 1; j < messages.length; j++) {
            if (messages[j].direction === 'outbound') {
              const gap = messages[j].createdAt.getTime() - messages[i].createdAt.getTime()
              if (gap >= 0 && gap <= MAX_GAP_MS) {
                gapTotalMs += gap
                gapCount++
              }
              break
            }
          }
        }
      }
    }
    if (gapCount > 0) {
      avgResponseTimeMin = Math.round((gapTotalMs / gapCount / 60000) * 10) / 10
    }
  } catch (respErr) {
    console.warn('[analytics] avg response time computation failed (non-fatal):', respErr)
  }

  return NextResponse.json({
    metric: 'whatsapp_analytics',
    totalConversations,
    activeConversations,
    intentDistribution,
    // REAL — from the message stream (inbound → next outbound reply gap).
    avgResponseTimeMin,
    // No button/CTA click tracking exists in the data model — honest null
    // instead of a fabricated 78%. UI renders "—" when null.
    buttonResponseRate: null,
    conversations: recentConversations,
  })
}

/**
 * Journey analytics: stage distribution, completion rates, timing
 */
async function handleJourneyAnalytics(
  dateFilter: Record<string, unknown>,
  tenantFilter: Record<string, unknown>
) {
  const where = {
    ...tenantFilter,
    ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}),
  }

  const [
    totalJourneys,
    completedJourneys,
    journeysByStage,
    scheduledActions,
  ] = await Promise.all([
    db.customerJourney.count({ where }),
    db.customerJourney.count({ where: { ...where, currentStage: 'completed' } }),
    db.customerJourney.groupBy({
      by: ['currentStage'],
      where,
      _count: { id: true },
    }),
    db.customerJourney.count({
      where: {
        ...where,
        nextActionAt: { not: null },
        automationActive: true,
      },
    }),
  ])

  const stageDistribution: Record<string, number> = {}
  for (const item of journeysByStage) {
    stageDistribution[item.currentStage] = item._count.id
  }

  const completionRate = totalJourneys > 0
    ? Math.round((completedJourneys / totalJourneys) * 100)
    : 0

  // ── REAL avg journey duration ────────────────────────────────────────
  // For journeys that reached a terminal stage, measure createdAt →
  // stageChangedAt (the last actual transition recorded on the row).
  let avgJourneyTimeHours: number | null = null
  try {
    const completedSample = await db.customerJourney.findMany({
      where: {
        ...tenantFilter,
        currentStage: { in: ['completed', 'review'] },
      },
      orderBy: { stageChangedAt: 'desc' },
      take: 500,
      select: { createdAt: true, stageChangedAt: true },
    })
    let totalMs = 0
    let counted = 0
    for (const j of completedSample) {
      const span = j.stageChangedAt.getTime() - j.createdAt.getTime()
      if (span > 0) {
        totalMs += span
        counted++
      }
    }
    if (counted > 0) {
      avgJourneyTimeHours = Math.round((totalMs / counted / 3600000) * 10) / 10
    }
  } catch (journeyErr) {
    console.warn('[analytics] avg journey time computation failed (non-fatal):', journeyErr)
  }

  return NextResponse.json({
    metric: 'journey_analytics',
    totalJourneys,
    completedJourneys,
    completionRate,
    stageDistribution,
    scheduledActionsPending: scheduledActions,
    // REAL — avg of actual lead→terminal transition spans (null when no
    // completed journeys yet, instead of a fabricated 22h).
    avgJourneyTimeHours,
  })
}

/**
 * Format a date to a key based on the groupBy parameter.
 */
function formatDateKey(date: Date, groupBy: string): string {
  const d = new Date(date)
  switch (groupBy) {
    case 'year':
      return `${d.getFullYear()}`
    case 'month':
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
    case 'week': {
      const startOfYear = new Date(d.getFullYear(), 0, 1)
      const weekNum = Math.ceil(((d.getTime() - startOfYear.getTime()) / 86400000 + startOfYear.getDay() + 1) / 7)
      return `${d.getFullYear()}-W${String(weekNum).padStart(2, '0')}`
    }
    case 'day':
    default:
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  }
}
