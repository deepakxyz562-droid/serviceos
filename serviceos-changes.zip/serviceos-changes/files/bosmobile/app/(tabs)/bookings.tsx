import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Switch,
  Linking,
  SafeAreaView,
  StatusBar,
  Modal,
  Share,
  Alert,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { hapticFeedback } from '@/lib/haptics';
import { API_PATHS } from '@/lib/constants';
import { apiRequest, ApiError } from '@/lib/api';

interface BookingItem {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  service: string;
  time: string;
  dateKey: 'today' | 'tomorrow' | 'this_week';
  duration: string;
  depositPaid: boolean;
  amount: number;
  meetingType: 'video' | 'in_person' | 'phone';
  meetingLocation: string;
  intakeAnswers: { question: string; answer: string }[];
  status: 'confirmed' | 'rescheduled' | 'cancelled';
}

export default function BookingsScreen() {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'event_types' | 'settings'>('upcoming');
  const [selectedBooking, setSelectedBooking] = useState<BookingItem | null>(null);
  const [filterDate, setFilterDate] = useState<'all' | 'today' | 'tomorrow'>('all');
  const [autoConfirm, setAutoConfirm] = useState(true);
  const [googleCalendarSync, setGoogleCalendarSync] = useState(false);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [bookings, setBookings] = useState<BookingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchBookings = async () => {
    try {
      setError(null);
      const res = await apiRequest<any>(API_PATHS.bookings);
      const list = Array.isArray(res) ? res : res?.bookings || [];
      const mapped: BookingItem[] = list.map((it: any, idx: number) => {
        const scheduled = it.scheduledAt ? new Date(it.scheduledAt) : null;
        let dateKey: 'today' | 'tomorrow' | 'this_week' = 'this_week';
        if (scheduled) {
          const now = new Date();
          const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          const startTmr = new Date(startToday); startTmr.setDate(startTmr.getDate() + 1);
          if (scheduled >= startToday && scheduled < startTmr) dateKey = 'today';
          else if (scheduled >= startTmr && scheduled.getTime() < startTmr.getTime() + 24 * 3600 * 1000) dateKey = 'tomorrow';
        }
        return {
          id: it.id || `b-${idx}`,
          customerName: it.customerName || it.name || 'Customer',
          phone: it.customerPhone || it.phone || '',
          email: it.customerEmail || it.email || '',
          service: it.serviceName || it.title || 'Consultation',
          time: scheduled ? scheduled.toLocaleString() : 'Scheduled',
          dateKey,
          duration: it.duration ? `${it.duration} min` : '30 min',
          depositPaid: !!it.depositPaid,
          amount: Number(it.price || it.amount || 0),
          meetingType: (it.meetingType === 'video' || it.meetingType === 'phone') ? it.meetingType : 'in_person',
          meetingLocation: it.location || it.address || 'Store / Office',
          intakeAnswers: Array.isArray(it.answers) ? it.answers : [],
          status: it.status || 'confirmed',
        };
      });
      setBookings(mapped);
    } catch (err: any) {
      const msg =
        err instanceof ApiError
          ? err.message
          : err?.message || 'We couldn\'t load your bookings right now.';
      setError(msg);
      setBookings([]);
    }
  };

  const fetchSettings = useCallback(async () => {
    try {
      const res = await apiRequest<{
        autoConfirm?: boolean;
        googleCalendarSync?: boolean;
      }>(API_PATHS.bookingSettings);
      if (typeof res.autoConfirm === 'boolean') setAutoConfirm(res.autoConfirm);
      if (typeof res.googleCalendarSync === 'boolean') setGoogleCalendarSync(res.googleCalendarSync);
    } catch {
      // Non-fatal: defaults remain in place; toggles still work locally.
    } finally {
      setSettingsLoaded(true);
    }
  }, []);

  const persistSetting = useCallback(
    async (key: 'autoConfirm' | 'googleCalendarSync', value: boolean) => {
      // Optimistic update is already applied by the caller (setAutoConfirm/
      // setGoogleCalendarSync). We just POST to the backend and revert on
      // failure with an Alert.
      setSettingsSaving(true);
      try {
        const res = await apiRequest<{
          autoConfirm?: boolean;
          googleCalendarSync?: boolean;
        }>(API_PATHS.bookingSettings, {
          method: 'PATCH',
          body: { [key]: value },
        });
        // Reconcile with the canonical server state.
        if (typeof res.autoConfirm === 'boolean') setAutoConfirm(res.autoConfirm);
        if (typeof res.googleCalendarSync === 'boolean') setGoogleCalendarSync(res.googleCalendarSync);
      } catch (err: any) {
        const msg =
          err instanceof ApiError
            ? err.message
            : err?.message || 'Could not save your preference.';
        // Revert the optimistic toggle.
        if (key === 'autoConfirm') setAutoConfirm(!value);
        if (key === 'googleCalendarSync') setGoogleCalendarSync(!value);
        Alert.alert('Save failed', msg);
      } finally {
        setSettingsSaving(false);
      }
    },
    [],
  );

  const handleToggleAutoConfirm = async (val: boolean) => {
    await hapticFeedback.light();
    setAutoConfirm(val);
    persistSetting('autoConfirm', val);
  };

  const handleToggleGoogleCalendarSync = async (val: boolean) => {
    await hapticFeedback.light();
    setGoogleCalendarSync(val);
    persistSetting('googleCalendarSync', val);
  };

  useEffect(() => {
    Promise.all([fetchBookings(), fetchSettings()]).finally(() => setLoading(false));
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    hapticFeedback.light();
    await fetchBookings();
    setRefreshing(false);
  };

  const filteredBookings = bookings.filter((b) => {
    if (filterDate === 'all') return true;
    return b.dateKey === filterDate;
  });

  const handleCall = async (phone: string) => {
    await hapticFeedback.medium();
    Linking.openURL(`tel:${phone}`);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backBtn}
          onPress={() => {
            hapticFeedback.light();
            router.back();
          }}
          activeOpacity={0.7}
        >
          <MaterialIcons name="arrow-back" size={24} color="#0f172a" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Bookings &amp; Calendar</Text>
        <View style={styles.headerRight} />
      </View>

      <View style={styles.container}>
        {/* Navigation Tabs */}
        <View style={styles.tabsRow}>
          {[
            { id: 'upcoming', label: 'Appointments', icon: 'event' },
            { id: 'event_types', label: 'Event Types', icon: 'schedule' },
            { id: 'settings', label: 'Calendar Sync', icon: 'sync' },
          ].map((tab) => {
            const active = activeTab === tab.id;
            return (
              <TouchableOpacity
                key={tab.id}
                onPress={async () => {
                  await hapticFeedback.light();
                  setActiveTab(tab.id as any);
                }}
                style={[styles.tabItem, active && styles.tabItemActive]}
                activeOpacity={0.8}
              >
                <MaterialIcons
                  name={tab.icon as any}
                  size={15}
                  color={active ? '#ffffff' : '#64748b'}
                />
                <Text style={[styles.tabLabel, active && styles.tabLabelActive]}>
                  {tab.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Tab 1: Upcoming Appointments */}
        {activeTab === 'upcoming' && (
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#10B981']} />}
            showsVerticalScrollIndicator={false}
          >
            {/* Filter Pills */}
            <View style={styles.filterPillsRow}>
              {(['all', 'today', 'tomorrow'] as const).map((filter) => (
                <TouchableOpacity
                  key={filter}
                  onPress={async () => {
                    await hapticFeedback.light();
                    setFilterDate(filter);
                  }}
                  style={[styles.pill, filterDate === filter && styles.pillActive]}
                  activeOpacity={0.8}
                >
                  <Text style={[styles.pillText, filterDate === filter && styles.pillTextActive]}>
                    {filter === 'all' ? 'All Slots' : filter === 'today' ? 'Today' : 'Tomorrow'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Loading */}
            {loading && (
              <View style={styles.stateWrap}>
                <ActivityIndicator size="large" color="#10B981" />
                <Text style={styles.stateText}>Loading appointments…</Text>
              </View>
            )}

            {/* Error */}
            {!loading && error && (
              <View style={styles.errorWrap}>
                <MaterialIcons name="cloud-off" size={40} color="#ef4444" style={{ marginBottom: 10 }} />
                <Text style={styles.errorTitle}>Couldn't load bookings</Text>
                <Text style={styles.errorText}>{error}</Text>
                <TouchableOpacity
                  style={styles.retryBtn}
                  onPress={() => {
                    hapticFeedback.light();
                    setLoading(true);
                    fetchBookings().finally(() => setLoading(false));
                  }}
                  activeOpacity={0.7}
                >
                  <Text style={styles.retryBtnText}>Try again</Text>
                </TouchableOpacity>
              </View>
            )}

            {/* Empty (no bookings at all) */}
            {!loading && !error && bookings.length === 0 && (
              <View style={styles.emptyWrap}>
                <MaterialIcons name="event-available" size={48} color="#cbd5e1" style={{ marginBottom: 12 }} />
                <Text style={styles.emptyTitle}>No appointments yet</Text>
                <Text style={styles.emptySub}>New bookings from your calendar links and forms will appear here.</Text>
              </View>
            )}

            {/* Loaded list / per-filter empty */}
            {!loading && !error && bookings.length > 0 && (
              <>
              {filteredBookings.map((b) => (
                <TouchableOpacity
                  key={b.id}
                  style={styles.bookingCard}
                  onPress={() => {
                    hapticFeedback.light();
                    setSelectedBooking(b);
                  }}
                  activeOpacity={0.8}
                >
                  <View style={styles.bookingCardHeader}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.bookingCustomer}>{b.customerName}</Text>
                      <Text style={styles.bookingService}>{b.service}</Text>
                    </View>
                    <View style={styles.bookingStatusBadge}>
                      <Text style={styles.bookingStatusText}>Confirmed</Text>
                    </View>
                  </View>

                  <View style={styles.bookingDetailsRow}>
                    <View style={styles.detailItem}>
                      <MaterialIcons name="access-time" size={14} color="#64748b" style={{ marginRight: 4 }} />
                      <Text style={styles.detailText}>{b.time} ({b.duration})</Text>
                    </View>
                    <View style={styles.detailItem}>
                      <MaterialIcons
                        name={b.meetingType === 'video' ? 'videocam' : b.meetingType === 'phone' ? 'phone' : 'place'}
                        size={14}
                        color="#64748b"
                        style={{ marginRight: 4 }}
                      />
                      <Text style={styles.detailText}>
                        {b.meetingType === 'video' ? 'Google Meet' : b.meetingType === 'phone' ? 'Phone' : 'In-Person'}
                      </Text>
                    </View>
                  </View>

                  {b.depositPaid && (
                    <View style={styles.depositRow}>
                      <MaterialIcons name="check-circle" size={14} color="#10b981" style={{ marginRight: 4 }} />
                      <Text style={styles.depositText}>Deposit Paid: ${b.amount}</Text>
                    </View>
                  )}

                  <View style={styles.bookingFooter}>
                    <Text style={styles.viewIntakeLink}>View Intake Details →</Text>
                    <TouchableOpacity
                      onPress={() => handleCall(b.phone)}
                      style={styles.callIconBtn}
                      activeOpacity={0.7}
                    >
                      <MaterialIcons name="phone" size={16} color="#10b981" />
                    </TouchableOpacity>
                  </View>
                </TouchableOpacity>
              ))}

              {filteredBookings.length === 0 && (
                <View style={styles.emptyWrap}>
                  <MaterialIcons name="event-busy" size={40} color="#cbd5e1" style={{ marginBottom: 8 }} />
                  <Text style={styles.emptyTitle}>No appointments for this filter</Text>
                  <Text style={styles.emptySub}>Try another date filter above.</Text>
                </View>
              )}
              </>
            )}
          </ScrollView>
        )}

        {/* Tab 2: Event Types — honest state; bookable event types are
            configured from the BOS web dashboard and sync to bookings. */}
        {activeTab === 'event_types' && (
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.emptyWrap}>
              <MaterialIcons name="event-note" size={44} color="#94a3b8" />
              <Text style={styles.emptyTitle}>Event types are managed on the web dashboard</Text>
              <Text style={styles.emptySub}>
                Create bookable event types (duration, price and booking link) from your BOS web dashboard — new bookings made through those links appear here automatically.
              </Text>
              <Text style={styles.emptySub}>
                You have {bookings.length} booking{bookings.length === 1 ? '' : 's'} scheduled so far.
              </Text>
              <TouchableOpacity
                onPress={() => setActiveTab('upcoming')}
                style={[styles.shareBtn, { alignSelf: 'center', marginTop: 8 }]}
                activeOpacity={0.7}
              >
                <MaterialIcons name="event-available" size={16} color="#3b82f6" style={{ marginRight: 4 }} />
                <Text style={styles.shareBtnText}>View Bookings</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        )}

        {/* Tab 3: Calendar Sync & Settings */}
        {activeTab === 'settings' && (
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {!settingsLoaded && (
              <View style={styles.stateWrap}>
                <ActivityIndicator size="small" color="#10B981" />
                <Text style={styles.stateText}>Loading settings…</Text>
              </View>
            )}
            <View style={styles.settingsCard}>
              <View style={styles.settingsRow}>
                <View style={{ flex: 1, marginRight: 12 }}>
                  <Text style={styles.settingsLabel}>Auto-Confirm Bookings</Text>
                  <Text style={styles.settingsSubtitle}>Instantly reserve calendar slots without manual review</Text>
                </View>
                <Switch
                  value={autoConfirm}
                  onValueChange={handleToggleAutoConfirm}
                  disabled={settingsSaving}
                  trackColor={{ false: '#cbd5e1', true: '#10b981' }}
                  thumbColor="#ffffff"
                />
              </View>

              <View style={styles.settingsDivider} />

              <View style={styles.settingsRow}>
                <View style={{ flex: 1, marginRight: 12 }}>
                  <Text style={styles.settingsLabel}>Google Calendar 2-Way Sync</Text>
                  <Text style={styles.settingsSubtitle}>Automatically block out busy slots and push new meetings</Text>
                </View>
                <Switch
                  value={googleCalendarSync}
                  onValueChange={handleToggleGoogleCalendarSync}
                  disabled={settingsSaving}
                  trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
                  thumbColor="#ffffff"
                />
              </View>
            </View>
          </ScrollView>
        )}
      </View>

      {/* Appointment Detail Modal */}
      <Modal
        visible={!!selectedBooking}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setSelectedBooking(null)}
      >
        <SafeAreaView style={styles.modalSafe}>
          <View style={styles.modalHeader}>
            <View>
              <Text style={styles.modalTitle}>{selectedBooking?.customerName}</Text>
              <Text style={styles.modalSubtitle}>{selectedBooking?.service}</Text>
            </View>
            <TouchableOpacity
              onPress={() => setSelectedBooking(null)}
              style={styles.modalCloseBtn}
              activeOpacity={0.7}
            >
              <MaterialIcons name="close" size={24} color="#64748b" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
            <View style={styles.modalCard}>
              <View style={styles.modalFieldRow}>
                <MaterialIcons name="access-time" size={18} color="#64748b" style={{ marginRight: 8 }} />
                <Text style={styles.modalFieldText}>{selectedBooking?.time}</Text>
              </View>
              <View style={styles.modalFieldRow}>
                <MaterialIcons name="phone" size={18} color="#64748b" style={{ marginRight: 8 }} />
                <Text style={styles.modalFieldText}>{selectedBooking?.phone}</Text>
              </View>
              <View style={styles.modalFieldRow}>
                <MaterialIcons name="place" size={18} color="#64748b" style={{ marginRight: 8 }} />
                <Text style={styles.modalFieldText}>{selectedBooking?.meetingLocation}</Text>
              </View>
            </View>

            {/* Intake Questions & Answers */}
            <Text style={styles.intakeHeading}>Customer Intake Answers</Text>
            <View style={styles.intakeBox}>
              {selectedBooking?.intakeAnswers.map((item, idx) => (
                <View key={idx} style={styles.intakeItem}>
                  <Text style={styles.intakeQuestion}>{item.question}</Text>
                  <Text style={styles.intakeAnswer}>{item.answer}</Text>
                </View>
              ))}
            </View>

            {/* Actions */}
            <View style={styles.modalActionRow}>
              <TouchableOpacity
                onPress={() => handleCall(selectedBooking?.phone || '')}
                style={styles.modalCallBtn}
                activeOpacity={0.7}
              >
                <MaterialIcons name="phone" size={18} color="#ffffff" style={{ marginRight: 6 }} />
                <Text style={styles.modalCallBtnText}>Call Customer</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  backBtn: {
    padding: 6,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0f172a',
  },
  headerRight: {
    width: 36,
  },
  container: {
    flex: 1,
    padding: 16,
  },
  tabsRow: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    padding: 4,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 14,
  },
  tabItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 9,
    borderRadius: 10,
    gap: 5,
  },
  tabItemActive: {
    backgroundColor: '#0f172a',
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: '#64748b',
  },
  tabLabelActive: {
    color: '#ffffff',
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 40,
    gap: 12,
  },
  filterPillsRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 4,
  },
  pill: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  pillActive: {
    backgroundColor: '#0f172a',
    borderColor: '#0f172a',
  },
  pillText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#64748b',
  },
  pillTextActive: {
    color: '#ffffff',
  },
  bookingCard: {
    backgroundColor: '#ffffff',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  bookingCardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  bookingCustomer: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0f172a',
  },
  bookingService: {
    fontSize: 13,
    fontWeight: '600',
    color: '#3b82f6',
    marginTop: 2,
  },
  bookingStatusBadge: {
    backgroundColor: '#ecfdf5',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  bookingStatusText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#059669',
  },
  bookingDetailsRow: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 4,
    marginBottom: 8,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailText: {
    fontSize: 12,
    color: '#64748b',
  },
  depositRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0fdf4',
    padding: 8,
    borderRadius: 8,
    marginBottom: 10,
  },
  depositText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#15803d',
  },
  bookingFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  viewIntakeLink: {
    fontSize: 12,
    fontWeight: '700',
    color: '#3b82f6',
  },
  callIconBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#ecfdf5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  eventTypeList: {
    gap: 12,
  },
  eventTypeCard: {
    backgroundColor: '#ffffff',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  evtHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  evtTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0f172a',
  },
  evtDuration: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
    marginTop: 2,
  },
  shareBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eff6ff',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  shareBtnText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#3b82f6',
  },
  evtDesc: {
    fontSize: 12,
    color: '#475569',
    lineHeight: 17,
    marginBottom: 10,
  },
  evtLinkRow: {
    backgroundColor: '#f8fafc',
    padding: 8,
    borderRadius: 8,
  },
  evtLinkText: {
    fontSize: 11,
    color: '#64748b',
    fontFamily: 'monospace',
  },
  settingsCard: {
    backgroundColor: '#ffffff',
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  settingsLabel: {
    fontSize: 14,
    fontWeight: '800',
    color: '#0f172a',
  },
  settingsSubtitle: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    lineHeight: 16,
  },
  settingsDivider: {
    height: 1,
    backgroundColor: '#f1f5f9',
    marginVertical: 14,
  },
  modalSafe: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#0f172a',
  },
  modalSubtitle: {
    fontSize: 12,
    color: '#3b82f6',
    fontWeight: '600',
    marginTop: 2,
  },
  modalCloseBtn: {
    padding: 6,
  },
  modalScroll: {
    flex: 1,
    padding: 16,
  },
  modalCard: {
    backgroundColor: '#f8fafc',
    borderRadius: 14,
    padding: 14,
    gap: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  modalFieldRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  modalFieldText: {
    fontSize: 13,
    color: '#334155',
    fontWeight: '500',
  },
  intakeHeading: {
    fontSize: 14,
    fontWeight: '800',
    color: '#0f172a',
    marginBottom: 8,
  },
  intakeBox: {
    backgroundColor: '#ffffff',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
    marginBottom: 20,
  },
  intakeItem: {
    gap: 4,
  },
  intakeQuestion: {
    fontSize: 12,
    fontWeight: '700',
    color: '#64748b',
  },
  intakeAnswer: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
  },
  modalActionRow: {
    paddingBottom: 20,
  },
  modalCallBtn: {
    backgroundColor: '#10b981',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 44,
    borderRadius: 12,
  },
  modalCallBtnText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
  },
  stateWrap: {
    alignItems: 'center',
    paddingVertical: 56,
    paddingHorizontal: 24,
  },
  stateText: {
    fontSize: 13,
    color: '#64748b',
    marginTop: 10,
  },
  errorWrap: {
    alignItems: 'center',
    paddingVertical: 44,
    paddingHorizontal: 24,
  },
  errorTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0f172a',
    marginBottom: 4,
  },
  errorText: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 18,
  },
  retryBtn: {
    backgroundColor: '#0f172a',
    paddingHorizontal: 22,
    paddingVertical: 10,
    borderRadius: 12,
  },
  retryBtnText: {
    color: '#ffffff',
    fontSize: 13,
    fontWeight: '700',
  },
  emptyWrap: {
    alignItems: 'center',
    paddingVertical: 48,
    paddingHorizontal: 24,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0f172a',
    marginBottom: 4,
  },
  emptySub: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
  },
});
