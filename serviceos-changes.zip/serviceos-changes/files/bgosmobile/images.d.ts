// Static asset module declarations (Metro bundler resolves these at build time).
declare module '*.png' {
  const source: number;
  export default source;
}
declare module '*.jpg' {
  const source: number;
  export default source;
}
