import { NextRequest, NextResponse } from 'next/server';
import { getAuthUser, getProductAppUrl } from '@/lib/auth';
import { db } from '@/lib/db';
import {
  BUSINESS_EDITIONS,
  BUSINESS_GROUPS,
  templateMatches,
  type Purpose,
} from '../../../../../../shared/business-template-collection';
import { composeBusinessEdition } from '../../../../../../shared/business-template-design';
import {
  scoreIndustryMatch,
  getCategoryVisualPool,
  CURATED_SMB_IMAGE_REGISTRY,
} from '@/lib/designs/dynamic-visual-resolver';
import {
  getMultiSourceCategoryVisuals,
  getFestivalVisuals,
  getCreativeSourceLabel,
  type MultiSourceCreativeVisual,
} from '@/lib/designs/multi-source-creative-engine';
import { getSeasonalOccasions } from '@/lib/designs/visual-query-builder';
import { normalizeCategoryContext } from '@/lib/designs/category-taxonomy';
import { generateCategoryBlueprints, getGbpCategoryByNameOrAlias } from '@/lib/gbp/master-category-catalog';
import { POSTER_TEMPLATES, type PosterTemplate } from '../../../../../../shared/poster-templates';
import {
  getCuratedTemplatesForBusiness,
  TEMPLATE_BUCKETS,
  type CuratedTemplateItem,
} from '../../../../../../shared/curated-photo-templates';

const FESTIVAL_VISUAL_POOL: Record<string, string[]> = {
  diwali: [
    '/images/bgos/templates/diwali.webp',
    'https://images.unsplash.com/photo-1572798089532-487718bc9d26?w=1200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1634401609694-f6ac6dd8474b?w=1200&auto=format&fit=crop&q=80',
  ],
  holi: [
    '/images/bgos/templates/edition-holi.webp',
    'https://images.unsplash.com/photo-1503127241807-fdc42d3acb95?w=1200&auto=format&fit=crop&q=80',
  ],
  eid: [
    '/images/bgos/templates/edition-eid.webp',
    'https://images.unsplash.com/photo-1564769625905-50e93615e769?w=1200&auto=format&fit=crop&q=80',
  ],
  christmas: [
    '/images/bgos/templates/edition-christmas.webp',
    'https://images.unsplash.com/photo-1512389142860-9c449e58a543?w=1200&auto=format&fit=crop&q=80',
  ],
  new_year: [
    '/images/bgos/templates/edition-new-year.webp',
    'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=1200&auto=format&fit=crop&q=80',
  ],
  independence_day: [
    '/images/bgos/templates/edition-independence-day.webp',
    'https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=1200&auto=format&fit=crop&q=80',
  ],
  republic_day: [
    '/images/bgos/templates/edition-republic-day.webp',
    'https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=1200&auto=format&fit=crop&q=80',
  ],
  rakhi: [
    '/images/bgos/templates/edition-rakhi.webp',
    '/images/bgos/templates/diwali.webp',
  ],
  navratri: [
    '/images/bgos/templates/edition-navratri.webp',
    'https://images.unsplash.com/photo-1572798089532-487718bc9d26?w=1200&auto=format&fit=crop&q=80',
  ],
  dussehra: [
    '/images/bgos/templates/edition-navratri.webp',
    '/images/bgos/templates/diwali.webp',
  ],
  chhath_puja: [
    '/images/bgos/templates/diwali.webp',
    'https://images.unsplash.com/photo-1572798089532-487718bc9d26?w=1200&auto=format&fit=crop&q=80',
  ],
  valentine: [
    '/images/bgos/templates/edition-valentine.webp',
    'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=1200&auto=format&fit=crop&q=80',
  ],
  mothers_day: [
    '/images/bgos/templates/edition-mothers-day.webp',
  ],
  fathers_day: [
    '/images/bgos/templates/edition-fathers-day.webp',
  ],
};

interface BusinessTemplateResponseItem {
  id: string;
  layout: string;
  name: string;
  headline: string;
  subtitle: string;
  badge: string;
  cta: string;
  tab: 'for_business' | 'promotions' | 'festivals' | 'reviews';
  purpose: Purpose;
  theme: string;
  aspectRatio: '1:1' | '4:5' | '9:16';
  photoUrl: string;
  photoSource?: string;
  photoCredit?: string;
  bgPrompt?: string;
  occasionId?: string;
  design?: any;
  defaultBullets?: string[];
  targetKeywords?: Array<{ keyword: string; volume: number }>;
  estimatedViews?: number;
  defaultCaption?: string;
}

function mapPurposeToTab(purpose?: Purpose): 'for_business' | 'promotions' | 'festivals' | 'reviews' {
  if (purpose === 'Promotion') return 'promotions';
  if (purpose === 'Festival') return 'festivals';
  if (purpose === 'Trust-building') return 'reviews';
  return 'for_business';
}

export async function GET(request: NextRequest) {
  const user = await getAuthUser(request);
  if (!user?.tenantId) {
    return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const requestedTab = searchParams.get('tab') || 'all'; // 'for_business' | 'promotions' | 'festivals' | 'reviews' | 'all'
  const requestedAspect = searchParams.get('aspect'); // '1:1' | '4:5' | '9:16'
  const searchQuery = searchParams.get('q') || '';
  const limit = Math.min(300, Math.max(8, parseInt(searchParams.get('limit') || '150', 10)));
  const includeDesign = searchParams.get('includeDesign') !== '0';

  // 1. Fetch tenant business context, connected GBP account, and real added services
  const [tenant, brandProfile, gbpAccount, merchantServices] = await Promise.all([
    db.tenant.findUnique({
      where: { id: user.tenantId },
      select: { name: true, industry: true, phone: true, address: true, city: true, settingsJson: true },
    }).catch(() => null),
    db.brandProfile.findUnique({
      where: { id: user.tenantId },
    }).catch(() => null),
    (db.socialAccount?.findFirst({
      where: { tenantId: user.tenantId, platform: 'googlebusiness', isActive: true },
    }) ?? Promise.resolve(null)).catch(() => null),
    (db.service?.findMany({
      where: { tenantId: user.tenantId, isActive: true },
      select: { name: true, description: true, category: true, basePrice: true },
      orderBy: { updatedAt: 'desc' },
      take: 40,
    }) ?? Promise.resolve([])).catch(() => []),
  ]);

  let businessName = brandProfile?.businessName || tenant?.name || 'My Business';
  let industry = brandProfile?.industry || tenant?.industry || 'Retail & Local Services';

  const paramBusinessName = searchParams.get('businessName')?.trim();
  const paramIndustry = searchParams.get('industry')?.trim();
  if (paramBusinessName && (!businessName || businessName === 'My Business')) {
    businessName = paramBusinessName;
  }
  if (paramIndustry && (!industry || /retail & local services|services|^other$/i.test(industry))) {
    industry = paramIndustry;
  }
  let phone = tenant?.phone || '';
  let website = brandProfile?.website || '';
  let logoUrl = (brandProfile as any)?.logoUrl || '';
  let address = tenant?.address || '';
  let city = (tenant as any)?.city || brandProfile?.location || 'Patna';

  // Derive the origin from the incoming request (x-forwarded-host aware) so
  // preview/proxy gateways never receive mismatched absolute image URLs.
  const resolveRequestOrigin = (): string => {
    const proto =
      request.headers.get('x-forwarded-proto')?.split(',')[0]?.trim() ||
      request.nextUrl?.protocol?.replace(/:$/, '') ||
      'https';
    const host =
      request.headers.get('x-forwarded-host')?.split(',')[0]?.trim() ||
      request.headers.get('host')?.split(',')[0]?.trim();
    if (host) return `${proto}://${host}`;
    const envUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;
    return envUrl ? envUrl.replace(/\/$/, '') : '';
  };
  const baseUrl = resolveRequestOrigin() || getProductAppUrl(request, 'bgos');
  const toAbsoluteUrl = (path?: string | null): string => {
    if (!path) return '';
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    return `${baseUrl}${path.startsWith('/') ? path : `/${path}`}`;
  };

  if (logoUrl) logoUrl = toAbsoluteUrl(logoUrl);

  // Parse GBP / Brand Brain overrides from settingsJson if available
  if (tenant?.settingsJson) {
    try {
      const parsed = JSON.parse(tenant.settingsJson);
      if (parsed?.activeGbpTitle) businessName = parsed.activeGbpTitle;
      if (parsed?.activeGbpCategory && !/corporate|holding|community/i.test(parsed.activeGbpCategory)) {
        industry = parsed.activeGbpCategory;
      }
      if (parsed?.activeGbpPhone) phone = parsed.activeGbpPhone;
      if (parsed?.activeGbpAddress) address = parsed.activeGbpAddress;
      if (parsed?.activeGbpCity) city = parsed.activeGbpCity;
    } catch {}
  }

  // Parse connected Google Business Profile account if present
  if (gbpAccount) {
    try {
      const gbpMeta =
        typeof gbpAccount.metadata === 'string'
          ? JSON.parse(gbpAccount.metadata)
          : (gbpAccount.metadata as any);
      const gbpCategory =
        (typeof gbpMeta?.primaryCategory === 'string' ? gbpMeta.primaryCategory : gbpMeta?.primaryCategory?.displayName) ||
        gbpMeta?.raw?.categories?.primaryCategory?.displayName ||
        gbpMeta?.categories?.primaryCategory?.displayName ||
        gbpMeta?.location?.primaryCategory?.displayName ||
        (typeof gbpMeta?.category === 'string' ? gbpMeta.category : gbpMeta?.category?.displayName) ||
        gbpMeta?.categoryName;
      const gbpTitle = gbpMeta?.locationTitle || gbpMeta?.name || gbpAccount.accountName;
      if (gbpTitle && (businessName === 'My Business' || !businessName)) {
        businessName = gbpTitle;
      }
      if (
        gbpCategory &&
        (!industry ||
          /corporate|holding|community|retail & local services|services|^other$/i.test(industry))
      ) {
        industry = gbpCategory;
      }
      if (gbpMeta?.phone && !phone) phone = gbpMeta.phone;
      if (gbpMeta?.address && !address) address = gbpMeta.address;
      if (gbpMeta?.city && (!city || city === 'Patna')) city = gbpMeta.city;
    } catch {}
  }

  // Real merchant services added to ServiceOS/BGOS
  const realServiceNames: string[] = (merchantServices || [])
    .map((s: any) => (typeof s?.name === 'string' ? s.name.trim() : ''))
    .filter(Boolean);

  // If industry is unset or a generic fallback placeholder, dynamically derive the merchant's trade
  // from their real added services or business title via the Universal Category Taxonomy
  if (!industry || /corporate|holding|community|retail & local services|services|^other$/i.test(industry)) {
    if (realServiceNames.length > 0) {
      const derived = normalizeCategoryContext(realServiceNames.join(' '));
      if (derived.detectedSubject) {
        industry = `${derived.detectedSubject} Services`;
      } else if (derived.verticalLabel) {
        industry = derived.verticalLabel;
      }
    } else if (businessName && businessName !== 'My Business') {
      const derivedFromTitle = normalizeCategoryContext(businessName);
      if (derivedFromTitle.detectedSubject) {
        industry = `${derivedFromTitle.detectedSubject} Services`;
      }
    }
  }

  // 2. Identify industry matcher & visual pool with Universal Category Taxonomy
  const servicesContext = realServiceNames.slice(0, 5).join(' ');
  const searchContext = normalizeCategoryContext(
    searchQuery || `${servicesContext} ${industry} ${businessName}`,
  );
  const effectiveCategoryText = searchQuery.trim()
    ? `${searchQuery} ${servicesContext} ${industry} ${businessName}`
    : `${servicesContext} ${industry} ${businessName}`.trim();

  const matchedIndustryKey = scoreIndustryMatch(effectiveCategoryText);

  // ── Tier 1: the merchant's own photos (brand library + recent post media) ──
  const [libraryRows, postRows] = await Promise.all([
    (db.imageLibrary?.findMany({
      where: { tenantId: user.tenantId },
      orderBy: { createdAt: 'desc' },
      take: 20,
      select: { id: true, name: true, url: true, folder: true, mediaType: true },
    }) ?? Promise.resolve([])).catch(
      () =>
        [] as Array<{
          id: string;
          name: string | null;
          url: string;
          folder: string | null;
          mediaType: string | null;
        }>,
    ),
    (db.socialPost?.findMany({
      where: { tenantId: user.tenantId },
      orderBy: { createdAt: 'desc' },
      take: 12,
      select: { id: true, mediaUrls: true },
    }) ?? Promise.resolve([])).catch(
      () => [] as Array<{ id: string; mediaUrls: string | null }>,
    ),
  ]);

  const parseMediaList = (raw: unknown): string[] => {
    if (Array.isArray(raw)) return raw.filter((u): u is string => typeof u === 'string' && Boolean(u.trim()));
    if (typeof raw !== 'string' || !raw.trim()) return [];
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed)
        ? parsed.filter((u): u is string => typeof u === 'string' && Boolean(u.trim()))
        : [];
    } catch {
      return /^https?:\/\//i.test(raw) || raw.startsWith('/') ? [raw] : [];
    }
  };

  const userPhotos: Array<{ url: string; title?: string }> = [];
  const seenUserPhotoUrls = new Set<string>();
  for (const row of libraryRows) {
    const url = typeof row?.url === 'string' ? row.url.trim() : '';
    if (!url || /\.(mp4|mov|webm|m4v|3gp|mkv|avi)(\?|$)/i.test(url)) continue;
    if (!seenUserPhotoUrls.has(url)) {
      seenUserPhotoUrls.add(url);
      userPhotos.push({ url, title: row.name || 'Brand Library Photo' });
    }
  }
  for (const post of postRows) {
    for (const u of parseMediaList(post?.mediaUrls)) {
      if (!/^https?:\/\//i.test(u) && !u.startsWith('/')) continue;
      if (!seenUserPhotoUrls.has(u)) {
        seenUserPhotoUrls.add(u);
        userPhotos.push({ url: u, title: 'Your Social Post' });
      }
    }
  }

  // ── Seasonal occasions driving dynamic festival visuals ──
  const seasonalOccasions = getSeasonalOccasions();
  if (searchContext.isFestival && searchContext.detectedOccasion) {
    seasonalOccasions.unshift({ id: searchContext.detectedOccasion, label: searchContext.detectedOccasion });
  }
  // Pre-scan template text so the Festivals tab always shows live imagery
  // (even outside seasonal windows) — top occasions present in the collection.
  const occasionFrequency = new Map<string, number>();
  for (const tpl of POSTER_TEMPLATES) {
    const text = `${tpl.occasionId || ''} ${tpl.headline || ''} ${tpl.name || ''}`.toLowerCase();
    if (!text.trim()) continue;
    let occasion = '';
    if (/diwali|deepavali/.test(text)) occasion = 'diwali';
    else if (/holi|gulal/.test(text)) occasion = 'holi';
    else if (/christmas|xmas/.test(text)) occasion = 'christmas';
    else if (/new year|nye/.test(text)) occasion = 'new_year';
    else if (/eid|mubarak/.test(text)) occasion = 'eid';
    else if (/navratri|durga|garba/.test(text)) occasion = 'navratri';
    else if (/dussehra|vijayadashami/.test(text)) occasion = 'dussehra';
    else if (/rakhi|raksha/.test(text)) occasion = 'rakhi';
    else if (/chhath/.test(text)) occasion = 'chhath_puja';
    else if (/independence|tiranga/.test(text)) occasion = 'independence_day';
    else if (/republic/.test(text)) occasion = 'republic_day';
    else if (/valentine|rose day/.test(text)) occasion = 'valentine';
    if (occasion) occasionFrequency.set(occasion, (occasionFrequency.get(occasion) || 0) + 1);
  }
  const templateOccasions = [...occasionFrequency.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([id]) => ({ id, label: id.replace(/_/g, ' ') }));
  // Seasonal occasions take priority slots; template occasions fill the rest.
  const uniqueOccasions = [
    ...new Map([...seasonalOccasions, ...templateOccasions].map((o) => [o.id, o])).values(),
  ].slice(0, 5);

  const [multiSourceVisuals, ...festivalVisualResults] = await Promise.all([
    getMultiSourceCategoryVisuals({
      industryText: effectiveCategoryText,
      requestedCount: POSTER_TEMPLATES.length + 40,
      userPhotos,
      tenantSeed: user.tenantId,
    }),
    ...uniqueOccasions.map((occasion) =>
      getFestivalVisuals(occasion.id, 40, user.tenantId).catch(() => [] as MultiSourceCreativeVisual[]),
    ),
  ]);
  const festivalVisualsByOccasion = new Map<string, MultiSourceCreativeVisual[]>();
  uniqueOccasions.forEach((occasion, i) => {
    const occasionVisuals = festivalVisualResults[i];
    if (Array.isArray(occasionVisuals) && occasionVisuals.length > 0) {
      festivalVisualsByOccasion.set(occasion.id, occasionVisuals);
    }
  });
  const festivalCursor = new Map<string, number>();

  const visuals = getCategoryVisualPool(effectiveCategoryText);
  const fallbackUnsplashPhotos =
    CURATED_SMB_IMAGE_REGISTRY[matchedIndustryKey] || CURATED_SMB_IMAGE_REGISTRY.generic_business;

  // Find business group in BUSINESS_GROUPS with word boundaries
  const groupNames = Object.keys(BUSINESS_GROUPS) as (keyof typeof BUSINESS_GROUPS)[];
  let matchedGroup: string = groupNames[0];
  for (const group of groupNames) {
    const pattern = BUSINESS_GROUPS[group]
      .split('|')
      .map((w) => w.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
      .filter(Boolean)
      .join('|');
    const rx = new RegExp(`\\b(${pattern})\\b`, 'i');
    if (rx.test(effectiveCategoryText)) {
      matchedGroup = group;
      break;
    }
  }

  // 3. Trade products & conflict adaptation engine
  const gbpCat = getGbpCategoryByNameOrAlias(effectiveCategoryText);
  const baseTradeProducts =
    gbpCat?.coreProducts && gbpCat.coreProducts.length > 0 ? gbpCat.coreProducts : [industry];
  const tradeProducts =
    realServiceNames.length > 0
      ? [...realServiceNames, ...baseTradeProducts]
      : baseTradeProducts;

  const isMerchantTrade = (word: string): boolean => {
    return new RegExp(`\\b(${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})\\b`, 'i').test(
      effectiveCategoryText,
    );
  };

  const conflictingTradesRegex =
    /\b(car wash|auto garage|bike repair|tyre shop|plumbing|plumber|electrician|ac repair|pest control|carpenter|plywood|timber|dentist|dental|teeth whitening|root canal|salon|haircut|hair spa|facial|manicure|sweet shop|mithai|halwai|software company|app development)\b/i;

  // 4. Adapt POSTER_TEMPLATES (270+ templates) with strict merchant trade relevance
  const allAdaptedPosterItems: BusinessTemplateResponseItem[] = POSTER_TEMPLATES.map((tpl, idx) => {
    const isFestival =
      tpl.category === 'festival' ||
      tpl.edition?.purpose === 'Festival' ||
      Boolean(tpl.occasionId) ||
      tpl.badge?.toLowerCase().includes('festival') ||
      /diwali|holi|eid|christmas|new year|independence|republic|rakhi|navratri|dussehra|chhath|valentine/i.test(
        tpl.headline || '',
      );

    let tab: 'for_business' | 'promotions' | 'festivals' | 'reviews' = 'for_business';
    let purpose: Purpose = 'Business profile';

    if (isFestival) {
      tab = 'festivals';
      purpose = 'Festival';
    } else if (tpl.category === 'sale_offer' || tpl.edition?.purpose === 'Promotion') {
      tab = 'promotions';
      purpose = 'Promotion';
    } else if (
      tpl.category === 'testimonial' ||
      tpl.category === 'quote' ||
      tpl.edition?.purpose === 'Trust-building'
    ) {
      tab = 'reviews';
      purpose = 'Trust-building';
    } else {
      tab = 'for_business';
      purpose = tpl.edition?.purpose || 'Business profile';
    }

    let headline = (tpl.headline || tpl.name)
      .replace(/\{businessName\}/g, businessName)
      .replace(/\{city\}/g, city);
    let subtitle = (tpl.subtitle || '')
      .replace(/\{businessName\}/g, businessName)
      .replace(/\{city\}/g, city);

    // Dynamically detect if template badge or industry belongs to an incompatible trade
    const isConflictingBadge = Boolean(
      tpl.badge &&
      !/^(featured|showcase|core service|special offer|5-star rated|top rated|limited offer|verified|exclusive)$/i.test(tpl.badge.trim()) &&
      normalizeCategoryContext(tpl.badge).verticalKey !== searchContext.verticalKey
    );

    const isConflictingIndustry = Boolean(
      tpl.industries && tpl.industries.length > 0 &&
      !tpl.industries.some((i) => /^(any|universal|none|all)$/i.test(i.trim())) &&
      !tpl.industries.some((i) => normalizeCategoryContext(i).verticalKey === searchContext.verticalKey)
    );

    if (!isFestival) {
      const match = headline.match(conflictingTradesRegex);
      if ((match && !isMerchantTrade(match[0])) || isConflictingBadge || isConflictingIndustry) {
        headline = tradeProducts[idx % tradeProducts.length];
      }
      const subMatch = subtitle.match(conflictingTradesRegex);
      if ((subMatch && !isMerchantTrade(subMatch[0])) || isConflictingBadge || isConflictingIndustry) {
        subtitle = `Certified ${industry} services in ${city}`;
      }
    }

    let assignedPhoto = tpl.photo;
    let photoSourceKey: string = 'curated';
    let photoCredit: string | undefined;
    if (isFestival) {
      const textToInspect = `${tpl.occasionId || ''} ${headline} ${tpl.name || ''}`.toLowerCase();
      let occasion = 'diwali';
      if (/holi|gulal/i.test(textToInspect)) occasion = 'holi';
      else if (/eid/i.test(textToInspect)) occasion = 'eid';
      else if (/christmas/i.test(textToInspect)) occasion = 'christmas';
      else if (/new year|nye/i.test(textToInspect)) occasion = 'new_year';
      else if (/independence/i.test(textToInspect)) occasion = 'independence_day';
      else if (/republic/i.test(textToInspect)) occasion = 'republic_day';
      else if (/rakhi/i.test(textToInspect)) occasion = 'rakhi';
      else if (/navratri|durga/i.test(textToInspect)) occasion = 'navratri';
      else if (/dussehra/i.test(textToInspect)) occasion = 'dussehra';
      else if (/chhath/i.test(textToInspect)) occasion = 'chhath_puja';
      else if (searchContext.isFestival && searchContext.detectedOccasion) {
        occasion = searchContext.detectedOccasion;
      }

      const dynamicFestival = festivalVisualsByOccasion.get(occasion);
      if (dynamicFestival && dynamicFestival.length > 0) {
          const festivalCounter = (festivalCursor.get(occasion) || 0) + 1;
          festivalCursor.set(occasion, festivalCounter);
          const festivalItem = dynamicFestival[(festivalCounter - 1) % dynamicFestival.length];
          assignedPhoto = festivalItem?.url || assignedPhoto;
          photoSourceKey = festivalItem?.source || 'curated';
          photoCredit = festivalItem?.credit;
        } else if (tpl.photo && tpl.photo.startsWith('/images/bgos/templates/')) {
          // No dynamic pool for this occasion yet — keep the evergreen local asset
          assignedPhoto = tpl.photo;
        } else {
          const festivalPhotos = FESTIVAL_VISUAL_POOL[occasion] || FESTIVAL_VISUAL_POOL.diwali;
          assignedPhoto = festivalPhotos[idx % festivalPhotos.length] || festivalPhotos[0];
        }
    } else {
      const multiSourceItem = multiSourceVisuals[idx % multiSourceVisuals.length];
      assignedPhoto =
        multiSourceItem?.url ||
        visuals[idx % visuals.length] ||
        fallbackUnsplashPhotos[idx % fallbackUnsplashPhotos.length] ||
        tpl.photo;
      photoSourceKey = multiSourceItem?.source || 'curated';
      photoCredit = multiSourceItem?.credit;
    }

    assignedPhoto = toAbsoluteUrl(assignedPhoto);

    let badge = tpl.badge || '';
    if (isConflictingBadge || !badge || badge.length > 20) {
      if (tab === 'promotions') badge = 'SPECIAL OFFER';
      else if (tab === 'festivals') badge = 'FESTIVAL SPECIAL';
      else if (tab === 'reviews') badge = '5-STAR RATED';
      else badge = 'CORE SERVICE';
    }

    const aspect = (tpl.aspect as '1:1' | '4:5' | '9:16') || '4:5';

    let composedDesign: any = null;
    if (includeDesign) {
      try {
        composedDesign = composeBusinessEdition({
          layout: String(tpl.layout || 'business_0'),
          ratio: aspect as any,
          brand: businessName,
          headline,
          subtitle,
          badge,
          cta: tpl.cta || 'Contact Us',
          phone,
          website: website ? website.replace(/^https?:\/\//, '') : undefined,
          logoUrl: logoUrl || undefined,
          photo: assignedPhoto,
          theme: (tpl.theme as any) || 'sand',
        });
      } catch {}
    }

    return {
      id: tpl.id,
      layout: String(tpl.layout || 'business_0'),
      name: tpl.name || headline,
      headline,
      subtitle,
      badge,
      cta: tpl.cta || 'Learn More',
      tab,
      purpose,
      theme: (tpl.theme as any) || 'sand',
      aspectRatio: aspect,
      photoUrl: assignedPhoto,
      photoSource: getCreativeSourceLabel(photoSourceKey),
      photoCredit,
      bgPrompt: tpl.bgPrompt || headline,
      occasionId: tpl.occasionId,
      design: composedDesign,
      targetKeywords: [
        { keyword: `${industry.toLowerCase()} company`, volume: 500 },
        { keyword: `${industry.toLowerCase()} in ${city}`, volume: 100 },
      ],
      estimatedViews: 45,
      defaultCaption: `${businessName} provides verified ${industry.toLowerCase()} in ${city}.\n\n#${industry.toLowerCase().replace(/[^a-z0-9]/g, '')} #${city.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
    };
  });

  // Filter aspect ratio if requested
  let filteredPosterItems = allAdaptedPosterItems;
  if (requestedAspect && ['1:1', '4:5', '9:16'].includes(requestedAspect)) {
    filteredPosterItems = filteredPosterItems.filter((tpl) => tpl.aspectRatio === requestedAspect);
  }

  // Filter search query if requested
  if (searchQuery.trim()) {
    const qTokens = searchQuery.toLowerCase().split(/\s+/).filter(Boolean);
    const matched = filteredPosterItems.filter((tpl) => {
      const text = `${tpl.headline} ${tpl.subtitle} ${tpl.name} ${tpl.badge}`.toLowerCase();
      return qTokens.some((tok) => text.includes(tok));
    });
    if (matched.length > 0) {
      filteredPosterItems = matched;
    }
  }

  // 3b. Synthesize First-Class Category Blueprints (Tailored specifically to the GBP trade & real services)
  const categoryBlueprints = generateCategoryBlueprints({
    categoryOrTitle: effectiveCategoryText,
    businessName,
    city,
    phone,
    realServices: realServiceNames,
  });

  const blueprintResponseItems: BusinessTemplateResponseItem[] = categoryBlueprints
    .filter((bp) => {
      if (requestedAspect && ['1:1', '4:5', '9:16'].includes(requestedAspect)) {
        if (bp.aspect !== requestedAspect) return false;
      }
      if (requestedTab === 'all') return true;
      return bp.tab === requestedTab;
    })
    .map((bp, bpIdx) => {
      const msVisual = multiSourceVisuals[bpIdx % multiSourceVisuals.length];
      const photoUrl = toAbsoluteUrl(msVisual?.url || bp.photoUrl);
      let composedDesign: any = null;
      if (includeDesign) {
        try {
          const fallbackLayout = String(BUSINESS_EDITIONS[0]?.layout || 'business_0');
          composedDesign = composeBusinessEdition({
            layout: fallbackLayout,
            ratio: '4:5',
            brand: businessName,
            headline: bp.headline,
            subtitle: bp.subtitle,
            badge: bp.badge,
            cta: bp.cta,
            phone,
            website: website ? website.replace(/^https?:\/\//, '') : undefined,
            logoUrl: logoUrl || undefined,
            photo: photoUrl,
            theme: bp.theme as any,
          });
        } catch {}
      }

      return {
        id: bp.id,
        layout: bp.layout,
        name: bp.headline,
        headline: bp.headline,
        subtitle: bp.subtitle,
        badge: bp.badge,
        cta: bp.cta,
        tab: bp.tab,
        purpose: bp.purpose,
        theme: bp.theme,
        aspectRatio: '4:5',
        photoUrl,
        photoSource: getCreativeSourceLabel(msVisual?.source),
        photoCredit: msVisual?.credit,
        bgPrompt: bp.headline,
        design: composedDesign,
        defaultBullets: bp.bullets,
        targetKeywords: bp.targetKeywords,
        estimatedViews: 90,
        defaultCaption: bp.defaultCaption,
      };
    });

  // 3c. Fetch curated trade references
  const curatedList = getCuratedTemplatesForBusiness({
    categoryOrTitle: effectiveCategoryText,
    limit: 25,
  });

  let filteredCuratedList = curatedList;
  if (searchQuery.trim()) {
    const qTokens = searchQuery.toLowerCase().split(/\s+/).filter(Boolean);
    const matchedCurated = curatedList.filter((tpl) => {
      const text = `${tpl.title} ${tpl.headlinePattern} ${tpl.subtitle || ''} ${tpl.categoryId} ${(tpl.targetKeywords || []).map((k) => k.keyword).join(' ')}`.toLowerCase();
      return qTokens.some((tok) => text.includes(tok));
    });
    if (matchedCurated.length > 0) {
      filteredCuratedList = matchedCurated;
    }
  }

  const curatedResponseItems: BusinessTemplateResponseItem[] = filteredCuratedList
    .filter((tpl) => {
      if (requestedAspect && ['1:1', '4:5', '9:16'].includes(requestedAspect)) {
        if (tpl.aspectRatio !== requestedAspect) return false;
      }
      if (requestedTab === 'all') return true;
      if (requestedTab === 'promotions') return tpl.bucketKey === 'special_offers';
      if (requestedTab === 'festivals') return tpl.bucketKey === 'festivals';
      if (requestedTab === 'reviews') return tpl.bucketKey === 'new_highlights';
      if (requestedTab === 'for_business') return tpl.bucketKey === 'services_products';
      return true;
    })
    .map((tpl) => {
      const formattedHeadline = tpl.headlinePattern
        .replace(/\{businessName\}/g, businessName)
        .replace(/\{city\}/g, city);
      const formattedCaption = tpl.defaultCaption
        .replace(/\{businessName\}/g, businessName)
        .replace(/\{city\}/g, city);

      const tab =
        tpl.bucketKey === 'special_offers'
          ? 'promotions'
          : tpl.bucketKey === 'festivals'
            ? 'festivals'
            : tpl.bucketKey === 'new_highlights'
              ? 'reviews'
              : 'for_business';

      // Hydrate festival curated references from the dynamic festival pools
      let photoUrl = toAbsoluteUrl(tpl.referenceUrl);
      let photoSource: string = 'Curated';
      let photoCredit: string | undefined;
      if (tab === 'festivals') {
        const festText = `${tpl.title} ${tpl.headlinePattern} ${tpl.categoryId}`.toLowerCase();
        let festOccasion = '';
        if (/diwali|deepavali/.test(festText)) festOccasion = 'diwali';
        else if (/holi|gulal/.test(festText)) festOccasion = 'holi';
        else if (/christmas|xmas/.test(festText)) festOccasion = 'christmas';
        else if (/new year|nye/.test(festText)) festOccasion = 'new_year';
        else if (/eid|mubarak/.test(festText)) festOccasion = 'eid';
        else if (/navratri|durga/.test(festText)) festOccasion = 'navratri';
        else if (/rakhi|raksha/.test(festText)) festOccasion = 'rakhi';
        else if (/valentine/.test(festText)) festOccasion = 'valentine';
        else if (/independence|republic/.test(festText)) festOccasion = 'independence_day';
        const curatedFestivalPool = festOccasion
          ? festivalVisualsByOccasion.get(festOccasion)
          : undefined;
        if (curatedFestivalPool && curatedFestivalPool.length > 0) {
          const festivalCounter = (festivalCursor.get(festOccasion) || 0) + 1;
          festivalCursor.set(festOccasion, festivalCounter);
          const festivalItem = curatedFestivalPool[(festivalCounter - 1) % curatedFestivalPool.length];
          if (festivalItem?.url) {
            photoUrl = toAbsoluteUrl(festivalItem.url);
            photoSource = getCreativeSourceLabel(festivalItem.source);
            photoCredit = festivalItem.credit;
          }
        }
      }
      let composedCuratedDesign: any = null;
      if (includeDesign) {
        try {
          const fallbackLayout = String(BUSINESS_EDITIONS[0]?.layout || 'business_0');
          composedCuratedDesign = composeBusinessEdition({
            layout: fallbackLayout,
            ratio: (tpl.aspectRatio as any) || '4:5',
            brand: businessName,
            headline: formattedHeadline,
            subtitle: tpl.subtitle,
            badge:
              tpl.bucketKey === 'special_offers'
                ? 'Special Offer'
                : tpl.bucketKey === 'festivals'
                  ? 'Festival'
                  : 'Featured',
            cta: tpl.ctaText,
            phone,
            website: website ? website.replace(/^https?:\/\//, '') : undefined,
            logoUrl: logoUrl || undefined,
            photo: photoUrl,
            theme: 'emerald',
          });
        } catch {}
      }

      return {
        id: tpl.id,
        layout: 'curated_commercial',
        name: tpl.title,
        headline: formattedHeadline,
        subtitle: tpl.subtitle,
        badge:
          tpl.bucketKey === 'special_offers'
            ? 'Special Offer'
            : tpl.bucketKey === 'festivals'
              ? 'Festival'
              : 'Featured',
        cta: tpl.ctaText,
        tab,
        purpose: (tpl.bucketKey === 'special_offers'
          ? 'Promotion'
          : tpl.bucketKey === 'festivals'
            ? 'Festival'
            : 'Business profile') as Purpose,
        theme: 'emerald',
        aspectRatio: tpl.aspectRatio,
        photoUrl,
        photoSource,
        photoCredit,
        bgPrompt: tpl.title,
        design: composedCuratedDesign,
        defaultBullets: tpl.defaultBullets,
        targetKeywords: tpl.targetKeywords,
        estimatedViews: tpl.estimatedViews,
        defaultCaption: formattedCaption,
      };
    });

  // Group all collections by tab with priority sorting for trade matches
  const isTradeMatch = (item: BusinessTemplateResponseItem): boolean => {
    return isMerchantTrade(item.name) || isMerchantTrade(item.headline);
  };

  const adaptedForBusiness = filteredPosterItems
    .filter((t) => t.tab === 'for_business')
    .sort((a, b) => Number(isTradeMatch(b)) - Number(isTradeMatch(a)));

  const forBusinessTemplates: BusinessTemplateResponseItem[] = [
    ...blueprintResponseItems.filter((bp) => bp.tab === 'for_business'),
    ...curatedResponseItems.filter((cr) => cr.tab === 'for_business'),
    ...adaptedForBusiness,
  ];

  const promotionsTemplates: BusinessTemplateResponseItem[] = [
    ...blueprintResponseItems.filter((bp) => bp.tab === 'promotions'),
    ...curatedResponseItems.filter((cr) => cr.tab === 'promotions'),
    ...filteredPosterItems.filter((t) => t.tab === 'promotions'),
  ];

  const festivalsTemplates: BusinessTemplateResponseItem[] = [
    ...blueprintResponseItems.filter((bp) => bp.tab === 'festivals'),
    ...curatedResponseItems.filter((cr) => cr.tab === 'festivals'),
    ...filteredPosterItems.filter((t) => t.tab === 'festivals'),
  ];

  const reviewsTemplates: BusinessTemplateResponseItem[] = [
    ...blueprintResponseItems.filter((bp) => bp.tab === 'reviews'),
    ...curatedResponseItems.filter((cr) => cr.tab === 'reviews'),
    ...filteredPosterItems.filter((t) => t.tab === 'reviews'),
  ];

  let selectedTemplates: BusinessTemplateResponseItem[] = [];

  if (requestedTab === 'for_business') {
    selectedTemplates = forBusinessTemplates.slice(0, limit);
  } else if (requestedTab === 'promotions') {
    selectedTemplates = promotionsTemplates.slice(0, limit);
  } else if (requestedTab === 'festivals') {
    selectedTemplates = festivalsTemplates.slice(0, limit);
  } else if (requestedTab === 'reviews') {
    selectedTemplates = reviewsTemplates.slice(0, limit);
  } else {
    // 'all': Balanced presentation across categories
    const perCategory = Math.max(10, Math.floor(limit / 4));
    selectedTemplates = [
      ...forBusinessTemplates.slice(0, perCategory),
      ...promotionsTemplates.slice(0, perCategory),
      ...festivalsTemplates.slice(0, perCategory),
      ...reviewsTemplates.slice(0, perCategory),
    ].slice(0, limit);
  }

  return NextResponse.json({
    businessContext: {
      name: businessName,
      industry,
      matchedGroup,
      matchedIndustryKey,
      phone,
      website,
      logoUrl,
      address,
      city,
    },
    counts: {
      total:
        forBusinessTemplates.length +
        promotionsTemplates.length +
        festivalsTemplates.length +
        reviewsTemplates.length,
      for_business: forBusinessTemplates.length,
      promotions: promotionsTemplates.length,
      festivals: festivalsTemplates.length,
      reviews: reviewsTemplates.length,
    },
    buckets: TEMPLATE_BUCKETS,
    templates: selectedTemplates,
  });
}
