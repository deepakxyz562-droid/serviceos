'use client';

import React, { useState } from 'react';
import { UniversalProject } from '@/lib/forms/universal-component-types';
import { qrSvgMarkup } from '@/lib/qr-svg';
import {
  Share2,
  Globe,
  Smartphone,
  Copy,
  Check,
  QrCode,
  ExternalLink,
  Code,
  Sparkles,
  Phone,
  Download,
  Printer,
  Lock,
  Eye,
  ShieldAlert,
  Layers,
  Send,
  ArrowRight,
  CheckCircle2,
  Sliders,
  EyeOff,
  Monitor,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export interface UniversalPublishCenterProps {
  project?: UniversalProject;
  formId?: string;
  formSlug?: string;
  formName?: string;
  formDescription?: string;
  privacyLevel?: 'public' | 'private' | 'password';
  onPrivacyChange?: (level: 'public' | 'private' | 'password') => void;
  siteOrigin?: string;
}

export function UniversalPublishCenter({
  project,
  formId,
  formSlug: propFormSlug,
  formName: propFormName,
  privacyLevel = 'public',
  onPrivacyChange,
  siteOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://fieseros.com',
}: UniversalPublishCenterProps) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activePreset, setActivePreset] = useState<'card' | 'flyer' | 'truck' | 'counter' | 'social'>('flyer');

  const rawFormSlug =
    propFormSlug ||
    project?.forms?.[0]?.slug ||
    project?.slug ||
    formId ||
    (propFormName ? propFormName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') : '') ||
    'service-request';

  const resolvedFormSlug =
    typeof rawFormSlug === 'string'
      ? rawFormSlug.replace(/^-+|-+$/g, '') || formId || 'service-request'
      : formId || 'service-request';

  const resolvedFormName =
    propFormName ||
    project?.forms?.[0]?.name ||
    project?.name ||
    'Service Request Form';

  const formUrl = `${siteOrigin}/f/${resolvedFormSlug}`;
  const mobileModeUrl = `${siteOrigin}/f/${resolvedFormSlug}?mode=mobile`;

  const [embedTransparent, setEmbedTransparent] = useState(false);
  const [embedHideHeader, setEmbedHideHeader] = useState(false);
  const [embedAutoResize, setEmbedAutoResize] = useState(true);
  const [embedPlatform, setEmbedPlatform] = useState<'iframe' | 'wordpress' | 'shopify' | 'webflow' | 'react'>('iframe');
  const [showEmbedPreview, setShowEmbedPreview] = useState(false);

  const embedParams = new URLSearchParams();
  embedParams.set('embed', '1');
  if (embedTransparent) embedParams.set('transparent', '1');
  if (embedHideHeader) embedParams.set('hideHeader', '1');
  const embedQueryString = embedParams.toString() ? `?${embedParams.toString()}` : '';
  const canonicalEmbedUrl = `${siteOrigin}/form/${formId || resolvedFormSlug}${embedQueryString}`;
  const iframeId = `fieseros-form-${(resolvedFormSlug || 'embed').replace(/[^a-z0-9_-]/gi, '')}`;

  const platformSnippets: Record<'iframe' | 'wordpress' | 'shopify' | 'webflow' | 'react', { code: string; label: string; tip: string }> = {
    iframe: {
      label: 'Standard iFrame (Universal)',
      tip: 'Paste this snippet directly into any HTML page where you want the form to appear.',
      code: `<iframe \n  id="${iframeId}"\n  src="${canonicalEmbedUrl}" \n  width="100%" \n  height="650" \n  frameborder="0" \n  style="border: none; width: 100%; transition: height 0.2s ease; background: ${embedTransparent ? 'transparent' : '#ffffff'};"\n  allow="camera; microphone; clipboard-write"\n  loading="lazy">\n</iframe>${embedAutoResize ? `\n<script>\n  window.addEventListener('message', function(e) {\n    if (e.data && e.data.type === 'FIESEROS_FORM_RESIZE' && e.data.height) {\n      var el = document.getElementById('${iframeId}');\n      if (el) el.style.height = e.data.height + 'px';\n    }\n  });\n</script>` : ''}`,
    },
    wordpress: {
      label: 'WordPress (Gutenberg / Elementor)',
      tip: 'In Gutenberg, add a "Custom HTML" block. In Elementor, use the "HTML Code" widget and paste this code.',
      code: `<!-- Fieseros Form Embed for WordPress -->\n<div class="fieseros-form-wrapper" style="width: 100%; max-width: 800px; margin: 0 auto;">\n  <iframe \n    id="${iframeId}"\n    src="${canonicalEmbedUrl}" \n    width="100%" \n    height="650" \n    frameborder="0" \n    style="border: none; width: 100%; min-height: 480px; transition: height 0.2s ease; background: ${embedTransparent ? 'transparent' : '#ffffff'};"\n    allow="camera; microphone; clipboard-write">\n  </iframe>\n  <script>\n    window.addEventListener('message', function(e) {\n      if (e.data && e.data.type === 'FIESEROS_FORM_RESIZE' && e.data.height) {\n        var el = document.getElementById('${iframeId}');\n        if (el) el.style.height = e.data.height + 'px';\n      }\n    });\n  </script>\n</div>`,
    },
    shopify: {
      label: 'Shopify Store (Liquid)',
      tip: 'In Shopify Theme Editor, click "Add section" -> "Custom Liquid" or "Custom HTML", then paste this snippet.',
      code: `<!-- Fieseros Form Shopify Liquid Block -->\n<div class="shopify-fieseros-form" style="width: 100%; padding: 20px 0;">\n  <iframe \n    id="${iframeId}"\n    src="${canonicalEmbedUrl}" \n    width="100%" \n    height="650" \n    frameborder="0" \n    style="border: none; width: 100%; background: ${embedTransparent ? 'transparent' : '#ffffff'};"\n    allow="camera; microphone; clipboard-write">\n  </iframe>\n  <script>\n    window.addEventListener('message', function(e) {\n      if (e.data && e.data.type === 'FIESEROS_FORM_RESIZE' && e.data.height) {\n        var el = document.getElementById('${iframeId}');\n        if (el) el.style.height = e.data.height + 'px';\n      }\n    });\n  </script>\n</div>`,
    },
    webflow: {
      label: 'Webflow',
      tip: 'In Webflow Designer, press "A" -> Components -> Drag "Embed" element onto your page, paste code, and save.',
      code: `<!-- Fieseros Form Webflow Embed -->\n<iframe \n  id="${iframeId}"\n  src="${canonicalEmbedUrl}" \n  width="100%" \n  height="650" \n  frameborder="0" \n  style="border: none; width: 100%; background: ${embedTransparent ? 'transparent' : '#ffffff'};"\n  allow="camera; microphone; clipboard-write">\n</iframe>\n<script>\n  window.addEventListener('message', function(e) {\n    if (e.data && e.data.type === 'FIESEROS_FORM_RESIZE' && e.data.height) {\n      var el = document.getElementById('${iframeId}');\n      if (el) el.style.height = e.data.height + 'px';\n    }\n  });\n</script>`,
    },
    react: {
      label: 'React / Next.js Component',
      tip: 'Copy this component directly into your React/Next.js codebase for responsive auto-resizing form embedding.',
      code: `import React, { useEffect, useRef } from 'react';\n\nexport function ${(resolvedFormName || 'Service').replace(/[^a-zA-Z0-9]/g, '')}FormEmbed() {\n  const iframeRef = useRef<HTMLIFrameElement>(null);\n\n  useEffect(() => {\n    const handleMessage = (e: MessageEvent) => {\n      if (e.data?.type === 'FIESEROS_FORM_RESIZE' && e.data.height && iframeRef.current) {\n        iframeRef.current.style.height = e.data.height + 'px';\n      }\n    };\n    window.addEventListener('message', handleMessage);\n    return () => window.removeEventListener('message', handleMessage);\n  }, []);\n\n  return (\n    <iframe\n      ref={iframeRef}\n      src="${canonicalEmbedUrl}"\n      width="100%"\n      height="650"\n      frameBorder="0"\n      style={{\n        border: 'none',\n        width: '100%',\n        transition: 'height 0.2s ease',\n        background: '${embedTransparent ? 'transparent' : '#ffffff'}',\n      }}\n      allow="camera; microphone; clipboard-write"\n      loading="lazy"\n    />\n  );\n}`,
    },
  };

  const inlineEmbedCode = platformSnippets[embedPlatform].code;



  // QR generated fully on-device — the form URL never leaves the browser.
  const formQrSvg = qrSvgMarkup(formUrl);

  const copyText = (text: string, key: string, label = 'Content') => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
    toast.success(`${label} copied to clipboard!`);
  };

  const handlePrintQR = () => {
    const win = window.open('', '_blank');
    if (!win) return;
    win.document.write(`
      <html>
        <head>
          <title>Scan to Open Form - ${resolvedFormName}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; text-align: center; padding: 40px; }
            h1 { font-size: 24px; margin-bottom: 8px; }
            p { color: #64748b; font-size: 14px; margin-bottom: 24px; }
            .qr-box { width: 260px; height: 260px; border-radius: 12px; margin: 0 auto; }
            .badge { display: inline-block; background: #ecfdf5; color: #047857; padding: 6px 14px; border-radius: 9999px; font-weight: 600; font-size: 12px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <h1>${resolvedFormName}</h1>
          <p>Scan the QR code below on your mobile phone to fill out this form</p>
          <div class="qr-box">${formQrSvg}</div>
          <br/>
          <div class="badge">Powered by Fieseros GPTForm</div>
          <script>window.onload = function() { window.print(); }</script>
        </body>
      </html>
    `);
    win.document.close();
  };

  return (
    <div className="w-full max-w-5xl mx-auto p-2 sm:p-6 space-y-6 font-sans">
      {/* ─── HEADER ─── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border/70 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-foreground flex items-center gap-2">
            <Share2 className="size-6 text-emerald-600" />
            Publish &amp; Share
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
            <strong className="text-foreground">One form. Anywhere your customers are.</strong> — Share the form by link, embed it on your website, launch the mobile experience, or print a QR code. AI Agent deployment is managed separately.
          </p>
        </div>
        <Badge variant="outline" className="bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-[11px] font-bold self-start sm:self-center py-1 px-3">
          ● Published &amp; Live
        </Badge>
      </div>

      {/* ─── 5-PILLAR PUBLISHING TABS ─── */}
      <Tabs defaultValue="share" className="w-full space-y-6">
        <TabsList className="grid grid-cols-2 sm:grid-cols-4 h-auto p-1.5 bg-muted/60 rounded-2xl gap-1 border border-border/60">
          <TabsTrigger value="share" className="rounded-xl py-2 text-xs font-bold gap-1.5 data-[state=active]:bg-background data-[state=active]:shadow-xs">
            <Globe className="size-3.5 text-blue-500" />
            <span>1. Share Link</span>
          </TabsTrigger>
          <TabsTrigger value="embed" className="rounded-xl py-2 text-xs font-bold gap-1.5 data-[state=active]:bg-background data-[state=active]:shadow-xs">
            <Code className="size-3.5 text-indigo-500" />
            <span>2. Embed</span>
          </TabsTrigger>
          <TabsTrigger value="mobile" className="rounded-xl py-2 text-xs font-bold gap-1.5 data-[state=active]:bg-background data-[state=active]:shadow-xs">
            <Smartphone className="size-3.5 text-purple-500" />
            <span>3. Mobile</span>
          </TabsTrigger>
          <TabsTrigger value="qr" className="rounded-xl py-2 text-xs font-bold gap-1.5 data-[state=active]:bg-background data-[state=active]:shadow-xs">
            <QrCode className="size-3.5 text-amber-500" />
            <span>4. QR Code</span>
          </TabsTrigger>
        </TabsList>

        {/* ─── TAB 1: DIRECT LINK ─── */}
        <TabsContent value="share" className="space-y-4">
          <Card className="rounded-2xl border-border/80 shadow-xs bg-gradient-to-b from-card to-blue-500/5">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-bold flex items-center gap-2">
                  <Globe className="size-4 text-blue-600" />
                  Direct Public Link
                </CardTitle>
                {onPrivacyChange && (
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-muted-foreground">Access:</span>
                    <Select value={privacyLevel} onValueChange={(v: any) => onPrivacyChange(v)}>
                      <SelectTrigger className="h-7 text-[11px] font-semibold bg-background rounded-lg px-2 border-border/80">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public" className="text-xs">🌐 Public</SelectItem>
                        <SelectItem value="password" className="text-xs">🔑 Password Protected</SelectItem>
                        <SelectItem value="private" className="text-xs">🔒 Private</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
              <CardDescription className="text-xs">
                Your form is hosted on a high-speed edge CDN and ready to share with customers anywhere.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  value={formUrl}
                  readOnly
                  className="h-10 text-xs font-mono bg-background select-all border-border/80"
                />
                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    size="sm"
                    onClick={() => copyText(formUrl, 'direct_link', 'Direct Form URL')}
                    className="h-10 gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 rounded-xl shadow-xs cursor-pointer"
                  >
                    {copiedKey === 'direct_link' ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
                    Copy Link
                  </Button>
                  <a
                    href={formUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center h-10 px-3 text-xs font-semibold rounded-xl border border-border/80 bg-background hover:bg-muted text-foreground gap-1.5"
                  >
                    <span>Open</span>
                    <ExternalLink className="size-3.5 text-blue-600" />
                  </a>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3 bg-muted/40 rounded-xl border border-border/60 space-y-1">
                  <p className="text-[11px] font-bold text-foreground flex items-center gap-1.5">
                    <CheckCircle2 className="size-3.5 text-emerald-500" /> SSL Encrypted
                  </p>
                  <p className="text-[10px] text-muted-foreground">End-to-end 256-bit encryption on all form submissions.</p>
                </div>
                <div className="p-3 bg-muted/40 rounded-xl border border-border/60 space-y-1">
                  <p className="text-[11px] font-bold text-foreground flex items-center gap-1.5">
                    <CheckCircle2 className="size-3.5 text-emerald-500" /> Real-Time Sync
                  </p>
                  <p className="text-[10px] text-muted-foreground">Form edits in the studio take effect instantly on this link.</p>
                </div>
                <div className="p-3 bg-muted/40 rounded-xl border border-border/60 space-y-1">
                  <p className="text-[11px] font-bold text-foreground flex items-center gap-1.5">
                    <CheckCircle2 className="size-3.5 text-emerald-500" /> Multi-Device
                  </p>
                  <p className="text-[10px] text-muted-foreground">Adapts seamlessly to phones, tablets, and desktop browsers.</p>
                </div>
              </div>

              {/* Social / WhatsApp Unfurl Card Preview */}
              <div className="pt-2">
                <div className="p-3 bg-muted/20 border border-border/70 rounded-xl space-y-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                    <Share2 className="size-3 text-blue-500" /> Social &amp; Messaging Card Preview (WhatsApp, iMessage, LinkedIn)
                  </span>
                  <div className="p-3 bg-card border border-border/80 rounded-lg shadow-2xs flex items-center gap-3">
                    <div className="size-12 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-500/20 font-black text-sm">
                      📝
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">fieseros.com/f</span>
                        <span className="text-[10px] text-muted-foreground">• SSL Verified</span>
                      </div>
                      <p className="text-xs font-bold text-foreground truncate">{resolvedFormName}</p>
                      <p className="text-[11px] text-muted-foreground truncate">
                        Fill out and submit this official online form securely on any phone or computer.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── TAB 2: EMBED ON WEBSITE ─── */}
        <TabsContent value="embed" className="space-y-4">
          {/* Embed Customization Bar */}
          <Card className="rounded-2xl border-border/80 shadow-xs bg-muted/20">
            <CardHeader className="p-4 pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xs font-bold flex items-center gap-1.5 text-foreground">
                  <Sliders className="size-3.5 text-indigo-600" />
                  Embed Options &amp; Customization
                </CardTitle>
                <Badge variant="outline" className="text-[10px] bg-background font-mono">
                  Live Parameters
                </Badge>
              </div>
              <CardDescription className="text-[11px]">
                Configure how your embedded form renders inside your host website.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-4 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Toggle 1: Auto-Resize */}
                <div className="flex items-center justify-between p-3 rounded-xl border border-border/70 bg-background shadow-2xs">
                  <div className="space-y-0.5 pr-2">
                    <p className="text-xs font-bold text-foreground">Auto-Resize Height</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">
                      Dynamically matches questions to prevent double scrollbars.
                    </p>
                  </div>
                  <Switch
                    checked={embedAutoResize}
                    onCheckedChange={setEmbedAutoResize}
                  />
                </div>

                {/* Toggle 2: Transparent */}
                <div className="flex items-center justify-between p-3 rounded-xl border border-border/70 bg-background shadow-2xs">
                  <div className="space-y-0.5 pr-2">
                    <p className="text-xs font-bold text-foreground">Transparent BG</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">
                      Blends seamlessly into your website&apos;s custom background.
                    </p>
                  </div>
                  <Switch
                    checked={embedTransparent}
                    onCheckedChange={setEmbedTransparent}
                  />
                </div>

                {/* Toggle 3: Hide Header */}
                <div className="flex items-center justify-between p-3 rounded-xl border border-border/70 bg-background shadow-2xs">
                  <div className="space-y-0.5 pr-2">
                    <p className="text-xs font-bold text-foreground">Hide Form Header</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">
                      Omits internal title when your site already has an H1 heading.
                    </p>
                  </div>
                  <Switch
                    checked={embedHideHeader}
                    onCheckedChange={setEmbedHideHeader}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Platform Snippet Selector */}
          <Card className="rounded-2xl border-border/80 shadow-xs">
            <CardHeader className="p-4 pb-2 border-b border-border/60">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <CardTitle className="text-xs font-bold flex items-center gap-1.5 text-foreground">
                    <Code className="size-3.5 text-indigo-600" />
                    Platform-Specific Integration Snippet
                  </CardTitle>
                  <CardDescription className="text-[11px] mt-0.5">
                    {platformSnippets[embedPlatform].tip}
                  </CardDescription>
                </div>

                {/* Platform Switcher Buttons */}
                <div className="flex flex-wrap gap-1 bg-muted/60 p-1 rounded-xl border border-border/60">
                  {(
                    [
                      { id: 'iframe', label: 'HTML iFrame' },
                      { id: 'wordpress', label: 'WordPress' },
                      { id: 'shopify', label: 'Shopify' },
                      { id: 'webflow', label: 'Webflow' },
                      { id: 'react', label: 'React / Next.js' },
                    ] as const
                  ).map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setEmbedPlatform(p.id)}
                      className={cn(
                        'px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer',
                        embedPlatform === p.id
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-muted-foreground hover:text-foreground hover:bg-background/80'
                      )}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-4 space-y-3">
              {/* Code Box */}
              <div className="relative rounded-xl overflow-hidden border border-border/80 bg-slate-950 text-slate-100 font-mono text-[11px]">
                <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-800 text-[10px] text-slate-400">
                  <span>{platformSnippets[embedPlatform].label}</span>
                  <span className="text-emerald-400 font-bold">● CSP-Ready (frame-ancestors: *)</span>
                </div>
                <textarea
                  readOnly
                  rows={8}
                  value={inlineEmbedCode}
                  className="w-full p-3 bg-transparent text-slate-200 select-all resize-none focus:outline-hidden leading-relaxed"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <Button
                    size="sm"
                    onClick={() => copyText(inlineEmbedCode, 'inline_embed', `${platformSnippets[embedPlatform].label} Code`)}
                    className="gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl h-9 px-4 cursor-pointer shadow-xs"
                  >
                    {copiedKey === 'inline_embed' ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
                    Copy Snippet
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowEmbedPreview(!showEmbedPreview)}
                    className="gap-1.5 text-xs font-semibold rounded-xl h-9 px-3 cursor-pointer"
                  >
                    <Monitor className="size-3.5 text-indigo-600" />
                    <span>{showEmbedPreview ? 'Hide Live Preview' : 'Test Live Embed'}</span>
                  </Button>
                </div>

                <span className="text-[10px] text-muted-foreground">
                  Works on WordPress, Shopify, Webflow, Squarespace, Wix &amp; Custom domains.
                </span>
              </div>

              {/* Live Interactive Embed Preview */}
              {showEmbedPreview && (
                <div className="mt-4 p-4 rounded-2xl border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/30 dark:bg-indigo-950/20 space-y-3 animate-in fade-in duration-300">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-indigo-950 dark:text-indigo-200 flex items-center gap-1.5">
                      <Monitor className="size-4 text-indigo-600" /> Live Embed Preview Container
                    </span>
                    <Badge variant="outline" className="text-[10px] bg-background">
                      Simulated Host Page
                    </Badge>
                  </div>
                  <div className="w-full rounded-xl border border-border/80 bg-background overflow-hidden shadow-xs min-h-[420px] p-2">
                    <iframe
                      id={`${iframeId}-preview`}
                      src={canonicalEmbedUrl}
                      width="100%"
                      height="500"
                      className="w-full border-none rounded-lg"
                      title="Form Embed Live Preview"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── TAB 3: MOBILE EXPERIENCE ─── */}
        <TabsContent value="mobile" className="space-y-4">
          <Card className="rounded-2xl border-border/80 shadow-xs bg-gradient-to-b from-card to-purple-500/5">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-sm font-bold flex items-center gap-2">
                    <Smartphone className="size-4 text-purple-600" />
                    Mobile Experience
                  </CardTitle>
                  <CardDescription className="text-xs mt-0.5">
                    Give your customers a mobile-friendly, app-like experience from any smartphone.
                  </CardDescription>
                </div>
                <Badge variant="outline" className="bg-purple-50 text-purple-700 dark:bg-purple-950/60 border-purple-200 text-[10px] font-bold">
                  No App Store Required
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-200/60 dark:border-purple-900/40 space-y-2">
                <p className="text-xs font-bold text-purple-950 dark:text-purple-200">
                  📱 Zero-Friction Mobile Installation
                </p>
                <p className="text-xs text-purple-900/80 dark:text-purple-300">
                  Customers can add this form directly to their iOS or Android home screen in 1 click as an installable Web App (PWA). No app store downloads, updates, or account friction required.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  value={mobileModeUrl}
                  readOnly
                  className="h-10 text-xs font-mono bg-background select-all border-border/80"
                />
                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    size="sm"
                    onClick={() => copyText(mobileModeUrl, 'mobile_link', 'Mobile Link')}
                    className="h-10 gap-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold px-4 rounded-xl shadow-xs"
                  >
                    {copiedKey === 'mobile_link' ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
                    Copy Mobile Link
                  </Button>
                  <a
                    href={mobileModeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center h-10 px-3 text-xs font-semibold rounded-xl border border-border/80 bg-background hover:bg-muted text-foreground gap-1.5"
                  >
                    <span>Open Preview</span>
                    <ExternalLink className="size-3.5 text-purple-600" />
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── TAB 5: QR CODE GENERATOR ─── */}
        <TabsContent value="qr" className="space-y-4">
          <Card className="rounded-2xl border-border/80 shadow-xs">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <QrCode className="size-4 text-amber-600" />
                QR Code &amp; Print Presets
              </CardTitle>
              <CardDescription className="text-xs">
                Generate high-resolution QR codes to put on trucks, business cards, flyers, and job sites.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row items-center gap-6 p-4 bg-muted/30 rounded-2xl border border-border/60">
                {/* Live QR Image */}
                <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 shrink-0 text-center space-y-2">
                  {/* Safe to inline: markup is generated entirely by our local
                      encoder — no user-controlled attributes. */}
                  <div
                    className="size-48 rounded-lg mx-auto"
                    role="img"
                    aria-label="Form QR Code"
                    dangerouslySetInnerHTML={{ __html: formQrSvg ?? '' }}
                  />
                  <p className="text-[10px] font-mono text-slate-500">Scan to open form</p>
                </div>

                {/* Print Presets & Actions */}
                <div className="flex-1 space-y-4 w-full">
                  <div>
                    <label className="text-xs font-bold text-foreground uppercase tracking-wider">
                      Print &amp; Placement Presets
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                      {[
                        { id: 'card', label: '📇 Business Card', sub: 'Compact QR' },
                        { id: 'flyer', label: '📄 Marketing Flyer', sub: 'High-Res' },
                        { id: 'truck', label: '🚚 Vehicle Decal', sub: 'Large scale' },
                        { id: 'counter', label: '🏪 Countertop Stand', sub: 'Storefront' },
                        { id: 'social', label: '📱 Social Media', sub: 'Square post' },
                      ].map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => setActivePreset(preset.id as any)}
                          className={`p-2.5 rounded-xl border text-left transition-all text-xs font-semibold ${
                            activePreset === preset.id
                              ? 'bg-amber-500/15 border-amber-500 text-amber-900 dark:text-amber-200'
                              : 'bg-background border-border/70 hover:border-border text-muted-foreground'
                          }`}
                        >
                          <div>{preset.label}</div>
                          <div className="text-[10px] font-normal opacity-80">{preset.sub}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-2">
                    <Button
                      size="sm"
                      onClick={() => {
                        // Rasterize the local SVG to a real PNG on-device.
                        if (!formQrSvg) {
                          toast.error('Could not encode this form URL into a QR code');
                          return;
                        }
                        const blob = new Blob([formQrSvg], {
                          type: 'image/svg+xml;charset=utf-8',
                        });
                        const url = URL.createObjectURL(blob);
                        const img = new Image();
                        img.onload = () => {
                          const canvas = document.createElement('canvas');
                          canvas.width = 1040;
                          canvas.height = 1040;
                          const ctx = canvas.getContext('2d');
                          if (!ctx) {
                            URL.revokeObjectURL(url);
                            toast.error('Could not rasterize the QR code');
                            return;
                          }
                          ctx.fillStyle = '#ffffff';
                          ctx.fillRect(0, 0, 1040, 1040);
                          ctx.drawImage(img, 0, 0, 1040, 1040);
                          URL.revokeObjectURL(url);
                          const a = document.createElement('a');
                          a.href = canvas.toDataURL('image/png');
                          a.download = `${(resolvedFormName || 'form').replace(/[^a-zA-Z0-9]+/g, '-').toLowerCase()}-qr.png`;
                          document.body.appendChild(a);
                          a.click();
                          document.body.removeChild(a);
                          toast.success('High-resolution QR image downloaded!');
                        };
                        img.onerror = () => {
                          URL.revokeObjectURL(url);
                          toast.error('Could not rasterize the QR code');
                        };
                        img.src = url;
                      }}
                      className="gap-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl h-9"
                    >
                      <Download className="size-3.5" /> Download PNG
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handlePrintQR}
                      className="gap-1.5 text-xs font-bold rounded-xl h-9"
                    >
                      <Printer className="size-3.5" /> Print QR Sheet
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ─── OPTIONAL CONNECTED UPGRADES BANNER (CLEAR MONETIZATION BOUNDARY) ─── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
        {/* Connected Fieseros CRM */}
        <div className="p-4 rounded-2xl bg-slate-900 text-white border border-slate-800 space-y-2 flex flex-col justify-between">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center gap-1">
                <Layers className="size-3" /> Fieseros Field CRM
              </span>
              <Badge className="bg-emerald-500/20 text-emerald-300 border-none text-[9px]">Optional Connection</Badge>
            </div>
            <h4 className="text-xs font-bold">Turn Submissions Into Real Dispatch Jobs</h4>
            <p className="text-[11px] text-slate-300">
              Automatically convert leads into dispatch jobs, assign technicians, track equipment history, and issue invoices.
            </p>
          </div>
          <a
            href="https://fieseros.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 pt-1"
          >
            Explore Fieseros CRM &amp; Dispatch <ArrowRight className="size-3" />
          </a>
        </div>

        {/* Connected AI Receptionist */}
        <div className="p-4 rounded-2xl bg-slate-900 text-white border border-slate-800 space-y-2 flex flex-col justify-between">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider flex items-center gap-1">
                <Phone className="size-3" /> AI Phone Receptionist
              </span>
              <Badge className="bg-amber-500/20 text-amber-300 border-none text-[9px]">Telephony Add-on</Badge>
            </div>
            <h4 className="text-xs font-bold">24/7 Live AI Phone Call Answering</h4>
            <p className="text-[11px] text-slate-300">
              Give your business a dedicated phone number. The AI Receptionist answers calls 24/7, captures caller info, and books appointments.
            </p>
          </div>
          <a
            href="https://fieseros.com/#ai-receptionist"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 pt-1"
          >
            Explore AI Phone Receptionist <ArrowRight className="size-3" />
          </a>
        </div>
      </div>
    </div>
  );
}
