import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { NextRequest, NextResponse } from 'next/server'
import { EventBus } from '@/lib/event-bus'

// GET /api/invoices/[id] — Get single invoice by ID
//
// Access control (Security-3 IDOR fix):
//   - Customer sessions: may view ONLY their own invoices (invoice.customerId
//     must equal authUser.id). Return 404 (not 403) to avoid leaking existence.
//   - Admin/employee sessions: may view invoices in their OWN tenant only.
//     Previously staff could read any tenant's invoice — now tenant-scoped.
//   - Super-admin: may access any tenant (platform-wide administration).
//   - Unauthenticated: denied (401).
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const authUser = await getAuthUser()

    // Require authentication — no anonymous access to invoices.
    if (!authUser) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    // Build the tenant-scoped filter
    // - Super-admin: no tenant filter (can access any tenant)
    // - Customer: filtered by customerId (ownership)
    // - Staff (admin/employee): filtered by tenantId
    let tenantFilter: Record<string, unknown>
    if (authUser.isSuperAdmin || authUser.role === 'superadmin' || authUser.role === 'super_admin') {
      tenantFilter = {} // super-admin can access any invoice
    } else if (authUser.role === 'customer') {
      tenantFilter = { customerId: authUser.id }
    } else {
      tenantFilter = { tenantId: authUser.tenantId }
    }

    const invoice = await db.invoice.findFirst({
      where: { id, ...tenantFilter },
      include: {
        customer: {
          select: { id: true, name: true, phone: true, email: true, address: true },
        },
        job: {
          select: { id: true, title: true, jobNumber: true, status: true },
        },
      },
    })

    if (!invoice) {
      return NextResponse.json(
        { error: 'Invoice not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(invoice)
  } catch (error) {
    console.error('Failed to get invoice:', error)
    return NextResponse.json(
      { error: 'Failed to get invoice' },
      { status: 500 }
    )
  }
}

// PUT /api/invoices/[id] — Full update of invoice (status changes, payment info)
// NOTE: The Invoice schema uses `amount`, `tax`, `discount`, `total` (NOT
// `subtotal`, `taxAmount`, `discountAmount`, `taxRate`, `discountType`,
// `discountValue`). There is no `customerName/Email/Phone`, `amountPaid`,
// `paymentMethod`, `paymentId`, or `pdfUrl` column on Invoice either. This
// handler was rewritten to only touch fields that actually exist on the model.
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // ── Security-3 IDOR fix: require authentication + tenant isolation ──
    const authUser = await getAuthUser()
    if (!authUser) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    const { id } = await params

    // Build the tenant-scoped filter (same logic as GET)
    let tenantFilter: Record<string, unknown>
    if (authUser.isSuperAdmin || authUser.role === 'superadmin' || authUser.role === 'super_admin') {
      tenantFilter = {}
    } else if (authUser.role === 'customer') {
      tenantFilter = { customerId: authUser.id }
    } else {
      tenantFilter = { tenantId: authUser.tenantId }
    }

    const existing = await db.invoice.findFirst({ where: { id, ...tenantFilter } })
    if (!existing) {
      return NextResponse.json(
        { error: 'Invoice not found' },
        { status: 404 }
      )
    }

    const body = await request.json()
    const {
      status,
      customerId,
      employeeId,
      jobId,
      itemsJson,
      taxPercent,   // percentage e.g. 18
      discount,     // flat amount in transaction currency
      dueDate,
      notes,
    } = body

    // ── FK-injection IDOR fix: body-supplied customerId/jobId/employeeId must
    // belong to the invoice's tenant before they can be linked to it (tenant
    // isolation on the referenced rows, not just the invoice row itself).
    // Super-admins keep cross-tenant access (their tenantFilter is empty).
    const isSuperAdminSession =
      authUser.isSuperAdmin || authUser.role === 'superadmin' || authUser.role === 'super_admin'
    const fkTenantId = existing.tenantId || authUser.tenantId
    if (!isSuperAdminSession && fkTenantId) {
      if (customerId) {
        const ownedCustomer = await db.customer.findFirst({
          where: { id: customerId, OR: [{ tenantId: fkTenantId }, { workspace: { tenantId: fkTenantId } }] },
          select: { id: true },
        })
        if (!ownedCustomer) {
          return NextResponse.json({ error: 'Invalid customerId' }, { status: 400 })
        }
      }
      if (jobId) {
        const ownedJob = await db.job.findFirst({
          where: { id: jobId, workspace: { tenantId: fkTenantId } },
          select: { id: true },
        })
        if (!ownedJob) {
          return NextResponse.json({ error: 'Invalid jobId' }, { status: 400 })
        }
      }
      if (employeeId) {
        const ownedEmployee = await db.employee.findFirst({
          where: { id: employeeId, workspace: { tenantId: fkTenantId } },
          select: { id: true },
        })
        if (!ownedEmployee) {
          return NextResponse.json({ error: 'Invalid employeeId' }, { status: 400 })
        }
      }
    }

    // Recalculate totals only if line items changed. The schema stores a single
    // `amount` (subtotal), `tax`, `discount`, `total`.
    let amount = existing.amount
    let tax = existing.tax
    let discountVal = existing.discount
    let total = existing.total

    if (itemsJson !== undefined) {
      let items: Array<{ description: string; quantity: number; rate: number; unitPrice?: number; amount?: number }>
      if (typeof itemsJson === 'string') {
        items = JSON.parse(itemsJson)
      } else {
        items = itemsJson
      }
      amount = items.reduce((sum, item) => sum + (item.amount || (item.quantity * (item.rate ?? item.unitPrice ?? 0))), 0)
      // Recompute tax/discount from the new subtotal
      const pct = typeof taxPercent === 'number' ? taxPercent : 0
      tax = amount * (pct / 100)
      discountVal = typeof discount === 'number' ? discount : 0
      total = amount + tax - discountVal
    } else if (typeof taxPercent === 'number' || typeof discount === 'number') {
      // Subtotal unchanged but tax % or discount changed
      const pct = typeof taxPercent === 'number' ? taxPercent : 0
      tax = amount * (pct / 100)
      discountVal = typeof discount === 'number' ? discount : existing.discount
      total = amount + tax - discountVal
    }

    // Use updateMany with tenant scope so a race-condition ID swap can't
    // mutate an invoice that was just moved to another tenant.
    const updateResult = await db.invoice.updateMany({
      where: { id, ...tenantFilter },
      data: {
        ...(status !== undefined && { status }),
        ...(customerId !== undefined && { customerId: customerId || null }),
        ...(employeeId !== undefined && { employeeId: employeeId || null }),
        ...(jobId !== undefined && { jobId: jobId || null }),
        ...(itemsJson !== undefined && {
          itemsJson: typeof itemsJson === 'string' ? itemsJson : JSON.stringify(itemsJson),
        }),
        amount,
        tax,
        discount: discountVal,
        total,
        ...(dueDate !== undefined && { dueDate: dueDate ? new Date(dueDate) : null }),
        ...(notes !== undefined && { notes }),
        // Set paidAt when status changes to paid
        ...(status === 'paid' && !existing.paidAt && { paidAt: new Date() }),
        // Set sentAt when status changes to sent
        ...(status === 'sent' && !existing.sentAt && { sentAt: new Date() }),
      },
    })

    if (updateResult.count === 0) {
      return NextResponse.json(
        { error: 'Invoice not found or access denied' },
        { status: 404 }
      )
    }

    // Fetch the updated invoice with relations (updateMany doesn't support include)
    const invoice = await db.invoice.findFirst({
      where: { id, ...tenantFilter },
      include: {
        customer: {
          select: { id: true, name: true, phone: true, email: true, address: true },
        },
        job: {
          select: { id: true, title: true, jobNumber: true, status: true },
        },
      },
    })

    // ─── Emit invoice lifecycle events on status change ──────────────
    // Best-effort — never fails the update.
    if (status && status !== existing.status) {
      try {
        const eventData = {
          invoiceId: invoice.id,
          invoiceNumber: invoice.number,
          customerId: invoice.customerId || null,
          tenantId: invoice.tenantId || null,
          total: Number(invoice.total),
          currency: invoice.currency,
          fromStatus: existing.status,
          toStatus: status,
          resourceType: 'invoice',
          resourceId: invoice.id,
        }
        const ctx = { tenantId: invoice.tenantId || undefined }
        if (status === 'sent') {
          await EventBus.emit('invoice.sent', eventData, ctx)
        } else if (status === 'paid') {
          await EventBus.emit('invoice.paid', eventData, ctx)
        }
      } catch (eventErr) {
        console.error('[Invoices PUT] invoice status event failed:', eventErr)
      }
    }

    return NextResponse.json(invoice)
  } catch (error) {
    console.error('Failed to update invoice:', error)
    return NextResponse.json(
      { error: 'Failed to update invoice' },
      { status: 500 }
    )
  }
}

// DELETE /api/invoices/[id] — Delete an invoice
// Security-3 IDOR fix: require authentication + tenant isolation
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authUser = await getAuthUser()
    if (!authUser) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    const { id } = await params

    // Build the tenant-scoped filter (same logic as GET/PUT)
    let tenantFilter: Record<string, unknown>
    if (authUser.isSuperAdmin || authUser.role === 'superadmin' || authUser.role === 'super_admin') {
      tenantFilter = {}
    } else if (authUser.role === 'customer') {
      // Customers typically can't delete invoices, but if they somehow
      // reach this endpoint, constrain to their own invoices.
      tenantFilter = { customerId: authUser.id }
    } else {
      tenantFilter = { tenantId: authUser.tenantId }
    }

    // Tenant-scoped delete: use deleteMany so cross-tenant ID is a no-op
    const deleteResult = await db.invoice.deleteMany({
      where: { id, ...tenantFilter },
    })

    if (deleteResult.count === 0) {
      return NextResponse.json(
        { error: 'Invoice not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, id })
  } catch (error) {
    console.error('Failed to delete invoice:', error)
    return NextResponse.json(
      { error: 'Failed to delete invoice' },
      { status: 500 }
    )
  }
}

// PATCH /api/invoices/[id] — Partial update (mark as sent, mark as paid, etc.)
// Security-3 IDOR fix: require authentication + tenant isolation
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authUser = await getAuthUser()
    if (!authUser) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    const { id } = await params

    // Build the tenant-scoped filter (same logic as GET/PUT/DELETE)
    let tenantFilter: Record<string, unknown>
    if (authUser.isSuperAdmin || authUser.role === 'superadmin' || authUser.role === 'super_admin') {
      tenantFilter = {}
    } else if (authUser.role === 'customer') {
      tenantFilter = { customerId: authUser.id }
    } else {
      tenantFilter = { tenantId: authUser.tenantId }
    }

    const existing = await db.invoice.findFirst({ where: { id, ...tenantFilter } })
    if (!existing) {
      return NextResponse.json(
        { error: 'Invoice not found' },
        { status: 404 }
      )
    }

    const body = await request.json()
    const updateData: Record<string, unknown> = {}

    // ── Payment ledger helpers ────────────────────────────────────────
    // `paid` used to be a bare status flip: partial payments, received-vs-
    // balance stats and payment history were impossible. Every payment now
    // lands in the InvoicePayment ledger; status is derived from the sums.
    const paidSoFar = async (): Promise<number> => {
      const agg = await db.invoicePayment.aggregate({
        where: { invoiceId: id },
        _sum: { amount: true },
      })
      return agg._sum.amount || 0
    }
    const round2 = (n: number) => Math.round(n * 100) / 100
    const PAYMENT_METHODS = ['MANUAL', 'CASH', 'CARD', 'BANK_TRANSFER', 'UPI', 'CHEQUE', 'OTHER']

    // Handle quick status actions
    if (body.action === 'mark_sent') {
      updateData.status = 'sent'
      updateData.sentAt = new Date()
    } else if (body.action === 'mark_paid') {
      updateData.status = 'paid'
      updateData.paidAt = new Date()
      // Record any remaining outstanding balance as a MANUAL payment so the
      // ledger matches the status (idempotent — skips when already settled).
      const outstanding = Number(existing.total) - (await paidSoFar())
      if (outstanding > 0.009) {
        await db.invoicePayment.create({
          data: {
            invoiceId: id,
            tenantId: existing.tenantId,
            amount: round2(outstanding),
            currency: existing.currency,
            method: PAYMENT_METHODS.includes(body.method) ? body.method : 'MANUAL',
            reference: typeof body.reference === 'string' ? body.reference : null,
            recordedBy: authUser.id,
          },
        })
      }
    } else if (body.action === 'record_payment') {
      // Partial payment entry — the mobile app + invoice detail use this.
      const amount = Number(body.amount)
      if (!Number.isFinite(amount) || amount <= 0) {
        return NextResponse.json(
          { error: 'A positive payment amount is required' },
          { status: 400 },
        )
      }
      if (body.method !== undefined && !PAYMENT_METHODS.includes(body.method)) {
        return NextResponse.json({ error: 'Invalid payment method' }, { status: 400 })
      }
      const paid = await paidSoFar()
      const outstanding = Number(existing.total) - paid
      if (amount > outstanding + 0.009) {
        return NextResponse.json(
          {
            error: `Payment exceeds the outstanding balance`,
            outstanding: round2(Math.max(0, outstanding)),
          },
          { status: 400 },
        )
      }
      await db.invoicePayment.create({
        data: {
          invoiceId: id,
          tenantId: existing.tenantId,
          amount: round2(amount),
          currency: existing.currency,
          method: PAYMENT_METHODS.includes(body.method) ? body.method : 'MANUAL',
          reference: typeof body.reference === 'string' ? body.reference : null,
          notes: typeof body.notes === 'string' ? body.notes : null,
          recordedBy: authUser.id,
        },
      })
      const newPaid = paid + amount
      if (newPaid >= Number(existing.total) - 0.009) {
        updateData.status = 'paid'
        updateData.paidAt = new Date()
      } else if (existing.status === 'draft') {
        updateData.status = 'sent' // a paid-towards draft is at least issued
      }
    } else if (body.action === 'cancel') {
      updateData.status = 'cancelled'
    } else {
      // Generic partial update — only touch real Invoice columns
      if (body.status !== undefined) {
        updateData.status = body.status
        if (body.status === 'paid' && !existing.paidAt) updateData.paidAt = new Date()
        if (body.status === 'sent' && !existing.sentAt) updateData.sentAt = new Date()
      }
      if (body.notes !== undefined) updateData.notes = body.notes
      if (body.dueDate !== undefined) updateData.dueDate = body.dueDate ? new Date(body.dueDate) : null

      // INTEGRITY: money fields are validated as a consistent set — the
      // client can no longer post arbitrary total/amount/tax/discount combos
      // (previously accepted verbatim, corrupting the books).
      const hasMoney = ['total', 'amount', 'tax', 'discount'].some((k) => body[k] !== undefined)
      if (hasMoney) {
        const amount = body.amount !== undefined ? Number(body.amount) : Number(existing.amount)
        const tax = body.tax !== undefined ? Number(body.tax) : Number(existing.tax)
        const discount = body.discount !== undefined ? Number(body.discount) : Number(existing.discount)
        const total = body.total !== undefined ? Number(body.total) : Number(existing.total)
        for (const [name, value] of [['amount', amount], ['tax', tax], ['discount', discount], ['total', total]] as const) {
          if (!Number.isFinite(value) || value < 0) {
            return NextResponse.json({ error: `Invalid ${name}: must be a non-negative number` }, { status: 400 })
          }
        }
        const expectedTotal = round2(amount + tax - discount)
        if (Math.abs(expectedTotal - total) > 0.011) {
          return NextResponse.json(
            { error: `Inconsistent amounts: total must equal amount + tax - discount (expected ${expectedTotal}, got ${total})` },
            { status: 400 },
          )
        }
        updateData.amount = amount
        updateData.tax = tax
        updateData.discount = discount
        updateData.total = total
      }
    }

    // Tenant-scoped update (Security-3 IDOR fix)
    const patchResult = await db.invoice.updateMany({
      where: { id, ...tenantFilter },
      data: updateData,
    })

    if (patchResult.count === 0) {
      return NextResponse.json(
        { error: 'Invoice not found or access denied' },
        { status: 404 }
      )
    }

    // Fetch the updated invoice with relations
    const invoice = await db.invoice.findFirst({
      where: { id, ...tenantFilter },
      include: {
        customer: {
          select: { id: true, name: true, phone: true, email: true },
        },
        job: {
          select: { id: true, title: true, jobNumber: true, status: true },
        },
      },
    })

    // ─── Emit invoice lifecycle events on status change ──────────────
    // Best-effort — never fails the update. Mirrors the PUT handler so
    // quick-action PATCHes (mark_sent, mark_paid) also fire events.
    const newStatus = (updateData.status as string | undefined) ?? existing.status
    if (newStatus !== existing.status) {
      try {
        const eventData = {
          invoiceId: invoice.id,
          invoiceNumber: invoice.number,
          customerId: invoice.customerId || null,
          tenantId: invoice.tenantId || null,
          total: Number(invoice.total),
          currency: invoice.currency,
          fromStatus: existing.status,
          toStatus: newStatus,
          resourceType: 'invoice',
          resourceId: invoice.id,
        }
        const ctx = { tenantId: invoice.tenantId || undefined }
        if (newStatus === 'sent') {
          await EventBus.emit('invoice.sent', eventData, ctx)
        } else if (newStatus === 'paid') {
          await EventBus.emit('invoice.paid', eventData, ctx)
        } else if (newStatus === 'overdue') {
          await EventBus.emit('invoice.overdue', eventData, ctx)
        }
      } catch (eventErr) {
        console.error('[Invoices PATCH] invoice status event failed:', eventErr)
      }
    }

    return NextResponse.json(invoice)
  } catch (error) {
    console.error('Failed to patch invoice:', error)
    return NextResponse.json(
      { error: 'Failed to patch invoice' },
      { status: 500 }
    )
  }
}
