import React, { useEffect, useRef } from 'react';
import { Stack, router, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { View, ActivityIndicator, AppState } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { useAuthStore } from '@/stores/auth-store';
import { useBlueprintStore } from '@/stores/blueprint-store';
import { registerForPushNotifications, setupNotificationListeners } from '@/lib/notifications';

import { BosSplash } from '@/components/brand/bos-splash';

export { AppErrorBoundary as ErrorBoundary } from '@/components/app-error-boundary';

export default function RootLayout() {
  const { isBooted, isAuthenticated, user, bootstrap } = useAuthStore();
  const segments = useSegments();
  const appStateRef = useRef(AppState.currentState);

  useEffect(() => {
    bootstrap();
  }, []);

  useEffect(() => {
    if (isAuthenticated && user?.id) {
      void useBlueprintStore.getState().init().catch(() => {});
    } else {
      useBlueprintStore.getState().reset();
    }
  }, [isAuthenticated, user?.id, user?.tenantId]);

  // Proactive session refresh on app foreground. When the app returns to the
  // foreground (from backgrounded), re-run bootstrap() which decodes the JWT
  // `exp` and calls /api/auth/refresh if the token is expired (or within 1h
  // of expiry). This keeps the session alive for returning users without them
  // ever seeing the login screen — as long as the token is within the 90-day
  // absolute session window.
  const prevAuthRef = React.useRef<boolean | null>(null);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      const prev = appStateRef.current;
      appStateRef.current = nextAppState;
      // App came back to the foreground from background/inactive.
      if (prev.match(/inactive|background/) && nextAppState === 'active') {
        // If not authenticated, try to restore session
        if (!useAuthStore.getState().isAuthenticated) {
          bootstrap();
        }
      }
    });
    return () => {
      subscription.remove();
    };
  }, [bootstrap]);

  useEffect(() => {
    if (!isBooted) return;
    const prevAuth = prevAuthRef.current;
    prevAuthRef.current = isAuthenticated;

    // Only navigate when auth state actually transitions (initial boot, login, or explicit logout)
    if (prevAuth === null || prevAuth !== isAuthenticated) {
      if (isAuthenticated) {
        // Keep a restored session on its requested product/settings deep link.
        if (prevAuth === false || segments[0] === '(auth)') router.replace('/(tabs)');
        registerForPushNotifications(user?.id);
      } else {
        router.replace('/(auth)/login');
      }
    }
  }, [isBooted, isAuthenticated, user?.id, segments]);

  useEffect(() => {
    const cleanup = setupNotificationListeners((route) => {
      try {
        router.push(route as any);
      } catch (err) {
        console.warn('Navigation from notification failed:', err);
      }
    });
    return cleanup;
  }, []);

  if (!isBooted) {
    return <BosSplash statusMessage="Loading BOS..." />;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <StatusBar style="light" />
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="(auth)" options={{ headerShown: false }} />
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen
            name="chat/[id]"
            options={{
              presentation: 'card',
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="lead/[id]"
            options={{
              presentation: 'modal',
              headerShown: false,
              animation: 'slide_from_bottom',
            }}
          />
          <Stack.Screen
            name="team/index"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="team/create-agent"
            options={{
              presentation: 'modal',
              headerShown: false,
              animation: 'slide_from_bottom',
            }}
          />
          <Stack.Screen
            name="team/train-agent"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="tickets"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="appearance"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="receptionist"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="notifications"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="channels/index"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="channels/whatsapp"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="channels/website"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="channels/instagram"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="channels/messenger"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="forms/index"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="khata"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="expenses"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="pos"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="catalog"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="dine-in-qr"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="templates"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="promotions"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="custom-domain"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="marketplace"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="blueprint-setup"
            options={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          />
        </Stack>
    </GestureHandlerRootView>
  );
}
