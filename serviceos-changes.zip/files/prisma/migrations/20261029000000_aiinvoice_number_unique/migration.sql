-- Deduplicate invoice numbers within a business before adding the unique constraint.
WITH ranked AS (
  SELECT id, ROW_NUMBER() OVER (PARTITION BY "businessId", number ORDER BY "createdAt" ASC) AS rn
  FROM "AiInvoice"
)
UPDATE "AiInvoice" SET number = number || '-D' || ranked.rn
FROM ranked WHERE "AiInvoice".id = ranked.id AND ranked.rn > 1;

-- Unique constraint: invoice numbers must be unique per business (GST series integrity).
CREATE UNIQUE INDEX "AiInvoice_businessId_number_key" ON "AiInvoice"("businessId", "number");
