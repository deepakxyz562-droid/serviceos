-- Phase 1: persist GST context on invoices, party metadata on customers,
-- and manual POS discounts on commerce orders.
ALTER TABLE "AiInvoice" ADD COLUMN "placeOfSupply" TEXT;
ALTER TABLE "AiInvoice" ADD COLUMN "customerGstin" TEXT;
ALTER TABLE "AiCustomer" ADD COLUMN "partyType" TEXT;
ALTER TABLE "AiCustomer" ADD COLUMN "creditLimit" DOUBLE PRECISION;
ALTER TABLE "GptformCommerceOrder" ADD COLUMN "discountAmount" DOUBLE PRECISION NOT NULL DEFAULT 0;
