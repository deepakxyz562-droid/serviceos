/*
 * Fieseros Service Worker (v5)
 * ------------------------------
 * Capabilities:
 *   1. App-shell pre-caching on install (/, /marketplace, /manifest.json, /logo.svg, /icon.svg, /offline.html)
 *      — SKIPPED in dev mode (?dev=1) to avoid caching Next.js dev renders.
 *   2. Cache cleanup + clients.claim() on activate
 *   3. Fetch strategies (ALL SKIPPED in dev mode — passthrough — so Next.js
 *      HMR and dev renders are never cached/served stale):
 *        - Network-first for /api/ (fall back to cache ONLY when offline, then offline JSON)
 *          — v5: NEVER caches /api/ responses that come back with a no-store
 *            Cache-Control header (CRM live-refresh fix). Only caches when
 *            the network is unreachable so the user gets stale-but-present
 *            data instead of a 503.
 *        - Stale-while-revalidate for /_next/static/ assets
 *        - Cache-first for images and fonts
 *        - Network-first with cache fallback for HTML navigation, falling back to /offline.html
 *   4. Background Sync: 'fieseros-sync' event notifies all clients to replay queued mutations
 *   5. Push Notifications: parses payload, shows notification with View/Dismiss actions
 *      — ALWAYS active (including dev) so real Web Push works in `next dev`.
 *   6. Notification click: focuses existing client (and postMessages data) or opens new client
 *   7. Message listener: SKIP_WAITING activates new SW immediately; CLEAR_CACHE wipes the cache
 *
 * DEV MODE:
 *   When registered as `/sw.js?dev=1` (which PwaProvider does in
 *   `process.env.NODE_ENV !== 'production'`), the SW detects the flag via
 *   `self.location.search` and disables ALL caching + the fetch handler.
 *   This lets the SW exist (so `pushManager.subscribe()` works and push
 *   events fire) without interfering with Next.js hot-reload or serving
 *   stale dev pages. The push + notificationclick handlers stay active.
 */

const CACHE_NAME = 'fieseros-v5';
const OFFLINE_URL = '/offline.html';

// Detect dev mode from the SW's own URL. PwaProvider registers this script
// as `/sw.js?dev=1` when running under `next dev`. This is race-free because
// the query param is part of the SW script URL and is available the moment
// the SW evaluates — before any fetch/push event can fire.
const IS_DEV =
  typeof self !== 'undefined' &&
  typeof self.location !== 'undefined' &&
  typeof self.location.search === 'string' &&
  new URLSearchParams(self.location.search).has('dev');

// App-shell assets pre-cached on install. All of these MUST exist in /public
// to avoid cache.addAll() rejecting the whole install. We use only files we
// know we ship (SVG icons + the offline page + the app shell URL).
const APP_SHELL = [
  '/',
  '/marketplace',
  '/manifest.json',
  '/logo.svg',
  '/icon.svg',
  OFFLINE_URL,
];

// ---------------------------------------------------------------------------
// Install — pre-cache the app shell
// ---------------------------------------------------------------------------
self.addEventListener('install', (event) => {
  if (IS_DEV) {
    // Dev mode: skip app-shell precache (don't cache Next.js dev renders).
    // Still skipWaiting() so the SW activates immediately and push works.
    self.skipWaiting();
    return;
  }
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .catch((err) => {
        // addAll rejects if ANY asset fails; we log but still install so the
        // SW can be activated and used for runtime caching.
        console.warn('[Fieseros SW] App-shell precache failed:', err);
      })
  );
  self.skipWaiting();
});

// ---------------------------------------------------------------------------
// Activate — clean up old caches and claim clients
// ---------------------------------------------------------------------------
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) =>
        Promise.all(
          cacheNames
            .filter((name) => name !== CACHE_NAME)
            .map((name) => caches.delete(name))
        )
      )
      .then(() => self.clients.claim())
  );
});

// ---------------------------------------------------------------------------
// Fetch — routing strategies
// ---------------------------------------------------------------------------
self.addEventListener('fetch', (event) => {
  // Dev mode: bypass the fetch handler entirely. The browser handles all
  // requests normally — no caching, no offline fallback. This keeps Next.js
  // HMR / fast-refresh working and prevents stale dev renders from being
  // served from cache. Push + notificationclick handlers remain active.
  if (IS_DEV) return;

  const { request } = event;
  const url = new URL(request.url);

  // Only handle GET
  if (request.method !== 'GET') return;

  // Only handle http(s) — skip chrome-extension://, blob:, data:, etc.
  if (!url.protocol.startsWith('http')) return;

  // Skip Next.js dev hot-reload and internal dev routes
  if (url.pathname.startsWith('/_next/') && url.pathname.includes('.hot-update')) return;
  if (url.pathname.startsWith('/__nextjs')) return;

  // 1. Network-first for /api/ requests (fall back to cache ONLY when offline)
  //
  // v5 fix: previously the SW cached EVERY successful /api/ GET indefinitely,
  // which defeated CRM live-refresh — the dashboard kept showing 30s-stale
  // jobs/pipeline data even after the server had fresh rows. Now:
  //   - If the response has `Cache-Control: no-store` (or no-cache), DON'T
  //     cache it — pass it straight through. This is the new default for all
  //     CRM list routes (see src/lib/cache-headers.ts).
  //   - If the response is cacheable (e.g. a static config endpoint), cache
  //     it with a 60s TTL via the `sw-cache-time` header we attach on put.
  //   - On network failure (offline), fall back to whatever is in the cache
  //     so the user sees stale-but-present data instead of a 503.
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) {
            const cc = response.headers.get('Cache-Control') || '';
            const isNoStore = /no-store|no-cache/i.test(cc);
            // Only cache the response if the server explicitly allows it
            // (no `no-store` / `no-cache` directive). This respects the
            // CRM live-refresh policy set in src/lib/cache-headers.ts.
            if (!isNoStore && request.method === 'GET') {
              const cloned = response.clone();
              caches.open(CACHE_NAME).then((cache) => {
                // Attach a cache-time header so the activate handler can
                // prune entries older than the TTL (60s for /api/).
                const headers = new Headers(cloned.headers);
                headers.set('sw-cache-time', Date.now().toString());
                cloned.text().then((body) => {
                  cache.put(
                    request,
                    new Response(body, {
                      status: cloned.status,
                      statusText: cloned.statusText,
                      headers,
                    })
                  );
                });
              });
            }
          }
          return response;
        })
        .catch(() =>
          caches.match(request).then(
            (cached) =>
              cached ||
              new Response(
                JSON.stringify({
                  error: 'offline',
                  message: 'You are offline. Your changes will sync when you reconnect.',
                }),
                {
                  status: 503,
                  statusText: 'Offline',
                  headers: { 'Content-Type': 'application/json' },
                }
              )
          )
        )
    );
    return;
  }

  // 2. Stale-while-revalidate for /_next/static/ assets (immutable build output)
  if (url.pathname.startsWith('/_next/static/')) {
    event.respondWith(staleWhileRevalidate(request));
    return;
  }

  // 3. Cache-first for images and fonts
  if (
    request.destination === 'image' ||
    request.destination === 'font' ||
    /\.(png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|eot)$/i.test(url.pathname)
  ) {
    event.respondWith(cacheFirst(request));
    return;
  }

  // 4. Network-first for navigation (HTML pages), falling back to /offline.html
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) {
            const cloned = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, cloned));
          }
          return response;
        })
        .catch(() =>
          caches.match(request).then((cached) => cached || caches.match(OFFLINE_URL))
        )
    );
    return;
  }

  // 5. Default — stale-while-revalidate for everything else (JS/CSS, etc.)
  event.respondWith(staleWhileRevalidate(request));
});

// ---------------------------------------------------------------------------
// Caching helpers
// ---------------------------------------------------------------------------
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    return new Response('', { status: 503, statusText: 'Offline' });
  }
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request);
  const networkFetch = fetch(request)
    .then((response) => {
      if (response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => cached);
  return cached || networkFetch;
}

// ---------------------------------------------------------------------------
// Background Sync — 'fieseros-sync' notifies clients to replay queued mutations
// ---------------------------------------------------------------------------
self.addEventListener('sync', (event) => {
  if (event.tag === 'fieseros-sync') {
    event.waitUntil(notifyClientsToReplay());
  }
});

async function notifyClientsToReplay() {
  const clients = await self.clients.matchAll({
    includeUncontrolled: true,
    type: 'window',
  });
  clients.forEach((client) => {
    client.postMessage({
      type: 'FIESEROS_SYNC',
      tag: 'fieseros-sync',
      timestamp: Date.now(),
    });
  });
}

// ---------------------------------------------------------------------------
// Push Notifications
// ---------------------------------------------------------------------------
self.addEventListener('push', (event) => {
  let payload = {};
  try {
    if (event.data) {
      payload = event.data.json();
    }
  } catch (err) {
    // Payload wasn't JSON — try to use it as plain text
    try {
      payload = { title: 'Fieseros', body: event.data ? event.data.text() : '' };
    } catch (e2) {
      payload = { title: 'Fieseros', body: 'You have a new update' };
    }
  }

  const title = payload.title || 'Fieseros';
  const body = payload.body || '';
  const icon = payload.icon || '/icon-192.png';
  const badge = payload.badge || '/icon-192.png';
  const tag = payload.tag || 'fieseros-notification';
  const data = payload.data || {};
  const actions =
    'actions' in Notification.prototype
      ? [
          { action: 'view', title: 'View', icon: '/icon-192.png' },
          { action: 'dismiss', title: 'Dismiss', icon: '/icon-192.png' },
        ]
      : undefined;

  const options = {
    body,
    icon,
    badge,
    tag,
    data: {
      url: data.url || '/',
      notificationId: data.notificationId || null,
      type: data.type || 'generic',
      ...data,
    },
    requireInteraction: payload.requireInteraction || false,
    ...(actions ? { actions } : {}),
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// ---------------------------------------------------------------------------
// Notification click — focus existing client or open new one
// ---------------------------------------------------------------------------
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'dismiss') {
    return;
  }

  const targetUrl =
    (event.notification.data && event.notification.data.url) || '/';
  const notificationData = event.notification.data || {};

  event.waitUntil(
    (async () => {
      const allClients = await self.clients.matchAll({
        type: 'window',
        includeUncontrolled: true,
      });

      // Look for a client whose URL starts with our origin (same app)
      for (const client of allClients) {
        if ('focus' in client) {
          try {
            await client.focus();
            client.postMessage({
              type: 'NOTIFICATION_CLICK',
              action: event.action || 'view',
              data: notificationData,
            });
            // Navigate the existing client to the target URL if it differs
            if (client.url !== targetUrl && 'navigate' in client) {
              try {
                await client.navigate(targetUrl);
              } catch (e) {
                /* navigate may not be supported — message will handle routing */
              }
            }
            return;
          } catch (e) {
            /* fall through to openWindow */
          }
        }
      }

      // No existing client — open a new window
      if (self.clients.openWindow) {
        try {
          await self.clients.openWindow(targetUrl);
        } catch (e) {
          /* ignore */
        }
      }
    })()
  );
});

// ---------------------------------------------------------------------------
// Message listener — SKIP_WAITING + CLEAR_CACHE
// ---------------------------------------------------------------------------
self.addEventListener('message', (event) => {
  if (!event.data) return;

  if (event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data.type === 'CLEAR_CACHE') {
    caches.delete(CACHE_NAME).then(() => {
      console.log('[Fieseros SW] Cache cleared');
    });
  }
});
