'use client';

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Settings, Plus, Send, Mail, Smartphone, MessageSquare,
  Wifi, WifiOff, AlertCircle, CheckCircle2, Loader2,
  Trash2, Shield, Key, Globe, Pencil, ExternalLink,
  ShieldCheck, Megaphone, RefreshCw, Link2, Info,
} from 'lucide-react';
import { useAppStore } from '@/store/app-store';
import { authFetch } from '@/lib/client-auth';

// ─── Types ───────────────────────────────────────────────────────────────────

interface ProviderConfig {
  [key: string]: string;
}

// Lightweight credential shape returned by /api/credentials and embedded in
// CommunicationProvider responses (the encryptedData is never sent to the UI).
interface CredentialLite {
  id: string;
  name: string;
  type: string;
}

interface CommunicationProvider {
  id: string;
  name: string;
  // 'email' is kept in the union ONLY for rendering legacy rows. New rows can
  // only be 'whatsapp' or 'sms' — see /api/communication-providers POST.
  type: 'email' | 'sms' | 'whatsapp';
  provider: string;
  status: string;
  isDefault: boolean;
  sendingEnabled: boolean;
  dailyLimit: number;
  monthlyLimit: number;
  sentToday: number;
  sentThisMonth: number;
  totalSent: number;
  totalDelivered: number;
  totalFailed: number;
  lastUsedAt: string | null;
  lastError: string | null;
  config: ProviderConfig;
  credentialId: string | null;
  credential: CredentialLite | null;
  createdAt: string;
}

// ─── Email Channel Status (two-section panel) ────────────────────────────────

interface EmailStatusMarketingProvider {
  id: string;
  name: string;
  providerType: string;
  usageType: string;
  isDefault: boolean;
  status: string;
  fromEmail: string;
  fromName: string;
  totalSent: number;
  lastUsedAt: string | null;
}

interface EmailChannelStatus {
  systemEmail: {
    managed: 'platform';
    connected: boolean;
    source: 'emailProvider' | 'simulated' | string | null;
    providerId: string | null;
    providerName: string | null;
    providerType: string | null;
    simulated: boolean;
  };
  marketingEmail: {
    connected: boolean;
    defaultProviderId: string | null;
    providers: EmailStatusMarketingProvider[];
  };
}

const MARKETING_PROVIDER_CHIPS = ['SMTP', 'Resend', 'SendGrid', 'Amazon SES', 'Mailgun', 'Brevo'];

// ─── Provider Configurations ─────────────────────────────────────────────────
// NOTE: 'email' type is no longer first-class here. Email send is owned by the
// EmailProvider model + /api/email-providers + src/lib/email-send.ts. Only
// WhatsApp + SMS providers can be created/edited through this view.

const PROVIDER_OPTIONS: Record<string, { value: string; label: string }> = {
  // SMS
  twilio: { value: 'twilio', label: 'Twilio' },
  msg91: { value: 'msg91', label: 'MSG91' },
  plivo: { value: 'plivo', label: 'Plivo' },
  textlocal: { value: 'textlocal', label: 'Textlocal' },
  exotel: { value: 'exotel', label: 'Exotel' },
  amazon_sns: { value: 'amazon_sns', label: 'Amazon SNS' },
  // WhatsApp
  meta_cloud_api: { value: 'meta_cloud_api', label: 'Meta Cloud API' },
  '360dialog': { value: '360dialog', label: '360Dialog' },
  wati: { value: 'wati', label: 'WATI' },
  interakt: { value: 'interakt', label: 'Interakt' },
  gupshup: { value: 'gupshup', label: 'Gupshup' },
};

const SMS_PROVIDERS = ['twilio', 'msg91', 'plivo', 'textlocal', 'exotel', 'amazon_sns'];
const WHATSAPP_PROVIDERS = ['meta_cloud_api', '360dialog', 'wati', 'interakt', 'gupshup'];

const CONFIG_FIELDS: Record<string, { key: string; label: string; type: 'text' | 'password'; placeholder: string }[]> = {
  // SMS providers
  twilio: [
    { key: 'accountSid', label: 'Account SID', type: 'text', placeholder: 'AC...' },
    { key: 'authToken', label: 'Auth Token', type: 'password', placeholder: '••••••••' },
    { key: 'fromNumber', label: 'From Number', type: 'text', placeholder: '+1234567890' },
  ],
  msg91: [
    { key: 'authKey', label: 'Auth Key / API Key', type: 'password', placeholder: '••••••••' },
    { key: 'fromNumber', label: 'From Number', type: 'text', placeholder: '+919876543210' },
  ],
  plivo: [
    { key: 'authId', label: 'Auth ID', type: 'text', placeholder: 'MA••••••••' },
    { key: 'authToken', label: 'Auth Token', type: 'password', placeholder: '••••••••' },
    { key: 'fromNumber', label: 'From Number', type: 'text', placeholder: '+1234567890' },
  ],
  textlocal: [
    { key: 'apiKey', label: 'API Key', type: 'password', placeholder: '••••••••' },
    { key: 'fromNumber', label: 'Sender Name', type: 'text', placeholder: 'SVROS' },
  ],
  exotel: [
    { key: 'accountSid', label: 'Account SID', type: 'text', placeholder: 'your_exotel_sid' },
    { key: 'authToken', label: 'Auth Token', type: 'password', placeholder: '••••••••' },
    { key: 'fromNumber', label: 'From Number', type: 'text', placeholder: '+919876543210' },
  ],
  amazon_sns: [
    { key: 'accessKeyId', label: 'AWS Access Key ID', type: 'text', placeholder: 'AKIA...' },
    { key: 'secretAccessKey', label: 'AWS Secret Access Key', type: 'password', placeholder: '••••••••' },
    { key: 'region', label: 'AWS Region', type: 'text', placeholder: 'us-east-1' },
    { key: 'senderId', label: 'Sender ID (optional, up to 11 chars)', type: 'text', placeholder: 'SRVOS' },
    { key: 'messageType', label: 'SMS Type', type: 'text', placeholder: 'Transactional' },
  ],
  // WhatsApp providers
  meta_cloud_api: [
    { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', placeholder: '1234567890' },
    { key: 'businessAccountId', label: 'Business Account ID', type: 'text', placeholder: 'BIZ-9876' },
    { key: 'accessToken', label: 'Access Token', type: 'password', placeholder: 'EAA••••••••' },
    { key: 'webhookVerifyToken', label: 'Webhook Verify Token', type: 'password', placeholder: 'your_verify_token' },
  ],
  '360dialog': [
    { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', placeholder: '1234567890' },
    { key: 'businessAccountId', label: 'Business Account ID', type: 'text', placeholder: 'BIZ-9876' },
    { key: 'accessToken', label: 'API Key', type: 'password', placeholder: '••••••••' },
    { key: 'webhookVerifyToken', label: 'Webhook Verify Token', type: 'password', placeholder: 'your_verify_token' },
  ],
  wati: [
    { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', placeholder: '1234567890' },
    { key: 'businessAccountId', label: 'Business Account ID', type: 'text', placeholder: 'BIZ-9876' },
    { key: 'accessToken', label: 'Access Token', type: 'password', placeholder: '••••••••' },
    { key: 'webhookVerifyToken', label: 'Webhook Verify Token', type: 'password', placeholder: 'your_verify_token' },
  ],
  interakt: [
    { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', placeholder: '1234567890' },
    { key: 'businessAccountId', label: 'Business Account ID', type: 'text', placeholder: 'BIZ-9876' },
    { key: 'accessToken', label: 'API Key', type: 'password', placeholder: '••••••••' },
    { key: 'webhookVerifyToken', label: 'Webhook Verify Token', type: 'password', placeholder: 'your_verify_token' },
  ],
  gupshup: [
    { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', placeholder: '1234567890' },
    { key: 'businessAccountId', label: 'Business Account ID', type: 'text', placeholder: 'BIZ-9876' },
    { key: 'accessToken', label: 'API Key', type: 'password', placeholder: '••••••••' },
    { key: 'webhookVerifyToken', label: 'Webhook Verify Token', type: 'password', placeholder: 'your_verify_token' },
  ],
};

// ─── Type Config ─────────────────────────────────────────────────────────────

interface TypeConfig {
  label: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
  /** True for legacy types that can no longer be created (only displayed). */
  deprecated?: boolean;
}

const TYPE_CONFIG: Record<string, TypeConfig> = {
  email: { label: 'Email (deprecated)', icon: Mail, color: 'text-amber-600', bgColor: 'bg-amber-50', borderColor: 'border-amber-200', deprecated: true },
  sms: { label: 'SMS', icon: Smartphone, color: 'text-emerald-600', bgColor: 'bg-emerald-50', borderColor: 'border-emerald-200' },
  whatsapp: { label: 'WhatsApp', icon: MessageSquare, color: 'text-emerald-600', bgColor: 'bg-emerald-50', borderColor: 'border-emerald-200' },
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatRelative(dateStr: string | null | undefined): string {
  if (!dateStr) return 'Never';
  try {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    if (diffMins < 10080) return `${Math.floor(diffMins / 1440)}d ago`;
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  } catch {
    return dateStr || 'Never';
  }
}

function formatNumber(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return n.toLocaleString();
}

// ─── Main Component ──────────────────────────────────────────────────────────

export function CommunicationProvidersView() {
  const [providers, setProviders] = useState<CommunicationProvider[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingProvider, setEditingProvider] = useState<CommunicationProvider | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  // Form state (shared for add/edit). Default to SMS — it works instantly and
  // doesn't require the complex WhatsApp API setup that 'whatsapp' does.
  // 'email' is intentionally not offered in the type selector (deprecated path).
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState<'email' | 'sms' | 'whatsapp'>('sms');
  const [formProvider, setFormProvider] = useState('meta_cloud_api');
  const [formConfig, setFormConfig] = useState<Record<string, string>>({});
  const [formCredentialId, setFormCredentialId] = useState<string>('');
  const [formIsDefault, setFormIsDefault] = useState(false);
  const [formSendingEnabled, setFormSendingEnabled] = useState(true);
  const [formDailyLimit, setFormDailyLimit] = useState('1000');
  const [formMonthlyLimit, setFormMonthlyLimit] = useState('30000');

  // ─── Credentials (for the Linked Credential dropdown) ───────────────────
  const [credentials, setCredentials] = useState<CredentialLite[]>([]);
  const [credentialsLoading, setCredentialsLoading] = useState(false);

  const fetchCredentials = useCallback(async (type?: 'whatsapp') => {
    setCredentialsLoading(true);
    try {
      const url = type ? `/api/credentials?type=${encodeURIComponent(type)}` : '/api/credentials';
      const res = await authFetch(url);
      if (res.ok) {
        const data = await res.json();
        // API returns either { credentials: [...] } or { data: [...] }
        const list: CredentialLite[] = (data.credentials || data.data || []).map((c: CredentialLite) => ({
          id: c.id,
          name: c.name,
          type: c.type,
        }));
        setCredentials(list);
      } else {
        setCredentials([]);
      }
    } catch {
      setCredentials([]);
    } finally {
      setCredentialsLoading(false);
    }
  }, []);

  // ─── Fetch ──────────────────────────────────────────────────────────────

  const fetchProviders = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await authFetch('/api/communication-providers');
      if (res.ok) {
        const data = await res.json();
        setProviders(data.data || []);
      } else {
        setError('Failed to load communication providers');
        toast.error('Failed to load communication providers');
      }
    } catch {
      setError('Network error. Please check your connection.');
      toast.error('Network error loading providers');
      setProviders([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProviders();
  }, [fetchProviders]);

  // ─── Email Channel Status (two-section panel) ──────────────────────────

  const [emailStatus, setEmailStatus] = useState<EmailChannelStatus | null>(null);
  const [statusLoading, setStatusLoading] = useState(true);
  const [statusError, setStatusError] = useState<string | null>(null);

  // ─── WhatsApp Credit & Email Usage Status ──────────────────────────────
  const [waCreditStatus, setWaCreditStatus] = useState<{
    allowed: boolean;
    remainingCredits: number;
    usedCredits: number;
    totalCredits: number;
    isTrial: boolean;
    ownWhatsappConnected: boolean;
    reason?: string;
  } | null>(null);
  const [emailUsageStatus, setEmailUsageStatus] = useState<{
    emailQuota: number;
    emailUsageCount: number;
    ownEmailProviderConnected: boolean;
  } | null>(null);

  const setActiveView = useAppStore((s) => s.setActiveView);

  const fetchEmailStatus = useCallback(async () => {
    setStatusLoading(true);
    setStatusError(null);
    try {
      const res = await fetch('/api/email-providers/status');
      if (res.ok) {
        const data = (await res.json()) as EmailChannelStatus;
        setEmailStatus(data);
      } else {
        setStatusError('Failed to load email channel status');
      }
    } catch {
      setStatusError('Network error loading status');
    } finally {
      setStatusLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEmailStatus();
  }, [fetchEmailStatus]);

  // Fetch WhatsApp credit status and email usage
  const fetchCreditStatus = useCallback(async () => {
    try {
      const waRes = await fetch('/api/credits/whatsapp');
      if (waRes.ok) {
        const data = await waRes.json();
        setWaCreditStatus(data);
      }
    } catch { /* ignore */ }
    try {
      const emailRes = await fetch('/api/credits/email-usage');
      if (emailRes.ok) {
        const data = await emailRes.json();
        setEmailUsageStatus(data);
      }
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    fetchCreditStatus();
  }, [fetchCreditStatus]);

  // ─── Computed ───────────────────────────────────────────────────────────

  const emailProviders = useMemo(() => providers.filter(p => p.type === 'email'), [providers]);
  const smsProviders = useMemo(() => providers.filter(p => p.type === 'sms'), [providers]);
  const whatsappProviders = useMemo(() => providers.filter(p => p.type === 'whatsapp'), [providers]);

  const stats = useMemo(() => {
    const active = providers.filter(p => p.status === 'active').length;
    const totalSent = providers.reduce((acc, p) => acc + p.totalSent, 0);
    const totalDelivered = providers.reduce((acc, p) => acc + p.totalDelivered, 0);
    const deliveryRate = totalSent > 0 ? Math.round((totalDelivered / totalSent) * 100) : 0;
    return { total: providers.length, active, totalSent, deliveryRate };
  }, [providers]);

  // Track whether we're populating for edit to avoid useEffect override
  const isPopulatingForEdit = useRef(false);

  // Reset form provider when type changes (skip during edit population).
  // Email is intentionally absent — we only allow whatsapp/sms selection for
  // new providers, but legacy email rows still pass through populateFormForEdit
  // which sets isPopulatingForEdit to bypass this branch.
  useEffect(() => {
    if (isPopulatingForEdit.current) return;
    const providerList = formType === 'sms' ? SMS_PROVIDERS : WHATSAPP_PROVIDERS;
    setFormProvider(providerList[0]);
    setFormConfig({});
    setFormCredentialId('');
  }, [formType]);

  // Load credentials for the Linked Credential dropdown whenever the form is
  // opened or the form type changes. For WhatsApp providers we filter the
  // vault by type=whatsapp; for SMS providers we show all credentials (since
  // SMS providers don't typically have a dedicated vault type).
  useEffect(() => {
    if (!showAddDialog && !showEditDialog) return;
    if (formType === 'whatsapp') {
      fetchCredentials('whatsapp');
    } else {
      fetchCredentials(undefined);
    }
  }, [showAddDialog, showEditDialog, formType, fetchCredentials]);

  // ─── Form helpers ───────────────────────────────────────────────────────

  const resetForm = () => {
    setFormName('');
    setFormType('whatsapp');
    setFormProvider('meta_cloud_api');
    setFormConfig({});
    setFormCredentialId('');
    setFormIsDefault(false);
    setFormSendingEnabled(true);
    setFormDailyLimit('1000');
    setFormMonthlyLimit('30000');
  };

  const populateFormForEdit = (provider: CommunicationProvider) => {
    isPopulatingForEdit.current = true;
    setFormName(provider.name);
    setFormType(provider.type);
    setFormProvider(provider.provider);
    setFormConfig(provider.config || {});
    setFormCredentialId(provider.credentialId || '');
    setFormIsDefault(provider.isDefault);
    setFormSendingEnabled(provider.sendingEnabled);
    setFormDailyLimit(String(provider.dailyLimit));
    setFormMonthlyLimit(String(provider.monthlyLimit));
    // Reset flag after the next render cycle so useEffect doesn't override
    requestAnimationFrame(() => {
      isPopulatingForEdit.current = false;
    });
  };

  // ─── Actions ────────────────────────────────────────────────────────────

  const handleAdd = async () => {
    if (!formName.trim()) {
      toast.error('Provider name is required');
      return;
    }

    setSaving(true);
    try {
      const res = await authFetch('/api/communication-providers', {
        method: 'POST',
        body: JSON.stringify({
          name: formName.trim(),
          type: formType,
          provider: formProvider,
          config: formConfig,
          credentialId: formCredentialId || undefined,
          isDefault: formIsDefault,
          sendingEnabled: formSendingEnabled,
          dailyLimit: parseInt(formDailyLimit) || 1000,
          monthlyLimit: parseInt(formMonthlyLimit) || 30000,
        }),
      });

      if (res.ok) {
        toast.success('Communication provider created');
        setShowAddDialog(false);
        resetForm();
        fetchProviders();
      } else {
        const data = await res.json();
        toast.error(data.error || 'Failed to create provider');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async () => {
    if (!editingProvider || !formName.trim()) {
      toast.error('Provider name is required');
      return;
    }

    setSaving(true);
    try {
      const res = await authFetch(`/api/communication-providers/${editingProvider.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: formName.trim(),
          provider: formProvider,
          config: formConfig,
          // Pass null when the user cleared the dropdown so the backend unlinks
          // any previously linked credential.
          credentialId: formCredentialId === '' ? null : formCredentialId,
          isDefault: formIsDefault,
          sendingEnabled: formSendingEnabled,
          dailyLimit: parseInt(formDailyLimit) || 1000,
          monthlyLimit: parseInt(formMonthlyLimit) || 30000,
        }),
      });

      if (res.ok) {
        toast.success('Provider updated successfully');
        setShowEditDialog(false);
        setEditingProvider(null);
        resetForm();
        fetchProviders();
      } else {
        const data = await res.json();
        toast.error(data.error || 'Failed to update provider');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const openEditDialog = (provider: CommunicationProvider) => {
    setEditingProvider(provider);
    populateFormForEdit(provider);
    setShowEditDialog(true);
  };

  const handleToggleSending = async (provider: CommunicationProvider) => {
    setTogglingId(provider.id);
    try {
      const res = await authFetch(`/api/communication-providers/${provider.id}`, {
        method: 'PUT',
        body: JSON.stringify({ sendingEnabled: !provider.sendingEnabled }),
      });
      if (res.ok) {
        toast.success(`Sending ${provider.sendingEnabled ? 'disabled' : 'enabled'} for ${provider.name}`);
        fetchProviders();
      } else {
        toast.error('Failed to toggle sending');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setTogglingId(null);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await authFetch(`/api/communication-providers/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        toast.success('Provider deleted');
        setShowDeleteDialog(null);
        fetchProviders();
      } else {
        toast.error('Failed to delete provider');
      }
    } catch {
      toast.error('Network error');
    }
  };

  // ─── Provider Card ─────────────────────────────────────────────────────

  const ProviderCard = ({ provider }: { provider: CommunicationProvider }) => {
    const typeConf = TYPE_CONFIG[provider.type] || TYPE_CONFIG.email;
    const TypeIcon = typeConf.icon;
    const isDeprecatedEmail = provider.type === 'email';
    // For legacy email rows the provider value (e.g. amazon_ses) is no longer
    // in PROVIDER_OPTIONS, so fall back to the raw string.
    const providerLabel = PROVIDER_OPTIONS[provider.provider]?.label || provider.provider;
    const dailyPct = provider.dailyLimit > 0 ? Math.min((provider.sentToday / provider.dailyLimit) * 100, 100) : 0;
    const monthlyPct = provider.monthlyLimit > 0 ? Math.min((provider.sentThisMonth / provider.monthlyLimit) * 100, 100) : 0;
    const deliveryRate = provider.totalSent > 0 ? Math.round((provider.totalDelivered / provider.totalSent) * 100) : 0;
    const isActive = provider.status === 'active';
    const isToggling = togglingId === provider.id;

    return (
      <Card className={cn('transition-all hover:shadow-md', !isActive && 'opacity-60', isDeprecatedEmail && 'border-amber-300 bg-amber-50/30')}>
        <CardContent className="p-4 space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <div className={cn('flex items-center justify-center size-10 rounded-lg shrink-0 border', typeConf.bgColor, typeConf.borderColor)}>
                <TypeIcon className={cn('size-5', typeConf.color)} />
              </div>
              <div className="min-w-0">
                <h3 className="font-semibold text-sm truncate">{provider.name}</h3>
                <p className="text-xs text-muted-foreground">{providerLabel}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
              {isDeprecatedEmail && (
                <Badge variant="outline" className="text-[10px] bg-amber-100 text-amber-800 border-amber-300">
                  <AlertCircle className="size-3 mr-0.5" /> Deprecated
                </Badge>
              )}
              {provider.isDefault && (
                <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200">
                  <Shield className="size-3 mr-0.5" /> Default
                </Badge>
              )}
              <Badge variant="outline" className={cn('text-[10px]', isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-gray-50 text-gray-500 border-gray-200')}>
                {isActive ? <Wifi className="size-3 mr-0.5" /> : <WifiOff className="size-3 mr-0.5" />}
                {isActive ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          </div>

          {/* Deprecation banner for legacy email rows */}
          {isDeprecatedEmail && (
            <div className="rounded-md border border-amber-300 bg-amber-100/70 p-2.5 text-xs text-amber-900 dark:bg-amber-900/30 dark:text-amber-200 dark:border-amber-700">
              <div className="flex items-start gap-2">
                <Info className="size-3.5 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-medium">Email providers have moved to Email Providers — this record is deprecated.</p>
                  <p className="text-amber-800/80 dark:text-amber-300/80">Email send is now managed by the EmailProvider system. This row is preserved for audit only.</p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-6 mt-1 text-[11px] bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-200 dark:bg-amber-900/40 dark:text-amber-200 dark:border-amber-700"
                    onClick={() => setActiveView('emailProviders')}
                  >
                    <ExternalLink className="size-3 mr-1" /> View Email Providers
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Linked credential indicator */}
          {!isDeprecatedEmail && provider.credential && (
            <div className="flex items-center gap-2 text-xs">
              <Link2 className="size-3.5 text-muted-foreground" />
              <span className="text-muted-foreground">Linked credential:</span>
              <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200">
                {provider.credential.name}
                <span className="ml-1 opacity-60 uppercase">{provider.credential.type}</span>
              </Badge>
            </div>
          )}
          {!isDeprecatedEmail && !provider.credential && provider.credentialId && (
            <div className="flex items-center gap-2 text-xs text-amber-700">
              <AlertCircle className="size-3.5" />
              <span>Linked credential is missing (deleted from vault).</span>
            </div>
          )}

          {/* Sending Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Send className="size-3.5 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Sending</span>
            </div>
            <Switch
              checked={provider.sendingEnabled}
              onCheckedChange={() => handleToggleSending(provider)}
              disabled={isToggling}
            />
          </div>

          {/* Usage */}
          <div className="space-y-2.5">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Daily Usage</span>
                <span className="font-medium">{provider.sentToday.toLocaleString()} / {provider.dailyLimit.toLocaleString()}</span>
              </div>
              <Progress value={dailyPct} className={cn('h-1.5', dailyPct > 80 && '[&>div]:bg-red-500', dailyPct > 50 && dailyPct <= 80 && '[&>div]:bg-amber-500', dailyPct <= 50 && '[&>div]:bg-emerald-500')} />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Monthly Usage</span>
                <span className="font-medium">{provider.sentThisMonth.toLocaleString()} / {provider.monthlyLimit.toLocaleString()}</span>
              </div>
              <Progress value={monthlyPct} className={cn('h-1.5', monthlyPct > 80 && '[&>div]:bg-red-500', monthlyPct > 50 && monthlyPct <= 80 && '[&>div]:bg-amber-500', monthlyPct <= 50 && '[&>div]:bg-emerald-500')} />
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-2">
            <div className="text-center p-2 rounded-md bg-muted/50">
              <p className="text-sm font-bold">{formatNumber(provider.totalSent)}</p>
              <p className="text-[10px] text-muted-foreground">Sent</p>
            </div>
            <div className="text-center p-2 rounded-md bg-muted/50">
              <p className="text-sm font-bold text-emerald-600">{formatNumber(provider.totalDelivered)}</p>
              <p className="text-[10px] text-muted-foreground">Delivered</p>
            </div>
            <div className="text-center p-2 rounded-md bg-muted/50">
              <p className="text-sm font-bold text-red-600">{formatNumber(provider.totalFailed)}</p>
              <p className="text-[10px] text-muted-foreground">Failed</p>
            </div>
          </div>

          {/* Delivery Rate */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground flex items-center gap-1">
              <CheckCircle2 className="size-3" /> Delivery Rate
            </span>
            <span className={cn('font-semibold', deliveryRate >= 95 ? 'text-emerald-600' : deliveryRate >= 80 ? 'text-amber-600' : 'text-red-600')}>
              {deliveryRate}%
            </span>
          </div>

          {/* Last Used / Error */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Last used: {formatRelative(provider.lastUsedAt)}</span>
            {provider.lastError && (
              <span className="flex items-center gap-1 text-red-600 truncate max-w-[140px]" title={provider.lastError}>
                <AlertCircle className="size-3 shrink-0" /> <span className="truncate">{provider.lastError}</span>
              </span>
            )}
          </div>

          {/* Edit / Delete */}
          <div className="flex justify-end gap-2 pt-1 border-t">
            <Button
              variant="ghost"
              size="sm"
              className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 h-7 text-xs"
              onClick={() => openEditDialog(provider)}
            >
              <Pencil className="size-3 mr-1" /> Edit
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-red-600 hover:text-red-700 hover:bg-red-50 h-7 text-xs"
              onClick={() => setShowDeleteDialog(provider.id)}
            >
              <Trash2 className="size-3 mr-1" /> Delete
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  // ─── Section ────────────────────────────────────────────────────────────

  const ProviderSection = ({ title, icon: SectionIcon, providers: sectionProviders, emptyText, deprecated }: {
    title: string;
    icon: React.ElementType;
    providers: CommunicationProvider[];
    emptyText: string;
    /** When true, the section renders as deprecated (e.g. legacy email rows). */
    deprecated?: boolean;
  }) => (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <SectionIcon className={cn('size-5', deprecated ? 'text-amber-600' : 'text-emerald-600')} />
        <h3 className="text-lg font-semibold">{title}</h3>
        <Badge variant="outline" className={cn('text-[10px]', deprecated ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200')}>
          {sectionProviders.length}
        </Badge>
        {deprecated && (
          <Badge variant="outline" className="text-[10px] bg-amber-100 text-amber-800 border-amber-300">
            Deprecated
          </Badge>
        )}
      </div>
      {deprecated && sectionProviders.length > 0 && (
        <div className="rounded-md border border-amber-300 bg-amber-100/60 p-3 text-xs text-amber-900 dark:bg-amber-900/30 dark:text-amber-200 dark:border-amber-700">
          <div className="flex items-start gap-2">
            <Info className="size-4 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-medium">Email providers have moved to Email Providers.</p>
              <p className="text-amber-800/80 dark:text-amber-300/80">
                These legacy rows are no longer used to send email — they're preserved for audit. Email send is now handled by the EmailProvider system.
              </p>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-6 mt-1 text-[11px] bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-200 dark:bg-amber-900/40 dark:text-amber-200 dark:border-amber-700"
                onClick={() => setActiveView('emailProviders')}
              >
                <ExternalLink className="size-3 mr-1" /> Open Email Providers
              </Button>
            </div>
          </div>
        </div>
      )}
      {sectionProviders.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-10 text-muted-foreground">
            <SectionIcon className="size-10 mb-3 opacity-30" />
            <p className="text-sm font-medium">No {title.toLowerCase()} configured</p>
            <p className="text-xs mt-1">{emptyText}</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {sectionProviders.map(p => <ProviderCard key={p.id} provider={p} />)}
        </div>
      )}
    </div>
  );

  // ─── Dynamic config fields for add/edit dialog ───────────────────────────

  const currentConfigFields = CONFIG_FIELDS[formProvider] || [];
  // When a credential is linked (or when editing a legacy email row), the
  // manual config fields below are decorative — secrets come from the vault.
  // For email rows we still show the legacy CONFIG_FIELDS lookup would yield [],
  // but we also short-circuit on the email type itself to be safe.
  const isEditingLegacyEmail = !!editingProvider && editingProvider.type === 'email';
  const configFieldsDisabled = !!formCredentialId || isEditingLegacyEmail;

  // ─── Shared form content for add/edit ──────────────────────────────────

  const formContent = (
    <div className="space-y-4 py-2">
      {/* Deprecation banner shown when editing a legacy email row */}
      {isEditingLegacyEmail && (
        <div className="rounded-md border border-amber-300 bg-amber-100/70 p-3 text-xs text-amber-900 dark:bg-amber-900/30 dark:text-amber-200 dark:border-amber-700">
          <div className="flex items-start gap-2">
            <Info className="size-4 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-medium">Email providers have moved to Email Providers — this record is deprecated.</p>
              <p className="text-amber-800/80 dark:text-amber-300/80">
                You can adjust quotas or disable sending here, but type/config changes are blocked. Please manage email send via the Email Providers page.
              </p>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-6 mt-1 text-[11px] bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-200 dark:bg-amber-900/40 dark:text-amber-200 dark:border-amber-700"
                onClick={() => setActiveView('emailProviders')}
              >
                <ExternalLink className="size-3 mr-1" /> View Email Providers
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Name */}
      <div className="space-y-2">
        <Label>Provider Name *</Label>
        <Input placeholder="e.g., Twilio SMS, Meta Cloud API" value={formName} onChange={e => setFormName(e.target.value)} />
      </div>

      {/* Type - only editable in Add mode. Email is intentionally NOT offered. */}
      {!editingProvider && (
        <div className="space-y-2">
          <Label>Type</Label>
          <Select value={formType === 'email' ? 'whatsapp' : formType} onValueChange={(v: 'email' | 'sms' | 'whatsapp') => setFormType(v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="sms">
                <span className="flex items-center gap-2"><Smartphone className="size-3.5 text-emerald-600" /> SMS</span>
              </SelectItem>
              <SelectItem value="whatsapp">
                <span className="flex items-center gap-2"><MessageSquare className="size-3.5 text-emerald-600" /> WhatsApp</span>
              </SelectItem>
            </SelectContent>
          </Select>
          <p className="text-[11px] text-muted-foreground">
            Email providers are managed on the <button type="button" className="underline text-emerald-700 hover:text-emerald-800" onClick={() => setActiveView('emailProviders')}>Email Providers</button> page.
          </p>
        </div>
      )}

      {/* Type indicator in edit mode */}
      {editingProvider && (
        <div className="space-y-2">
          <Label>Type</Label>
          <div className="flex items-center gap-2 h-9 px-3 rounded-md border bg-muted/50 text-sm text-muted-foreground">
            {(() => {
              const typeConf = TYPE_CONFIG[editingProvider.type] || TYPE_CONFIG.email;
              const TypeIcon = typeConf.icon;
              return <><TypeIcon className={cn('size-4', typeConf.color)} /> {typeConf.label}</>;
            })()}
          </div>
        </div>
      )}

      {/* Provider dropdown — email is intentionally excluded. */}
      <div className="space-y-2">
        <Label>Provider</Label>
        <Select
          value={formProvider}
          onValueChange={v => { setFormProvider(v); setFormConfig({}); }}
          // Disable provider switching for legacy email rows — their provider
          // value (e.g. amazon_ses) is no longer in the option list, so the
          // Select would show an empty value otherwise. They can still edit
          // name/limits/toggles below.
          disabled={isEditingLegacyEmail}
        >
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {(formType === 'sms' ? SMS_PROVIDERS : WHATSAPP_PROVIDERS).map(key => (
              <SelectItem key={key} value={key}>
                {PROVIDER_OPTIONS[key]?.label || key}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Linked Credential section — only for whatsapp/sms providers (not legacy email) */}
      {!isEditingLegacyEmail && (
        <>
          <Separator />
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Link2 className="size-4 text-emerald-600" />
              <Label className="text-sm font-semibold">Linked Credential</Label>
            </div>
            <p className="text-xs text-muted-foreground">
              Link a credential from the Credentials vault instead of pasting secrets here. If a credential is linked, the secrets below are ignored.
            </p>
            <Select
              value={formCredentialId || '__none__'}
              onValueChange={v => setFormCredentialId(v === '__none__' ? '' : v)}
            >
              <SelectTrigger>
                <SelectValue placeholder="No credential linked (use config fields below)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none__">— None (use config below) —</SelectItem>
                {credentialsLoading ? (
                  <div className="flex items-center gap-2 px-2 py-1.5 text-xs text-muted-foreground">
                    <Loader2 className="size-3 animate-spin" /> Loading credentials...
                  </div>
                ) : credentials.length === 0 ? (
                  <div className="px-2 py-1.5 text-xs text-muted-foreground">
                    No credentials found. Add one in the Credentials page.
                  </div>
                ) : (
                  credentials.map(c => (
                    <SelectItem key={c.id} value={c.id}>
                      <span className="flex items-center gap-2">
                        <Key className="size-3 text-muted-foreground" />
                        {c.name}
                        <span className="text-[10px] uppercase opacity-60">{c.type}</span>
                      </span>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        </>
      )}

      <Separator />

      {/* Dynamic Config Fields */}
      {currentConfigFields.length > 0 && (
        <div className={cn('space-y-3', configFieldsDisabled && 'opacity-50 pointer-events-none')}>
          <div className="flex items-center gap-2">
            <Key className="size-4 text-emerald-600" />
            <Label className="text-sm font-semibold">Configuration</Label>
            {configFieldsDisabled && (
              <span className="text-[11px] text-muted-foreground ml-auto">
                {isEditingLegacyEmail ? 'Disabled (legacy email row)' : 'Ignored — credential linked'}
              </span>
            )}
          </div>
          {currentConfigFields.map(field => (
            <div key={field.key} className="space-y-1.5">
              <Label className="text-xs">{field.label}</Label>
              <Input
                type={field.type}
                placeholder={field.placeholder}
                value={formConfig[field.key] || ''}
                onChange={e => setFormConfig(prev => ({ ...prev, [field.key]: e.target.value }))}
                disabled={configFieldsDisabled}
              />
            </div>
          ))}
        </div>
      )}

      <Separator />

      {/* Limits */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-xs">Daily Limit</Label>
          <Input
            type="number"
            placeholder="1000"
            value={formDailyLimit}
            onChange={e => setFormDailyLimit(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label className="text-xs">Monthly Limit</Label>
          <Input
            type="number"
            placeholder="30000"
            value={formMonthlyLimit}
            onChange={e => setFormMonthlyLimit(e.target.value)}
          />
        </div>
      </div>

      {/* Toggles */}
      <div className="flex items-center justify-between">
        <div className="space-y-0.5">
          <Label className="text-sm">Enable Sending</Label>
          <p className="text-xs text-muted-foreground">Allow this provider to send messages</p>
        </div>
        <Switch checked={formSendingEnabled} onCheckedChange={setFormSendingEnabled} />
      </div>
      <div className="flex items-center justify-between">
        <div className="space-y-0.5">
          <Label className="text-sm">Set as Default</Label>
          <p className="text-xs text-muted-foreground">Use as the default provider for this type</p>
        </div>
        <Switch checked={formIsDefault} onCheckedChange={setFormIsDefault} />
      </div>
    </div>
  );

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6 w-full">
      {/* Email Channel Status Panel (System Email + Marketing Email) */}
      <section className="space-y-3" aria-label="Email Channel Status">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h3 className="text-base font-semibold flex items-center gap-2">
              <Mail className="size-4 text-emerald-600" />
              Email Channel Status
            </h3>
            <p className="text-xs text-muted-foreground">
              Two separate channels: one for transactional email, one for your campaigns.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchEmailStatus}
            disabled={statusLoading}
          >
            <RefreshCw className={cn('size-4 mr-1.5', statusLoading && 'animate-spin')} />
            Refresh
          </Button>
        </div>

        {statusLoading ? (
          <div className="grid gap-4 md:grid-cols-2">
            {Array.from({ length: 2 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <Skeleton className="size-10 rounded-full" />
                    <div className="space-y-1.5">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-48" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Skeleton className="h-12 w-full rounded-md" />
                  <Skeleton className="h-3 w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : statusError ? (
          <Card>
            <CardContent className="p-4 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <AlertCircle className="size-4 text-amber-600" />
                <span>Unable to load status — {statusError}</span>
              </div>
              <Button variant="outline" size="sm" onClick={fetchEmailStatus}>
                <RefreshCw className="size-4 mr-1.5" /> Retry
              </Button>
            </CardContent>
          </Card>
        ) : emailStatus ? (
          <div className="grid gap-4 md:grid-cols-2">
            {/* ── Card 1: System Email (transactional, platform-managed) ── */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex items-center justify-center size-10 rounded-full bg-emerald-100 dark:bg-emerald-900/40 shrink-0">
                      <ShieldCheck className="size-5 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-base">System Email</CardTitle>
                      <p className="text-xs text-muted-foreground">
                        Password resets, invitations, booking & invoice alerts
                      </p>
                    </div>
                  </div>
                  <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-800 shrink-0">
                    <ShieldCheck className="size-3 mr-0.5" /> Managed By Platform
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="rounded-md border bg-muted/40 p-3">
                  {emailStatus.systemEmail.simulated || !emailStatus.systemEmail.connected ? (
                    <p className="text-sm">
                      <span className="font-medium text-amber-700 dark:text-amber-400">Simulated</span>{' '}
                      <span className="text-muted-foreground">
                        (add an email provider in SuperAdmin → Settings → Providers)
                      </span>
                    </p>
                  ) : emailStatus.systemEmail.source === 'emailProvider' && emailStatus.systemEmail.providerName ? (
                    <p className="text-sm">
                      <span className="font-medium">{emailStatus.systemEmail.providerName}</span>{' '}
                      <span className="text-muted-foreground">
                        via {emailStatus.systemEmail.providerType?.toUpperCase() || 'Provider'}
                      </span>
                    </p>
                  ) : (
                    <p className="text-sm text-muted-foreground">Connected</p>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  This channel is managed by the platform. You cannot reconfigure it.
                </p>
                {/* Email usage quota display */}
                {emailUsageStatus && !emailUsageStatus.ownEmailProviderConnected && (
                  <div className="rounded-md border bg-muted/40 p-3 mt-2">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-medium text-muted-foreground">Operational Email Usage</span>
                      <span className="text-xs font-bold">
                        {emailUsageStatus.emailUsageCount} / {emailUsageStatus.emailQuota}
                      </span>
                    </div>
                    <Progress
                      value={emailUsageStatus.emailQuota > 0 ? (emailUsageStatus.emailUsageCount / emailUsageStatus.emailQuota) * 100 : 0}
                      className="h-2"
                    />
                    <p className="text-[11px] text-muted-foreground mt-1.5">
                      {Math.max(0, emailUsageStatus.emailQuota - emailUsageStatus.emailUsageCount)} remaining this month
                      {emailUsageStatus.emailUsageCount >= emailUsageStatus.emailQuota && (
                        <span className="text-amber-600 dark:text-amber-400 font-medium block mt-0.5">
                          Quota exceeded — connect your own email provider for unlimited emails.
                        </span>
                      )}
                    </p>
                  </div>
                )}
                {emailUsageStatus && emailUsageStatus.ownEmailProviderConnected && (
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
                    ✓ Using your own email provider — unlimited operational emails.
                  </p>
                )}
              </CardContent>
            </Card>

            {/* ── Card 2: Marketing Email (tenant's own campaign channel) ── */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex items-center justify-center size-10 rounded-full bg-teal-100 dark:bg-teal-900/40 shrink-0">
                      <Megaphone className="size-5 text-teal-600 dark:text-teal-400" />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-base">Marketing Email</CardTitle>
                      <p className="text-xs text-muted-foreground">
                        Newsletters, promotions & bulk campaigns
                      </p>
                    </div>
                  </div>
                  {emailStatus.marketingEmail.connected ? (
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-800 shrink-0">
                      <CheckCircle2 className="size-3 mr-0.5" /> Connected
                    </Badge>
                  ) : (
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-800 shrink-0">
                      <AlertCircle className="size-3 mr-0.5" /> Not Connected
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {emailStatus.marketingEmail.connected ? (
                  <div className="space-y-2">
                    {emailStatus.marketingEmail.providers.length > 0 && (
                      <p className="text-xs text-muted-foreground">
                        {emailStatus.marketingEmail.providers.length} provider
                        {emailStatus.marketingEmail.providers.length === 1 ? '' : 's'} connected
                      </p>
                    )}
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {emailStatus.marketingEmail.providers.map((p) => (
                        <div
                          key={p.id}
                          className="flex items-start justify-between gap-2 rounded-md border bg-muted/40 p-2.5"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm font-medium truncate">{p.name}</span>
                              {p.isDefault && (
                                <Badge
                                  variant="outline"
                                  className="text-[10px] bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-800"
                                >
                                  Default
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground truncate">
                              {p.fromEmail || '—'}
                            </p>
                          </div>
                          <Badge
                            variant="outline"
                            className="text-[10px] uppercase shrink-0"
                          >
                            {p.providerType}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Connect your own email provider to send campaigns. Bulk email is sent through your domain to protect platform deliverability.
                    </p>
                    <Button
                      className="bg-emerald-600 hover:bg-emerald-700"
                      size="sm"
                      onClick={() => setActiveView('emailProviders')}
                    >
                      <Plus className="size-4 mr-1.5" /> Connect Provider
                    </Button>
                  </div>
                )}

                {/* Supported provider type chips */}
                <div className="pt-1">
                  <p className="text-[11px] text-muted-foreground mb-1.5">Supported providers</p>
                  <div className="flex flex-wrap gap-1.5">
                    {MARKETING_PROVIDER_CHIPS.map((name) => (
                      <span
                        key={name}
                        className="inline-flex items-center rounded-md border bg-muted/40 px-2 py-0.5 text-[10px] text-muted-foreground"
                      >
                        {name}
                      </span>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ── Card 3: WhatsApp Trial Credits ── */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex items-center justify-center size-10 rounded-full bg-emerald-100 dark:bg-emerald-900/40 shrink-0">
                      <MessageSquare className="size-5 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-base">WhatsApp</CardTitle>
                      <p className="text-xs text-muted-foreground">
                        Booking confirmations, reminders, job updates
                      </p>
                    </div>
                  </div>
                  {waCreditStatus ? (
                    waCreditStatus.ownWhatsappConnected ? (
                      <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-800 shrink-0">
                        <CheckCircle2 className="size-3 mr-0.5" /> Connected
                      </Badge>
                    ) : waCreditStatus.remainingCredits > 0 ? (
                      <Badge className="bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-800 shrink-0">
                        <MessageSquare className="size-3 mr-0.5" /> Trial Mode
                      </Badge>
                    ) : (
                      <Badge className="bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-900/40 dark:text-rose-300 dark:border-rose-800 shrink-0">
                        <AlertCircle className="size-3 mr-0.5" /> Credits Used
                      </Badge>
                    )
                  ) : null}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {waCreditStatus && waCreditStatus.ownWhatsappConnected ? (
                  <div className="space-y-2">
                    <p className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">
                      ✓ Your own Meta Business Account is connected — unlimited messaging.
                    </p>
                    {whatsappProviders.filter(p => !p.isPlatform).map((p) => (
                      <div key={p.id} className="flex items-center justify-between rounded-md border bg-muted/40 p-2.5">
                        <div>
                          <span className="text-sm font-medium">{p.name}</span>
                          <p className="text-xs text-muted-foreground">{p.provider}</p>
                        </div>
                        <Badge variant="outline" className="text-[10px] uppercase shrink-0">Connected</Badge>
                      </div>
                    ))}
                  </div>
                ) : waCreditStatus ? (
                  <div className="space-y-3">
                    <div className="rounded-md border bg-muted/40 p-3">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-medium text-muted-foreground">WhatsApp Trial Messages</span>
                        <span className="text-xs font-bold">
                          {waCreditStatus.usedCredits} / {waCreditStatus.totalCredits}
                        </span>
                      </div>
                      <Progress
                        value={waCreditStatus.totalCredits > 0 ? (waCreditStatus.usedCredits / waCreditStatus.totalCredits) * 100 : 0}
                        className="h-2"
                      />
                      <p className="text-[11px] text-muted-foreground mt-1.5">
                        {Math.max(0, waCreditStatus.remainingCredits)} free messages remaining
                        {waCreditStatus.remainingCredits <= 0 && (
                          <span className="text-amber-600 dark:text-amber-400 font-medium block mt-0.5">
                            You&apos;ve used all free WhatsApp test messages. Connect your Meta Business Account to continue sending WhatsApp messages.
                          </span>
                        )}
                      </p>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Connect your Meta Business Account for unlimited WhatsApp messaging.
                    </p>
                    <Button
                      className="bg-emerald-600 hover:bg-emerald-700"
                      size="sm"
                      onClick={() => { resetForm(); setFormType('whatsapp'); setShowAddDialog(true); }}
                    >
                      <Plus className="size-4 mr-1.5" /> Connect Meta Business
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-2 w-full" />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ) : null}
      </section>

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center size-10 rounded-lg bg-emerald-600">
            <Settings className="size-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Communication Providers</h2>
            <p className="text-sm text-muted-foreground">Manage SMS and WhatsApp providers — email is configured under Email Providers</p>
          </div>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { resetForm(); setShowAddDialog(true); }}>
          <Plus className="size-4 mr-1.5" /> Add Provider
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-3 grid-cols-2 sm:grid-cols-4">
        {[
          { label: 'Total Providers', value: stats.total, icon: Globe, color: 'text-foreground' },
          { label: 'Active', value: stats.active, icon: CheckCircle2, color: 'text-emerald-600' },
          { label: 'Total Sent', value: formatNumber(stats.totalSent), icon: Send, color: 'text-emerald-600' },
          { label: 'Delivery Rate', value: `${stats.deliveryRate}%`, icon: Wifi, color: stats.deliveryRate >= 95 ? 'text-emerald-600' : stats.deliveryRate >= 80 ? 'text-amber-600' : 'text-red-600' },
        ].map(stat => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-4">
              <div className="flex items-center gap-2">
                <Icon className={cn('size-4', stat.color)} />
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className={cn('text-lg font-bold', stat.color)}>{stat.value}</p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Loading */}
      {loading ? (
        <div className="space-y-6 w-full">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Skeleton className="size-10 rounded-lg" />
              <div>
                <Skeleton className="h-5 w-48" />
                <Skeleton className="h-3 w-56 mt-1" />
              </div>
            </div>
            <Skeleton className="h-9 w-32" />
          </div>
          <div className="grid gap-3 grid-cols-2 sm:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i} className="p-4"><div className="flex items-center gap-2"><Skeleton className="size-4" /><div><Skeleton className="h-3 w-20" /><Skeleton className="h-5 w-10 mt-1" /></div></div></Card>
            ))}
          </div>
          {Array.from({ length: 2 }).map((_, i) => (
            <Card key={i} className="p-4"><div className="space-y-4"><Skeleton className="h-4 w-1/3" /><Skeleton className="h-3 w-2/3" /><Skeleton className="h-8 w-full" /></div></Card>
          ))}
        </div>
      ) : error ? (
        <div className="flex flex-col items-center justify-center h-96 text-muted-foreground">
          <Settings className="size-12 mb-4 opacity-20" />
          <p className="text-lg font-medium">Failed to load providers</p>
          <p className="text-sm mt-1">{error}</p>
          <Button className="mt-4" variant="outline" onClick={fetchProviders}>
            <Loader2 className="size-4 mr-1.5" /> Retry
          </Button>
        </div>
      ) : providers.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Settings className="size-14 mb-4 opacity-30" />
            <p className="text-lg font-medium">No communication providers configured</p>
            <p className="text-sm mt-1 mb-4">Add your first provider to start sending messages</p>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { resetForm(); setShowAddDialog(true); }}>
              <Plus className="size-4 mr-1.5" /> Add Provider
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {emailProviders.length > 0 && (
            <ProviderSection
              title="Email Providers (Legacy)"
              icon={Mail}
              providers={emailProviders}
              emptyText="Add an email provider like Amazon SES, Resend, or SendGrid"
              deprecated
            />
          )}
          <ProviderSection
            title="SMS Providers"
            icon={Smartphone}
            providers={smsProviders}
            emptyText="Add an SMS provider like Twilio, MSG91, or Plivo"
          />
          <ProviderSection
            title="WhatsApp Providers"
            icon={MessageSquare}
            providers={whatsappProviders}
            emptyText="Add a WhatsApp provider like Meta Cloud API or 360Dialog"
          />
        </div>
      )}

      {/* Add Provider Dialog */}
      <Dialog open={showAddDialog} onOpenChange={(open) => { if (!open) setShowAddDialog(false); }}>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Communication Provider</DialogTitle>
            <DialogDescription>Configure a new SMS or WhatsApp provider. Email providers are managed on the Email Providers page.</DialogDescription>
          </DialogHeader>
          {formContent}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleAdd} disabled={!formName.trim() || saving}>
              {saving ? <><Loader2 className="size-4 mr-1.5 animate-spin" /> Creating...</> : <><Plus className="size-4 mr-1.5" /> Create Provider</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Provider Dialog */}
      <Dialog open={showEditDialog} onOpenChange={(open) => { if (!open) { setShowEditDialog(false); setEditingProvider(null); } }}>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Communication Provider</DialogTitle>
            <DialogDescription>Update provider configuration and settings.</DialogDescription>
          </DialogHeader>
          {formContent}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => { setShowEditDialog(false); setEditingProvider(null); }}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleEdit} disabled={!formName.trim() || saving}>
              {saving ? <><Loader2 className="size-4 mr-1.5 animate-spin" /> Saving...</> : <><Pencil className="size-4 mr-1.5" /> Save Changes</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Dialog */}
      <Dialog open={!!showDeleteDialog} onOpenChange={(open) => { if (!open) setShowDeleteDialog(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Provider</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this provider? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDeleteDialog(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => showDeleteDialog && handleDelete(showDeleteDialog)}>
              <Trash2 className="size-4 mr-1.5" /> Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
