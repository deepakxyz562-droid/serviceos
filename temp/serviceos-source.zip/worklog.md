# ServiceOS Enterprise Build — Worklog

## Project: AI Operating System for Local Service Businesses
## Execution: 13-Phase Enterprise Plan (Option A — continuous build)

---
Task ID: P0-reset
Agent: main
Task: Reset codebase from GitHub, fix schema, start dev server

Work Log:
- Saved industry-catalog.ts (774 lines) to /tmp before reset (not on origin)
- Saved Phase 0 backup files (health, logger, rate-limit, proxy, nextconfig, 3 observability UIs) to /tmp
- Executed `git reset --hard origin/main` → HEAD now at acc3434
- Restored industry-catalog.ts to src/lib/
- Verified schema valid (`npx prisma validate` → valid)
- Started dev server with `bun run dev` in background

Stage Summary:
- Codebase reset to origin/main (commit acc3434 "add marketing ai receiptionist")
- Industry catalog preserved (25 industries, 150+ sub-services)
- Phase 0 backup files available in /tmp for review/restoration
- Dev server running on port 3000

---
Task ID: P0-auth-ratelimit
Agent: general-purpose
Task: Add rate limiting to all auth routes

Work Log:
- src/app/api/auth/login/route.ts → authLimiter (10/15min/IP) applied as first check in POST
- src/app/api/auth/register/route.ts → authLimiter applied as first check in POST
- src/app/api/auth/request-reset/route.ts → passwordResetLimiter (3/hour/IP) applied as first check in POST
- src/app/api/auth/dev-login/route.ts → authLimiter applied before the production guard in POST
- src/app/api/auth/company-login/route.ts → authLimiter applied as first check in POST
- src/app/api/auth/customer/login/route.ts → authLimiter applied as first check in POST
- src/app/api/auth/customer/send-otp/route.ts → otpLimiter (5/hour/IP) added on TOP of existing per-phone Map-based limiter
- src/app/api/auth/customer/magic-link/route.ts → authLimiter applied as first check in POST (Request type, no NextRequest)
- src/app/api/auth/google/route.ts → authLimiter applied as first check in GET (route only has GET — OAuth redirect entry point)

Each route was modified to:
1. Import the appropriate limiter(s) plus applyRateLimit and rateLimitResponse from '@/lib/rate-limit'
2. Add the two-line guard as the VERY FIRST thing in the handler:
     const rateLimited = applyRateLimit(<limiter>, request);
     if (rateLimited) return rateLimitResponse(rateLimited.resetAtMs);

No existing logic was modified. The rate-limit.ts library itself was not touched.

Stage Summary:
- 9 auth routes protected with rate limiting (8 POST + 1 GET for google OAuth entry)
- Lint check result: 0 errors in any api/auth/* file. Pre-existing 14 errors + 1 warning in unrelated files (server-daemon.js, server.js, start-dev.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text) are not affected by these changes.

---
Task ID: P1-feature-flags
Agent: general-purpose
Task: Extend FeatureFlag with revenue toggles + create SuperAdmin RevenueFeatureToggle API

Work Log:
- src/app/api/superadmin/feature-flags/route.ts → extended existing FEATURE_DEFINITIONS array with 12 new revenue-related feature keys (marketplace_commission, featured_listing, ai_credits, sms_billing, whatsapp_billing, white_label_billing, premium_integrations, marketplace_eligibility, instant_booking, quote_request, emergency_dispatch, ai_auto_assign). All 16 original entries preserved. Array total now 28 definitions.
- src/app/api/superadmin/revenue-toggles/route.ts → NEW file. GET (list all RevenueFeatureToggle rows, calls seedRevenueFeatureToggles() from @/lib/revenue-toggles on empty table then re-queries; parses pricingJson/configJson for client convenience; ordered by featureKey asc) + PATCH (update a single toggle by featureKey from body; supports enabled/pricingJson/configJson/perTenantOverride/defaultForNewTenants/displayName/description fields; returns 404 if toggle missing, 400 if featureKey missing or no updatable fields provided).
- src/app/api/superadmin/revenue-toggles/[featureKey]/route.ts → NEW file. GET (single toggle by featureKey; attempts seed if not found, then returns 404 if still missing) + PATCH (update single toggle by featureKey from route param; body supports same optional fields as the collection PATCH). Uses async params (Next.js 16 dynamic route signature: RouteContext with Promise<{ featureKey: string }>).
- All handlers use the established auth pattern: getAuthUser() from @/lib/auth → 401 if missing; isSuperAdminRequest() from @/lib/admin-auth → 403 if not super admin. All responses JSON. All wrapped in try/catch with console.error + 500 fallback.
- Import from @/lib/revenue-toggles confirmed working: seedRevenueFeatureToggles() is exported (file already exists with REVENUE_FEATURE_DEFS, seedRevenueFeatureToggles, isRevenueFeatureEnabled).

Stage Summary:
- 3 files touched/created (1 modified, 2 new) under src/app/api/superadmin/
- Lint check: 0 errors in any new/modified file. Pre-existing 14 errors + 1 warning (server-daemon.js, server.js, start-dev.js, custom-server.js, pm.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text) remain unchanged and unrelated.
- Pattern parity with feature-flags/route.ts maintained for auth + JSON responses.
- Revenue toggles API ready for SuperAdmin UI integration. Frontend can call GET /api/superadmin/revenue-toggles for the list, PATCH /api/superadmin/revenue-toggles with { featureKey, enabled, ... } for bulk update, or use the /api/superadmin/revenue-toggles/[featureKey] endpoints for single-toggle reads/edits.

---
Task ID: P1-eligibility
Agent: general-purpose
Task: Create marketplace eligibility checker + seed RevenueFeatureToggle table

Work Log:
- src/lib/marketplace-eligibility.ts (new, ~290 lines)
  - Exported `EligibilityResult` interface (eligible, missingRequirements[], profileCompletionPct, plan, marketplaceAccess, checks{9 booleans})
  - `checkMarketplaceEligibility(tenantId)` — loads Tenant (plan/planStatus + 6 marketplace fields), looks up Plan.marketplaceAccess, checks for an active Subscription row (fallback to planStatus==='active'), live-computes profile %, runs all 8 gates + planSupportsMarketplace (marketplaceAccess ∈ {receive_bookings, priority}). Returns graceful fully-failed result on null tenant / error.
  - `computeProfileCompletion(tenantId)` — weighted 13-field checklist summing to 100%: business name 5%, industry 5%, description ≥100ch 10%, ≥3 services 15% (db.service.count), ≥1 image 10% (coverImage OR galleryJson non-empty), business hours 10%, service areas 10%, pricing type 5%, call-out fee>0 5%, insurance info 10%, VAT 5%, licence 5%, Stripe connected 5%. Returns 0 on null tenant / error. Clamped to [0,100].
  - All paths logged via `logger` (warn for missing plan/subscription lookups, error for failures).
- src/lib/revenue-toggles.ts (new, ~210 lines)
  - Exported `REVENUE_FEATURE_DEFS` array with exactly the 7 feature keys specified: marketplace_commission, featured_listing, ai_credits, sms_billing, whatsapp_billing, white_label_billing, premium_integrations — each with displayName, description, enabled, perTenantOverride, defaultForNewTenants, pricingJson, configJson per the task spec.
  - `seedRevenueFeatureToggles()` — idempotent: loads existing toggles by featureKey in one round-trip, creates only missing rows (preserves admin edits to existing rows). Returns {seeded, skipped}. Race-safe (catches unique-constraint violations → skipped).
  - `isRevenueFeatureEnabled(featureKey, tenantId?)` — fail-closed resolution: global RevenueFeatureToggle must exist & be enabled; if !perTenantOverride OR no tenantId → return global `enabled`; else look up FeatureFlag(tenantId, featureKey), return its `enabled` if present, else fall back to `defaultForNewTenants`. Returns false on any error.
- src/app/api/marketplace/eligibility/route.ts (new, ~55 lines)
  - `GET` only. Auth required via `getAuthUser()`. 401 if no user; 403 if user has no tenantId. Returns the full `EligibilityResult` from `checkMarketplaceEligibility(user.tenantId)`. Uses `withRequestId(request)` for structured logging.
- Seed execution:
  - `bun -e "...seedRevenueFeatureToggles()..."` → first run: Seeded: 7, Skipped: 0
  - Re-ran to verify idempotency → Seeded: 0, Skipped: 7 ✓ (existing rows untouched)

Stage Summary:
- 3 new files, 0 existing files modified.
- Marketplace eligibility checker exposes 8 gates + planSupportsMarketplace, returns missingRequirements[] for UI checklist consumption.
- Profile completion uses live computation (not stale cached column) on every eligibility check.
- RevenueFeatureToggle table now has 7 rows seeded in SQLite (db/custom.db) — idempotent re-runs safe.
- isRevenueFeatureEnabled() ready for use by commission/billing/AI-credits/SMS/WhatsApp/white-label/premium-integrations code paths.
- Lint: 0 new errors introduced. Pre-existing 14 errors + 1 warning (accept-invitation.tsx setState-in-effect, customer-360-view.tsx alt-text, start-dev.js require-imports, server-daemon.js / server.js require-imports) are unchanged and unrelated to this task.
- Next actions for downstream agents:
  - Wire `checkMarketplaceEligibility` into the marketplace lead dispatcher (gate who receives leads).
  - Persist `profileCompletionPct` back to Tenant column after onboarding-step saves (so list views don't recompute per row).
  - Add SuperAdmin UI for editing RevenueFeatureToggle rows (displayName/pricingJson/enabled/perTenantOverride) and per-tenant FeatureFlag overrides keyed by the same featureKey.
  - Add `/api/marketplace/eligibility` POST for accepting marketplace T&Cs (sets marketplaceTermsAcceptedAt + marketplaceOptIn=true).

---
Task ID: P1-stripe
Agent: general-purpose
Task: Create Stripe Connect infrastructure

Work Log:
- src/lib/stripe.ts — Stripe server singleton + helpers (getStripe, isStripeConfigured, createConnectAccount, createAccountLink, getAccountStatus, createPaymentIntent, transferToProvider, createPayout, handleWebhookEvent, constructWebhookEvent) + StripeConfigError class. Server-only, lazy-init, structured logger, full input validation, idempotent webhook handlers.
- src/app/api/billing/stripe/connect/route.ts — POST creates/reuses Express Connect account + returns onboarding accountLinkUrl (idempotent on stripeAccountId); GET returns live Stripe account status (charges/payouts/detailsSubmitted/requirements) with DB-cache fallback.
- src/app/api/billing/stripe/connect/status/route.ts — GET lightweight status check returning { connected, payoutsEnabled, chargesEnabled, detailsSubmitted, accountId, requirements, stale? }. Falls back to cached DB columns when Stripe is unreachable so the dashboard never blanks out.
- src/app/api/billing/stripe/webhook/route.ts — POST reads RAW body via request.text(), verifies stripe-signature with STRIPE_WEBHOOK_SECRET via constructWebhookEvent, dispatches to handleWebhookEvent (handles account.updated → Tenant sync, payment_intent.succeeded → MarketplaceTransaction → escrow, transfer.created → record transferId, payout.paid → Payout.status=paid). Returns 200 for ack, 401 on bad signature, 500 on handler crash (Stripe retries). GET health-check endpoint for monitoring.
- src/app/api/billing/stripe/payment/route.ts — POST creates a marketplace PaymentIntent. Validates amount (>0, ≤1M), currency (3-letter ISO), bookingType (instant|quote_request|emergency|ai_auto), provider tenantId. Pre-creates a pending MarketplaceTransaction row (with 5% commission split) BEFORE calling Stripe so the webhook can always reconcile. Returns { clientSecret, paymentIntentId, transactionId } for Stripe.js.

Stage Summary:
- Built 5 files: 1 lib (src/lib/stripe.ts, ~510 lines) + 4 API routes under src/app/api/billing/stripe/
- All Stripe operations are server-side only (lib uses lazy SDK init, never imported by client components)
- STRIPE_SECRET_KEY / STRIPE_WEBHOOK_SECRET absence handled gracefully via isStripeConfigured() checks returning 503 with clear error messages; STRIPE_CONNECT_CLIENT_ID read but never required (Express onboarding via account links doesn't need it)
- Webhook signature verification uses request.text() (raw bytes) per Stripe's security contract — NOT request.json()
- Webhook handlers are idempotent (check current DB state before transitioning) so Stripe redeliveries are safe
- Marketplace payment flow uses escrow semantics: customer pays → funds in platform balance → on job completion settlement worker calls transferToProvider → payout.paid webhook closes the loop
- Lint: 0 errors / 0 warnings in any of the new Stripe files (project-wide 14 pre-existing errors in unrelated files: server-daemon.js, server.js, start-dev.js, accept-invitation.tsx, customer-360-view.tsx are unchanged)
- TypeScript: 0 errors in any of the new Stripe files (project-wide tsc errors only in src/scripts/seed-*.ts, unrelated)
- PayPal remains untouched; Stripe is additive and handles only marketplace payments + provider payouts as specified

---
Task ID: P3-verticals
Agent: general-purpose
Task: Add vertical field to industry catalog + group 25 industries into 9 verticals + align sub-services

Work Log:
- src/lib/industry-catalog.ts (was 774 lines → now 865 lines)
  - Industry interface (lines 53-84): added `vertical: string` field between `description` and `longDescription?` (with JSDoc comment: "Vertical ID this industry belongs to (see VERTICALS)")
  - NEW section "Verticals — top-level grouping of the 25 industries into 9 verticals" inserted between the types block and the Helper exports section (lines 86-128):
    * `VERTICALS` — `as const` array of 9 vertical objects each with { id, name, icon (emoji), description }
      IDs: home-property, security-tech, maintenance-repair, outdoor-utility, automotive, logistics, health-personal, professional, custom
    * `VERTICAL_MAP: Record<string, string>` — explicit kebab-case industry ID → vertical ID map (all 25 industries covered, 1:1 with the user's taxonomy)
  - Each of the 25 industry entries got a new `vertical: '<vertical-id>'` line added immediately after its `description` field. Industry IDs and ordering preserved exactly. Distribution:
    * home-property (10): cleaning, landscaping, hvac, plumbing, electrical, roofing, construction, painting, flooring, home-services
    * security-tech (2): security, it-services
    * maintenance-repair (3): appliance-repair, locksmith, handyman
    * outdoor-utility (3): pest-control, pool-spa, junk-removal
    * automotive (1): automotive
    * logistics (1): moving
    * health-personal (1): health-wellness
    * professional (1): professional-services
    * custom (3): others, window-cleaning, solar
  - NEW section "Vertical helpers" appended at the very end of the file (lines 847-864):
    * `getVerticals()` → returns VERTICALS array
    * `getIndustriesByVertical(verticalId)` → filters INDUSTRY_CATALOG by VERTICAL_MAP (uses canonical `INDUSTRY_CATALOG` constant instead of the `INDUSTRIES` shorthand in the task spec — same intent, matches actual file symbol)
    * `getVerticalForIndustry(industryId): string | undefined` → lookup into VERTICAL_MAP

Sub-service alignment verification (the user's stated must-haves):
  - Cleaning (10): Residential ✓, Commercial ✓, Carpet ✓, Window ✓, Pressure Washing ✓, Bin ✓, Move In/Out ✓, Post Construction ✓, Air Duct ✓, Solar Panel ✓
  - HVAC (7): AC Installation ✓, AC Repair ✓, Furnace ✓, Heat Pump ✓, Ventilation ✓, Duct Cleaning ✓, Refrigeration ✓
  - Plumbing (6): Plumbing Repair ✓, Drain Cleaning ✓, Water Heater ✓, Gas Fitting ✓, Leak Detection ✓, Sewer Services ✓
  All required sub-services were already present — no additions needed. Total sub-services = 143 across 25 industries (unchanged from before the task).

Runtime sanity check (bun -e):
  - INDUSTRY_CATALOG.length = 25 ✓
  - VERTICALS.length = 9 ✓
  - 0 industries missing vertical field
  - 0 industries with mismatched VERTICAL_MAP entry vs `vertical` field
  - getVerticals() / getIndustriesByVertical() / getVerticalForIndustry() all return expected values; getVerticalForIndustry('nonexistent') → undefined

Stage Summary:
- 1 file modified (src/lib/industry-catalog.ts), 0 new files, 0 deletions of existing data.
- All 25 industry IDs, names, icons, emojis, descriptions, sub-services, categories, jobTypes, employeeRoles, hasKit/hasSeoPage/seoSlug flags preserved byte-for-byte. Only the new `vertical` field was added per industry.
- VERTICALS, VERTICAL_MAP, and the 3 vertical helper functions are now exported alongside the existing getIndustry/getSubServices/INDUSTRY_LIST/CATALOG_STATS/legacyIndustryList/INDUSTRY_ID_ALIASES/resolveIndustryId exports — back-compat with existing consumers is preserved (additive only).
- Lint check (bun run lint): 0 errors / 0 warnings in industry-catalog.ts. Project-wide 14 pre-existing errors + 1 warning remain in unrelated files (start-dev.js require-imports, accept-invitation.tsx setState-in-effect, customer-360-view.tsx alt-text) — unchanged by this task.
- TypeScript check (bunx tsc --noEmit on industry-catalog.ts): 0 errors.
- Next actions for downstream agents:
  - Surface verticals in the onboarding industry picker (group by vertical, show 9 expandable sections instead of one 25-row grid) — src/components/onboarding/saas-onboarding.tsx.
  - Expose verticals on the industry list API (src/app/api/workspaces/industries/route.ts) so marketing pages + dashboards can render the 9-group layout.
  - Optional: add a `vertical` column to Tenant/Workspace Prisma models if vertical-level analytics are needed (not required — can be derived at runtime via VERTICAL_MAP).

---
Task ID: P3-pricing
Agent: general-purpose
Task: Add PricingRule model to Prisma + create estimatePrice() function for Smart Pricing

Work Log:
- prisma/schema.prisma (4 modifications):
  1. Tenant model (after line 144 `paymentGatewayConfigs PaymentGatewayConfig[]`): added `pricingRules PricingRule[]` relation — back-to-back with the existing paymentGatewayConfigs line, alphabetically grouped with other Phase-2 collection relations.
  2. Service model (after line 385 `tenant Tenant? @relation(...)` line): added `pricingRules PricingRule[]` relation — kept before the @@index lines.
  3. Appended new "SMART PRICING" section header + full `PricingRule` model definition at the end of the file (after the PaymentGatewayConfig model). All 18 fields + 2 relations + 3 indexes match the task spec verbatim:
     * id, tenantId, serviceId, name, basePrice, pricingType, callOutFee, travelFeePerKm,
       emergencySurchargePct, weekendSurchargePct, eveningSurchargePct, holidaySurchargePct,
       minimumCharge, maximumCharge (nullable), estimatedDurationMins, isActive, priority,
       conditionsJson, createdAt, updatedAt
     * tenant Tenant? @relation onDelete:Cascade  +  service Service? @relation onDelete:Cascade
     * @@index([tenantId]) + @@index([serviceId]) + @@index([isActive])
  4. Verified: `npx prisma validate` → valid 🚀
  5. Pushed: `npx prisma db push --accept-data-loss` → "Your database is now in sync with your Prisma schema" + Prisma Client v6.19.2 regenerated.

- src/lib/smart-pricing.ts (NEW, ~420 lines):
  - Exports `PriceEstimateInput` interface (tenantId, serviceId?, urgency?, scheduledAt?, distanceKm?, estimatedDurationMins?)
  - Exports `PriceEstimateOutput` interface (low, high, breakdown{base,callOutFee,travelFee,emergencySurcharge,weekendSurcharge,eveningSurcharge,total}, pricingType, currency, estimatedDurationMins, isEstimate)
  - Exports `estimatePrice(input): Promise<PriceEstimateOutput | null>` — the Smart Pricing estimate engine.
  - Resolution order for effective pricing parameters:
      1. Highest-priority active PricingRule scoped to (tenantId, serviceId) — service-specific rule wins
      2. Highest-priority active PricingRule scoped to (tenantId, null serviceId) — tenant-wide fallback rule
      3. Tenant-level default fields (pricingType, callOutFee, travelFeePerKm, emergencySurchargePct, weekendSurchargePct) + Service.basePrice fallback
  - Calculation logic:
      * Base amount per pricing type:
        - 'fixed' (default): base = basePriceRaw
        - 'hourly': base = basePriceRaw × (estimatedDurationMins / 60)
        - 'starting_from': base = basePriceRaw (low end); high end widened via STARTING_FROM_HIGH_MULT (1.75×) → isEstimate=true
        - 'custom_quote': wide range via CUSTOM_QUOTE_LOW_MULT (0.5×) + CUSTOM_QUOTE_HIGH_MULT (2×) anchored on basePrice or fees → isEstimate=true
      * callOutFee: flat add
      * travelFee: distanceKm × travelFeePerKm (distance clamped to ≥ 0)
      * emergencySurcharge: applied when urgency === 'emergency' → base × emergencySurchargePct / 100
      * weekendSurcharge: applied when scheduledAt.getDay() ∈ {0 (Sun), 6 (Sat)} → base × weekendSurchargePct / 100
      * eveningSurcharge: applied when scheduledAt.getHours() >= 18 → base × eveningSurchargePct / 100
      * holidaySurcharge: applied when scheduledAt matches a HolidayCalendar row for the tenant (one-off: sameCalendarDay, recurring: sameMonthDay) → base × holidaySurchargePct / 100. Only runs when holidaySurchargePct > 0 to avoid an unnecessary query.
      * Range: low = base + callOut (no travel/surcharges); high = base + callOut + travel + all applicable surcharges
      * Caps: minimumCharge floors both low and high; maximumCharge (if non-null) ceilings both; final sanity `if (high < low) high = low`
      * All monetary values rounded to 2 decimals via Math.round((n + EPSILON) * 100) / 100 before returning
      * Returns null when: missing tenantId, tenant not found, or no pricing info at all (basePrice=0 AND callOutFee=0 AND travelFeePerKm=0 AND pricingType=default)
  - Server-side only: imports `db` from '@/lib/db' and `logger` from '@/lib/logger' (same pattern as src/lib/marketplace-eligibility.ts). All DB lookups use Prisma `select` for performance. Every external lookup wrapped in try/catch with logger.warn — degraded gracefully when PricingRule/HolidayCalendar/Service tables or rows are missing.
  - Bug fix during self-review: renamed destructured `estimatedDurationMins` from input to `inputDurationMins` to avoid TS2448 "Block-scoped variable used before its declaration" shadowing the later local const.

Stage Summary:
- 1 file modified (prisma/schema.prisma: +3 relation additions inside existing models, +1 new model appended), 1 new file (src/lib/smart-pricing.ts), 0 deletions.
- Schema validates + pushed to SQLite (db/custom.db). Prisma Client regenerated.
- Lint check (bun run lint): 0 errors / 0 warnings in either changed file. Project-wide 14 pre-existing errors + 1 warning remain in unrelated files (start-dev.js require-imports, accept-invitation.tsx setState-in-effect, customer-360-view.tsx alt-text) — unchanged by this task.
- TypeScript (npx tsc --noEmit on smart-pricing.ts): 0 errors after shadowing fix. (Direct single-file tsc reports phantom "@/lib/db" + "@/lib/logger" resolution errors but this is expected — path alias `@/*` → `./src/*` is configured in tsconfig.json and resolved by the Next.js bundler at build time; the same pattern is used by src/lib/marketplace-eligibility.ts.)
- estimatePrice() is ready to be wired into:
    * /api/services/[id]/estimate/route.ts (public service-page price preview)
    * /api/jobs/quote/route.ts (quote generator for quote_request bookingType)
    * /api/marketplace/leads/route.ts (lead dispatcher price hint)
    * Job create/edit UI (live price preview as the customer picks service + scheduling)
- Next actions for downstream agents:
  - Create an API route POST /api/pricing/estimate that wraps estimatePrice() with auth + tenant scoping (caller must be a member of the input.tenantId or be the customer who owns the lead).
  - Add a SuperAdmin/Tenant UI for managing PricingRule rows (create service-specific rules with conditionsJson editor for minDistance/maxDistance/timeWindow).
  - Persist the chosen estimate snapshot onto Job.estimatedPriceJson so the customer-facing quote is immutable once issued.
  - Wire evening/holiday surcharges into the existing Tenant onboarding form (currently only callOutFee/travelFee/emergency/weekend are exposed on Tenant).

---
Task ID: P3-onboarding
Agent: general-purpose
Task: Enhance the business onboarding flow to collect all rich marketplace-eligibility fields (new "Business Profile" step)

Work Log:
- prisma/schema.prisma (1 addition)
  - Tenant model: added `businessCategoriesJson String @default("[]")` between `employeesCount` and the Public Business Hub section. Captures the multi-select industry categories from the new onboarding step (the existing `industry` field remains the canonical single industry for SEO routing).
  - `npx prisma db push --accept-data-loss` → "Your database is now in sync with your Prisma schema" + Prisma Client v6.19.2 regenerated.

- src/app/api/tenants/[id]/route.ts (1 new PATCH handler appended, ~240 lines)
  - Added `import { computeProfileCompletion } from '@/lib/marketplace-eligibility'` at the top.
  - PATCH handler accepts the full marketplace-eligibility field set with explicit field-by-field whitelisting (NOT a spread of `body`) so onboarding can never write to protected columns (slug, plan, planStatus, mrr, etc.):
    * Pricing: pricingType (validated against the 5 enum values), callOutFee, travelFeePerKm, emergencySurchargePct, weekendSurchargePct, emergencyServiceAvailable — all coerced to Numbers / booleans.
    * Credentials: vatNumber, licenceNumber (nullable strings, trimmed).
    * Insurance: insuranceProvider, insurancePolicyNumber (nullable, trimmed), insuranceExpiryDate (ISO-string → Date; invalid → null), insuranceVerified (boolean).
    * Operations: employeesCount (Int, clamped ≥ 0), languagesJson (array → JSON string), businessCategoriesJson (array → JSON string), businessHoursJson (object → JSON string), serviceAreasJson (array → JSON string).
    * Marketplace: marketplaceOptIn (boolean), marketplaceTermsAcceptedAt (true → new Date(), false/null → null, ISO string → parsed Date).
    * Verification flags: identityVerified, businessVerified, stripeConnected (all boolean).
    * Onboarding meta: onboardingStep (Number), onboardingCompleted (boolean).
  - After persisting: live-recomputes `profileCompletionPct` via `computeProfileCompletion(id)` and writes it back to the Tenant row so subsequent list views don't have to recompute per row. Best-effort — non-fatal if it fails.
  - Revalidates the public Business Hub ISR page (best-effort, non-fatal).
  - Response echoes back all marketplace-eligibility fields + the freshly-computed profileCompletionPct so the client can update its local state.

- src/components/onboarding/saas-onboarding.tsx (was 1,162 lines → now ~2,150 lines)
  - Imports: added Switch, Checkbox, Progress, Select (+ SelectContent/Item/Trigger/Value), Accordion (+ AccordionContent/Item/Trigger), CardHeader + CardTitle (was importing only Card + CardContent). Added Lucide icons: Briefcase, MapPin, Clock, Wrench, DollarSign, Users, ShieldCheck, Languages, Store, Plus, X, ExternalLink, RefreshCw. Added `useEffect` to the React import. Added `INDUSTRY_CATALOG, VERTICALS, getIndustriesByVertical, type Industry` from `@/lib/industry-catalog`.
  - STEPS array extended from 3 to 4 entries — new "Business Profile" step inserted at position 2 with the Briefcase icon; existing "Choose Your Plan" pushed to position 3 (CreditCard icon) and "All Set!" to position 4 (CheckCircle2 icon).
  - New types: `PricingType` (5-value union), `DayHours` (open/close/byAppointment/closed), `Step2Data` (~20 fields covering all marketplace-eligibility inputs + local-only `errors`, `stripeStatusLoading`, `profileCompletionPct`).
  - New module-level constants: `PRICING_TYPE_OPTIONS` (5 entries with label + hint), `LANGUAGE_OPTIONS` (18 languages: en/es/fr/de/hi/ar/zh/pt/ru/ja/it/nl/ko/tr/pl/ur/bn/pa), `DAYS_OF_WEEK` (mon-sun), `DEFAULT_BUSINESS_HOURS` (9-5 Mon-Fri, closed Sat/Sun).
  - New module-level helper `initializeStep2(tenant)` — defensively parses the JSON columns (businessCategoriesJson, languagesJson, serviceAreasJson, businessHoursJson) so the user can resume onboarding mid-flight without losing previously-saved data. Detects the `{byAppointmentOnly: true}` sentinel stored when "by appointment only" is toggled on. Formats insuranceExpiryDate as yyyy-mm-dd for `<input type="date">`.
  - Component state: `step2` (Step2Data) initialized via `initializeStep2(tenant)`. The existing `step3` state is preserved as an alias for the renamed `step4` state (`const step3 = step4; const setStep3 = setStep4;`) so the existing plan-step code keeps reading `step3.*` without a 50-line rename.
  - Navigation: `goToStep` / `goNext` now use `STEPS.length` (4) instead of the hard-coded `3` so future step additions don't require touching these.
  - `handleStep1Next` now also pre-selects the user's step-1 industry as the first entry in `step2.businessCategories` so they don't have to re-pick it.
  - New `isStep2Valid()` validator: checks categories ≥ 1, coverage areas ≥ 1, pricingType set, no negative numbers in fees/counts, marketplace opt-in requires terms acceptance. Returns a keyed error object.
  - New `handleStep2Next()`: runs validation, scrolls first error into view, builds the PATCH payload (Number coercion for numeric inputs, `{byAppointmentOnly: true}` sentinel for the by-appointment-only hours mode, `insuranceVerified` auto-set when both provider + policy are present), calls `patchBusinessProfile()`, reads `profileCompletionPct` from the response, stores it in `step2` state, shows a toast with the completion % + marketplace-eligibility status, then advances to step 3.
  - New `patchBusinessProfile()` helper — dedicated `fetch('/api/tenants/${tenantId}', { method: 'PATCH', ... })` wrapper that throws on non-2xx with the server-provided error message.
  - New Stripe Connect handlers:
    * `handleConnectStripe()` — POSTs to `/api/billing/stripe/connect?returnUrl=...&refreshUrl=...`, opens the returned `accountLinkUrl` in a new tab (so the onboarding wizard state survives the Stripe redirect roundtrip), shows a toast telling the user to come back and click "Refresh Status".
    * `refreshStripeStatus()` — GETs `/api/billing/stripe/connect/status`, sets `step2.stripeConnected` based on the response, toasts success (with payouts status) / warning (with pending requirements count) / error.
    * `useEffect` on mount — detects `?stripe_connect=return` or `?stripe_connect=refresh` in the URL (the Stripe return path), clears the param, and calls `refreshStripeStatus()` so the toggle reflects the freshly-completed onboarding when the user lands back on the wizard.
  - Renamed existing handlers to match the new step numbering: `handleStep2Next` (was the plan-step handler) → `handleStep3Next`. Same for renderStep2 → renderStep3 and renderStep3 → renderStep4. The CTAs inside the plan cards now call `handleStep3Next('trial')` / `handleStep3Next('pay')`.
  - `handleComplete` writes `onboardingStep: 4` (was 3) and `onboardingCompleted: true`.
  - `handleNext` dispatch table: step 1 → handleStep1Next, step 2 → handleStep2Next (NEW), step 4 → handleComplete. Step 3 still has no footer "Next" — plan cards carry their own dual CTAs.
  - `renderCurrentStep` switch: added case 4 → renderStep4(); cases 2 and 3 still call renderStep2 and renderStep3 respectively.
  - `renderNavigation`: step 4 returns null (no footer); step 3 shows Back only (plan cards have their own CTAs); steps 1 and 2 show Back + Continue.
  - New `renderStep2()` function (~850 lines) — the Business Profile step. Renders 8 Card sections (CardHeader + CardTitle + CardContent pattern), separated by visual spacing. Each section uses an icon (Briefcase, MapPin, Clock, Wrench, Users, ShieldCheck, Store, CreditCard) to aid visual scanning:
    1. Business Categories — multi-select with 9 verticals rendered as Accordion items. Each vertical header shows the emoji, name, count badge of selected industries in that vertical, and total industry count. Expanding reveals a 2-col (mobile) / 3-col (desktop) grid of toggle buttons with emoji + name + check icon. Selected categories also surface as removable Badges above the accordion.
    2. Coverage Area — tag input with Enter/comma to add, Backspace on empty input removes the last tag. Selected areas show as MapPin Badges with X-to-remove.
    3. Business Hours — Switch for "by appointment only" (collapses the per-day grid). Per-day grid: day label, Open time input, Close time input, "Appt." Checkbox, "Closed" Checkbox. Time inputs auto-disable when "Closed" is checked. Header row hidden on mobile (grid collapses to 2 cols).
    4. Service & Pricing — Switch for "Do you offer emergency / after-hours service?". Select for pricingType (with hint text per option). 2×2 grid of number inputs: callOutFee ($), travelFeePerKm ($), emergencySurchargePct (%), weekendSurchargePct (%). Currency fields have a $-icon prefix, percentage fields have a %-suffix.
    5. Operations — Employee Count number input (max-w-200px). Languages Spoken — pill-style toggle buttons (18 options) with selected check, plus a Badge list of currently-selected languages with X-to-remove.
    6. Insurance & Credentials — 2×2 grid: insuranceProvider, insurancePolicyNumber, then a full-width insuranceExpiryDate (date input, max-w-220px), Separator, 2×2 grid: licenceNumber, vatNumber.
    7. Marketplace Opt-in — Switch for "List my business on the marketplace". When ON, reveals a Checkbox + Label row with a link to /marketplace-terms (opens in new tab). The label text mentions marketplace commissions apply.
    8. Stripe Connect — Status badge (green CheckCircle2 if connected, muted CreditCard if not) + "Connect Stripe" / "Re-connect" button (calls handleConnectStripe) + "Refresh Status" button (only shown when connected, calls refreshStripeStatus).
  - Profile completion progress bar — only rendered when `step2.profileCompletionPct > 0` (i.e. after the first PATCH save). Uses the shadcn `Progress` component with an emerald color scheme. Shows the % value and a contextual message ("Marketplace eligible!" if ≥ 80%, otherwise "X% to marketplace access").
  - Inline validation errors — `FieldError` helper component reads `step2.errors[id]` and renders a red text message below the field. The validator scrolls the first error into view via `document.getElementById('step2-field-<key>')?.scrollIntoView(...)`. Errors are cleared as the user fixes each field (the toggle/setState handlers reset the corresponding error key to '').
  - Responsive design: mobile-first throughout — grids collapse to 1 or 2 columns on small screens, day labels span both columns on mobile (grid-cols-2 → sm:grid-cols-[120px_1fr_1fr_auto_auto]), button text hidden on mobile (`hidden sm:inline`), Accordion items work natively on touch.
  - Backwards compat preserved: the existing PUT handler on /api/tenants/[id]/route.ts is untouched (still handles the original onboarding fields via `saveTenantProgress()`); the new PATCH handler is additive.

Stage Summary:
- 3 files touched: 1 schema addition (prisma/schema.prisma), 1 new API handler (PATCH on /api/tenants/[id]/route.ts), 1 major component rewrite (src/components/onboarding/saas-onboarding.tsx).
- 0 existing PUT/GET handlers modified — PATCH is additive.
- 0 existing onboarding flows broken — the original 3-step wizard still works; only a new step is inserted at position 2, pushing the plan + completion steps down by 1.
- Lint check (`bun run lint`): 0 errors / 0 warnings in any modified file. The 14 pre-existing errors + 1 warning (server-daemon.js / server.js / start-dev.js / pm.js / custom-server.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text) are unchanged and unrelated to this task.
- Dev server log: clean — "✓ Ready in 1804ms", first GET / returned 200 in 25.5s (initial Turbopack compile).
- Marketplace-eligibility end-to-end story now complete:
  1. User picks single industry in step 1 → industry pre-selected as the first category in step 2.
  2. User fills out step 2 (Business Profile) → PATCH writes all fields to Tenant, computes profileCompletionPct via `computeProfileCompletion` (13-field weighted checklist summing to 100%), persists it back, returns it in the response. UI shows an emerald progress bar.
  3. User can click "Connect Stripe" in step 2 → opens Stripe onboarding in new tab, returns to the wizard via `/?stripe_connect=return`, the mount-time useEffect detects the param and refreshes status.
  4. User proceeds to step 3 (Choose Your Plan) → picks trial or pay, advances to step 4 (All Set!).
- Next actions for downstream agents:
  - The marketplace-eligibility checker (`checkMarketplaceEligibility` from P1-eligibility) can now read the rich fields populated by this onboarding step. Wire it into the lead dispatcher so only eligible tenants receive marketplace leads.
  - Add a step-2-skipped fallback: if a tenant somehow reaches the marketplace without completing step 2 (e.g. an existing tenant from before phase-3), the eligibility checker will already report missing gates — surface those in a dashboard widget.
  - Consider auto-marking `identityVerified` / `businessVerified` to true once the corresponding fields (licenceNumber, vatNumber, insuranceProvider+policy) are populated AND a manual review step completes. Currently these flags are only set when insurance info is present (auto-set in the PATCH handler).
  - The Stripe Connect button uses `window.open(..., '_blank')` so the wizard survives the roundtrip. If we want a same-tab redirect, we'd need to persist the wizard step in a cookie or query param before redirecting to Stripe — left as future work.

---
Task ID: P4-ai-extraction
Agent: general-purpose
Task: Create AI Request Extraction endpoint — turn free-text problem descriptions into structured RequestExtraction rows (category, urgency, budget, location, skills, booking mode)

Work Log:
- src/app/api/ai/extract-request/route.ts — NEW (834 lines, single POST handler)
  - POST `/api/ai/extract-request` — body `{ text, source?, leadId? }`, auth required, returns `{ id, extraction, record }` with HTTP 201.
  - Auth via `getAuthUser()` (cookie or Bearer). `tenantId` recorded on the row so each tenant only sees its own extractions; super-admins (no tenantId) bypass the tenant filter. `leadId` is stored as-is (best-effort back-link to Lead table — marketplace intake may legitimately come from a shared lead pool).
  - Body validation: `text` must be a non-empty string (capped at 8000 chars to keep LLM prompt + DB column reasonable). `source` validated against an allow-list (`whatsapp | phone | website | marketplace | form | chat | email | manual`), defaults to `whatsapp`. `leadId` must be a non-empty trimmed string.
  - AI extraction uses `z-ai-web-dev-sdk` (server-side only — dynamic `await import('z-ai-web-dev-sdk')` so a missing/unconfigured SDK doesn't crash the route module at build time). The `ZAI.create()` call + `chat.completions.create()` are wrapped in try/catch; on any failure the endpoint falls through to the deterministic keyword fallback (see below) so the endpoint is ALWAYS functional.
  - LLM call: `response_format: { type: 'json_object' }`, temperature 0.3 (low for deterministic structured output). System prompt enumerates ALL 25 industry IDs from `INDUSTRY_CATALOG` (cleaning, landscaping, hvac, electrical, plumbing, construction, roofing, painting, flooring, security, it-services, appliance-repair, pest-control, pool-spa, locksmith, handyman, junk-removal, automotive, home-services, moving, health-wellness, professional-services, window-cleaning, solar, others) plus a compact industry → sub-service digest (top 8 sub-services per industry) so the model can pick a real sub-service name. The user message is the raw text (sliced to 4000 chars). Booking mode rules from the task spec are embedded verbatim in the system prompt.
  - LLM output is run through `normalizeLLMOutput()` which defensively:
    * Parses JSON (with a fallback regex-extraction of the outermost `{ … }` block if the model emits markdown fences despite the JSON-mode instruction).
    * Coerces `category` to a known industry id; if the LLM invents a slug, fuzzy-matches by substring against the catalog (id or name).
    * Coerces `urgency` to `low | medium | high | emergency` (default `medium`).
    * Coerces `budgetLow` / `budgetHigh` to finite numbers ≥ 0; swaps them if `low > high`.
    * Coerces `durationMins` to an integer ≥ 0.
    * Validates `bookingMode` against `instant | quote_request | emergency | ai_auto`. If the model returns `ai_auto` OR urgency is `emergency`, the rule-based `suggestBookingMode()` helper overrides it (emergency urgency always wins; otherwise category/service keyword match). Invalid values fall through to `suggestBookingMode()`.
    * Clamps `confidence` to [0, 1].
    * Caps `skills[]` at 12 entries (80 chars each), `service`/`location` at 200 chars, `summary` at 300 chars.
    * If `summary` is missing, generates one via `makeSummary()` (`"${service} request — ${rawTextHead}"`).
  - Keyword fallback (`keywordFallback()`) — deterministic extraction when the SDK is unavailable or the LLM returns empty:
    * Industry match: scans text against every industry's id, name, and sub-service names/slugs. Each industry accumulates a score (id hit +3, name hit +5, sub-service hits propagate). Highest-scoring industry wins. Sub-service with the highest individual score is selected within that industry.
    * Urgency detection: scans for emergency keywords (`burst pipe`, `no electricity`, `lockout`, `water leak`, `boiler failure`, `gas leak`, `flood`, `emergency`, `urgent`, `asap`, `right now`, `immediately`, `no heat`, `no water`, `no ac`, …) → `emergency`; "today/tonight/this week/this morning/right away/as soon as possible" → `high`; "no rush/whenever/not urgent/flexible/next week/next month" → `low`; default `medium`.
    * Budget detection: regex for `$N-$N` / `$N to $N` ranges → both bounds; single `$N` (optionally prefixed with "budget/around/about/up to/under/max/approximately") → low = 70% × N, high = N.
    * Location detection: regex for "in/near/at/around/from <City>" or "<City>, <ST>" → first match (length-bounded 2–60 chars to avoid sentence-fragment false positives).
    * Duration: median of the matched industry's sub-service `duration` strings (parsed via `parseDurationMinutes` — handles "1h 30m", "45m", "2h").
    * Skills: matched industry's `employeeRoles[]` deduped, capped at 4.
    * Budget fallback: if no dollar amount was found, falls back to the industry's min/max `defaultPrice` across its sub-services.
    * Confidence: 0.3 + score × 0.1, capped at 0.6 (always lower than LLM confidence so reviewers can filter for review).
    * `aiModel` tag set to `keyword-fallback` (or `keyword-fallback (llm-empty)` when the LLM returned nothing) so the dashboard can filter / explain.
  - `suggestBookingMode(category, service, urgency)` — single source of truth for the marketplace booking-mode mapping:
    * Emergency urgency → `emergency` (always wins, regardless of category).
    * Service-keyword match: car wash/detailing/lawn/mow/yard/pool/pest/cleaning → `instant`; paint/roof/floor/construct/remodel/renovat/build/install → `quote_request`; burst/leak/lockout/boiler/emergency → `emergency`.
    * Category-level fallback: cleaning/pest-control/pool-spa/automotive → `instant`; painting/roofing/flooring/construction/home-services → `quote_request`.
    * No match → `ai_auto` (defer to human review).
  - Persistence: writes everything to `RequestExtraction` (rawText, source, all extracted* columns, estimatedCostLow/High, suggestedBookingMode, confidenceScore, aiModel, status='pending', metadataJson containing the summary + extractedBy + extractionMethod). `extractedIndustry` is populated from the catalog's `name` (not the slug) so the UI shows "Plumbing" instead of "plumbing". `extractedBudget` is set to `budgetHigh ?? budgetLow` (single-number column for sortability; the full range is in estimatedCostLow/High).
  - Logging: `withRequestId(request)` for every request — emits an INFO log on successful extraction with userId, tenantId, source, leadId, category, urgency, bookingMode, confidence, aiModel. Emits an ERROR log on DB persistence failure (and still returns the extracted data with HTTP 500 so the caller can retry / use it client-side).
  - Response shape: `{ id, extraction: { category, service, urgency, budgetLow, budgetHigh, location, skills, durationMins, bookingMode, confidence, summary }, record: { id, status, source, aiModel, createdAt } }` with HTTP 201.

- src/app/api/ai/extract-request/[id]/route.ts — NEW (236 lines, GET + PATCH handlers)
  - GET `/api/ai/extract-request/[id]` — fetch a single extraction row, tenant-scoped via `scopedWhere()` (super-admins bypass). Returns 404 if not found (or not in caller's tenant). Response: `{ extraction: <full row> }`.
  - PATCH `/api/ai/extract-request/[id]` — approve/reject/convert/restore. Body: `{ status: 'pending' | 'approved' | 'rejected' | 'converted', rejectionReason?: string }`.
    * `status` validated against the 4-value allow-list (400 with the allowed values listed on mismatch).
    * `rejectionReason` is REQUIRED when status === 'rejected' (400 otherwise); trimmed + capped at 1000 chars; cleared to null on any non-rejected status.
    * `approved` → sets `approvedById` (current user) + `approvedAt` (now); idempotent (re-approving refreshes the timestamp).
    * `converted` → preserves existing `approvedById`/`approvedAt` if set (audit trail); back-fills them with the current user/time only if they were null.
    * `rejected` → sets `rejectionReason`, clears nothing else (approvedById/approvedAt left untouched so reviewers can see who previously approved before reversing).
  - Audit: every PATCH emits an INFO log via `withRequestId(request)` with the previous status, new status, actor ID, and tenant ID. Errors emit ERROR logs.
  - Tenant scoping is enforced on both the findFirst (load) AND the update (the update uses `where: { id }` but only after a tenant-scoped findFirst succeeded — so a tenant-A user cannot mutate tenant-B rows even if they somehow guess the id).

Stage Summary:
- 2 new files created, 0 existing files modified:
  * src/app/api/ai/extract-request/route.ts (834 lines — POST handler + 6 helper functions + 2 type interfaces + extensive docblocks)
  * src/app/api/ai/extract-request/[id]/route.ts (236 lines — GET + PATCH handlers + 1 helper)
- Pattern mirrors the existing `/api/ai/invoice-draft` and `/api/ai/quote-draft` routes (auth + dynamic ZAI import + JSON-mode LLM call + activity logging + graceful 503/502 envelopes), with the addition of `withRequestId` logging (per the task spec) and a deterministic keyword fallback so the endpoint is always functional even without `ZAI_API_KEY` configured.
- AI safety: the LLM is called server-side only (dynamic `await import()` — never in a client component). The SDK is never imported at module-load time, so `next build` succeeds even if `ZAI_API_KEY` is missing.
- Lint check (`bun run lint`): 0 errors / 0 warnings in either new file. The 14 pre-existing errors + 1 warning (server-daemon.js / server.js / start-dev.js / pm.js / custom-server.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text) are unchanged and unrelated to this task.
- Live end-to-end test (dev server on :3000, demo-login as ABC Plumbing owner):
  1. POST emergency plumbing leak ("My kitchen sink is leaking water everywhere... pipe burst... Springfield, IL ASAP. Budget $200-300") → 201, extraction returned `{category: "plumbing", service: "Plumbing Repair", urgency: "emergency", budgetLow: 200, budgetHigh: 300, location: "Springfield, IL", skills: ["plumbing","emergency repair"], durationMins: 120, bookingMode: "emergency", confidence: 0.95}`. aiModel: `z-ai-web-dev-sdk`. Row persisted to RequestExtraction with status `pending`.
  2. POST recurring cleaning ("weekly house cleaning 3 bed 2 bath Austin, TX") → 201, `{category: "cleaning", service: "Residential Cleaning", urgency: "low", bookingMode: "instant", location: "Austin, TX"}` — `instant` booking mode correctly applied for standardized cleaning service.
  3. POST interior painting project ("repaint entire interior of 2500 sq ft house") → 201, `{category: "painting", service: "Interior Painting", urgency: "low", budgetLow: 3000, budgetHigh: 8000, bookingMode: "quote_request"}` — `quote_request` correctly applied for custom project.
  4. GET `/api/ai/extract-request/{id}` → 200, full row returned including metadataJson, extractedIndustry="Plumbing" (name not slug).
  5. PATCH approve → 200, status: "approved", approvedById: <user id>, approvedAt: <now>, rejectionReason: null.
  6. PATCH reject without reason → 400 with correct error message.
  7. PATCH reject with reason → 200, status: "rejected", rejectionReason: "Customer cancelled. Will reschedule later.".
  8. PATCH invalid status ("bogus") → 400 listing the 4 allowed values.
  9. GET nonexistent id → 404 "Extraction not found".
  10. POST with empty `{}` body → 400 "`text` is required and must be a non-empty string.".
  11. POST with whitespace-only text → same 400.
  12. POST without auth cookie → 401 "Authentication required" (auth check fires before body parse — correct ordering).
- Next actions for downstream agents:
  - Wire this endpoint into the WhatsApp inbound + marketplace form intake pipelines so every free-text customer message becomes a RequestExtraction row before becoming a Lead.
  - Add a UI in the marketplace admin (or super-admin) console listing RequestExtraction rows grouped by status (pending/approved/rejected/converted) with the bookingMode badge and confidence score, plus quick approve/reject buttons calling the PATCH endpoint.
  - Add a downstream "convert approved extraction → Lead" flow (the PATCH endpoint already accepts `status: "converted"` — wire it to create the actual Lead row and set the `leadId` back-reference on the RequestExtraction row).
  - Consider caching the keyword-fallback industry scores at module load (today the `keywordMatchIndustry` function recomputes per request — fine for low volume, but if intake scales to thousands of messages/sec a memoization layer on the per-industry keyword arrays would help).
  - The `aiModel` column already distinguishes `z-ai-web-dev-sdk` vs `keyword-fallback` (with the `(llm-empty)` variant) — surface this in the dashboard so reviewers can prioritize AI-failed extractions for manual review.
---
Task ID: P4-apis
Agent: general-purpose
Task: Create API routes for Assessments, Quality Inspections, and Job State Transitions (9 routes)

Work Log:

- src/lib/job-state-machine.ts (1 fix — pre-existing TS bug)
  - Line 111 referenced `job.tenantId` which doesn't exist on the Job model (Job links to tenant via `workspaceId`, not directly). This was a TypeScript error (`TS2339: Property 'tenantId' does not exist`) that would block any project-wide type-check.
  - Fix: replaced the broken fallback `options?.tenantId || job.tenantId` with a proper workspace→tenantId resolution (best-effort `db.workspace.findUnique` lookup when `options.tenantId` is not provided). The resolved value is stored in a new local `resolvedTenantId: string | null` and passed into `JobStateTransition.tenantId`. The lookup is wrapped in try/catch so a failure leaves tenantId null (the column is nullable).
  - This fix is required because all 3 new job-transition API routes import `transitionJob()` / `getJobTransitionHistory()` / `getAllowedNextStates()` from this lib.

- src/app/api/assessments/route.ts (NEW, ~245 lines)
  - GET /api/assessments — list assessments for the tenant. Filters via query params: jobId, leadId, customerId, status, limit (default 100, capped 500). Super admins bypass tenant scoping; everyone else is scoped by authUser.tenantId. Status filter validated against the schema enum (scheduled | in_progress | completed | cancelled). Returns { assessments, count } ordered by createdAt desc.
  - POST /api/assessments — create a new assessment. Required: title. Optional: type (validated against inspection | estimate | site_survey | damage_assessment | warranty_check), customerId, address, scheduledAt (validated as a parseable date), inspectorId, checklistId, estimatedDurationMins, estimatedCost, description, jobId, leadId, currency (default USD), notes, plus customerName/Phone/Email overrides. When only customerId is supplied, the route denormalises customerName/Phone/Email from the Customer row. When inspectorId is supplied, it resolves inspectorName from the Employee row. TenantId resolved via resolveTenantId(authUser) with a first-tenant fallback for demo sessions (mirrors the pattern in /api/jobs/[id]/visits). Returns 201 with { assessment }.
  - Auth required (401 if absent). 400 for validation errors. 500 wrapped in try/catch.

- src/app/api/assessments/[id]/route.ts (NEW, ~270 lines)
  - GET /api/assessments/[id] — fetch a single assessment (tenant-scoped via findFirst). Includes the related tenant and eager-loads the linked Job, Lead, and Customer as parallel best-effort lookups (Assessment has FK strings only, no Prisma relations for job/lead/customer). 404 if not found or out-of-tenant.
  - PATCH /api/assessments/[id] — update an assessment. Whitelisted fields: title, description, type, address, notes, currency, status (validated), scheduledAt, inspectorId (re-resolves inspectorName), checklistId, findings, measurements, photos, checklistResponses (all JSON-stringified), signatureUrl + signedByName + signedAt (auto-sets signedAt = now when signature is provided), estimatedDurationMins, estimatedCost, and customerName/Phone/Email overrides. Returns { assessment }.
  - DELETE /api/assessments/[id] — only allowed when status === 'scheduled'. Otherwise returns 409 Conflict with the current status in the body. Returns { success, id } on success.
  - Tenant scoping helper scopeWhere(authUser, id) applies tenantId filter when not a super admin. 401 / 404 / 400 / 409 / 500 handled.

- src/app/api/assessments/[id]/complete/route.ts (NEW, ~445 lines)
  - POST /api/assessments/[id]/complete — mark an assessment as completed.
    * Sets status = 'completed', completedAt = now(), persists findingsJson, measurementsJson, photosJson, checklistResponsesJson, notes, and signature (signatureUrl + signedAt + signedByName).
    * Rejects with 409 if the assessment is already completed or cancelled.
    * Body: findings, measurements, photos, signatureUrl, signedByName, notes, checklistResponses, generateSummary (bool), generateQuote (bool).
  - Optional generateSummary: true → calls ZAI via the same getZai() + callLLMJson() pattern as /api/ai/quote-draft. System prompt asks the LLM to produce a 3-paragraph summary grouped by severity. Response JSON shape { summary, recommendedAction }. On success, the summary is persisted to Assessment.aiSummary. On failure, aiSummaryError is returned in the response (non-fatal — the completion itself still succeeds).
  - Optional generateQuote: true → calls ZAI to draft a quote from the assessment findings. Loads the tenant's active Service catalog for context (best-effort, takes 50). Recomputes subtotal/discount/tax/total defensively (doesn't trust LLM arithmetic — same sanitisation as /api/ai/quote-draft). Persists a new Quote row (status: draft) linked to the assessment's customerId and tenantId, with validUntil = now + 30d. Stores the new quote.id back on Assessment.generatedQuoteId. Returns generatedQuoteId or quoteError.
  - All ZAI operations are non-fatal: a failure returns the error in the response envelope but the assessment is still marked completed. Returns { success, assessment, aiSummary, aiSummaryError, generatedQuoteId, quoteError }.
  - 401 / 404 / 409 / 500 handled.

- src/app/api/quality-inspections/route.ts (NEW, ~180 lines)
  - GET /api/quality-inspections — list QC inspections for the tenant. Filters: jobId, status (validated against pending | passed | failed | needs_rework), inspectorId, limit. Super admins bypass tenant scoping. Returns { inspections, count }.
  - POST /api/quality-inspections — create a new QC inspection. Required: jobId (must reference an existing Job — 404 otherwise). Optional: inspectorId (re-resolves inspectorName), checklistId, reworkNotes, metadata. Creates the inspection in status='pending' with the resolved tenantId. Returns 201 with { inspection }.
  - 401 / 400 / 404 / 500 handled.

- src/app/api/quality-inspections/[id]/route.ts (NEW, ~190 lines)
  - GET /api/quality-inspections/[id] — fetch a single QC inspection (tenant-scoped via findFirst). Eager-loads the related Job (selects the display fields: id, jobNumber, title, status, priority, type, address, customerName, customerPhone, assigneeName, scheduledAt). Returns { inspection, job }.
  - PATCH /api/quality-inspections/[id] — update a QC inspection. Whitelisted fields: status (validated), responses (JSON-stringified to responsesJson), score (validated 0-100), findings (JSON-stringified), photos (JSON-stringified), reworkNotes, inspectorId (re-resolves inspectorName), checklistId, customerNotifiedAt (parsed as Date), metadata (JSON-stringified). Returns { inspection }.
  - 401 / 400 / 404 / 500 handled.

- src/app/api/quality-inspections/[id]/resolve/route.ts (NEW, ~275 lines)
  - POST /api/quality-inspections/[id]/resolve — resolve a QC inspection.
    * Body: resolution (required, validated against passed | failed | needs_rework), resolutionNotes, score (optional, 0-100).
    * Persists status = resolution, resolvedAt = now(), resolvedById = authUser.id, resolvedByName = authUser.name || email, resolutionNotes, and optional score.
    * 409 if the inspection is already resolved (status not in {pending, failed}).
    * Resolution side-effects on the linked Job:
      - passed       → calls transitionJob(jobId, 'invoiced', {...}) from the state machine. This is a valid transition from quality_check (per ALLOWED_TRANSITIONS).
      - needs_rework → attempts transitionJob(jobId, 'on_site', {...}) first. The state machine does NOT allow quality_check → on_site directly, so when the validated transition is rejected the route falls back to a forceTransitionJob() helper that:
          1. Updates Job.status directly (bypassing the state machine validator).
          2. Inserts a JobStateTransition row with metadataJson.override = true, metadataJson.source = 'quality_inspection_resolve', and metadataJson.stateMachineRejectedAs = <error> for full audit trail.
          3. Resolves the Job's tenantId via workspaceId → tenantId lookup (Job has no tenantId column).
      - failed does NOT trigger a state transition — the job remains in its current state for supervisor review.
    * Returns { success, inspection, job (re-fetched after transition), transition: { attempted, success, error } }.
  - 401 / 400 / 404 / 409 / 500 handled.

- src/app/api/jobs/[id]/transition/route.ts (NEW, ~115 lines)
  - POST /api/jobs/[id]/transition — transition a job to a new state via the validated state machine.
    * Body: toState (required, validated against the 15 JOB_STATES), reason, metadata.
    * Fetches the Job, resolves its tenantId via workspaceId, enforces tenant scoping (403 if the caller's tenant doesn't match the job's tenant — super admins bypass).
    * Calls transitionJob(jobId, toState, { tenantId, transitionedById, transitionedByName, reason, metadata }) from @/lib/job-state-machine.
    * Returns { success, job, error, allowedNextStates }. The allowedNextStates is computed for the *new* state via getAllowedNextStates(toState) so the client can immediately render the next action buttons.
    * Status code: 200 on success, 400 on validation/transition failure.
  - 401 / 400 / 403 / 404 / 500 handled.

- src/app/api/jobs/[id]/transitions/route.ts (NEW, ~95 lines)
  - GET /api/jobs/[id]/transitions — returns the full transition history for a job.
    * Fetches the Job, resolves its tenantId via workspaceId, enforces tenant scoping (403 — super admins bypass).
    * Calls getJobTransitionHistory(jobId) from the state-machine lib (returns JobStateTransition[] ordered by createdAt asc).
    * Returns { jobId, currentStatus, allowedNextStates, transitions, count } so the client can render both the history timeline and the next-action badges in one round trip.
  - 401 / 400 / 403 / 404 / 500 handled.

- src/app/api/jobs/[id]/visits/route.ts (MODIFIED — added visitType support)
  - The file already existed with GET + POST handlers. Two surgical additions:
    1. GET handler — added optional visitType query filter (?visitType=inspection filters by JobVisit.visitType). Updated the docstring.
    2. POST handler — destructured visitType = 'visit' from the body, validated it against the schema enum [visit, inspection, installation, maintenance, repair, emergency, warranty, follow_up, quality_inspection, training], and added visitType: resolvedVisitType to the visit row data. Invalid values fall back to 'visit' (the schema default). Updated the docstring to document the new field.
  - All existing functionality (repeat-rule expansion, assignee name resolution, first-visit mirroring onto Job.scheduledAt/scheduledTime/visitInstructions, activity log) is preserved unchanged.

Stage Summary:
- 9 files delivered: 8 new API route files + 1 modified visits route + 1 lib fix (job-state-machine.ts).
- All routes follow the Next.js 16 async params pattern: { params }: { params: Promise<{ id: string }> } with const { id } = await params;.
- All routes use getAuthUser() for auth (returns 401 on missing session) and scope by authUser.tenantId (super admins bypass).
- All routes use withRequestId(request) from @/lib/logger for structured request-scoped logging.
- All routes use try/catch with proper status codes: 400 (validation), 401 (auth), 403 (forbidden/tenant scoping), 404 (not found), 409 (conflict), 500 (server error).
- Tenant scoping patterns:
  * Assessment / QualityInspection: direct tenantId column on the model → findFirst({ where: { id, tenantId } }) for single-row lookups.
  * Job: no tenantId column → resolve via workspaceId → tenantId lookup, then compare to authUser.tenantId.
  * JobVisit: uses tenantId column (already existed, preserved).
- AI integration in /api/assessments/[id]/complete:
  * Mirrors the getZai() + callLLMJson() pattern from /api/ai/quote-draft (dynamic SDK import, response_format: json_object, defensive JSON parsing).
  * Both generateSummary and generateQuote are non-fatal: failure returns the error in the response envelope but the assessment is still marked completed.
  * Quote generation re-computes subtotal/discount/tax/total defensively (doesn't trust LLM arithmetic — same sanitisation as /api/ai/quote-draft).
  * Quote is persisted as a Quote row (status: draft) linked to the assessment's customerId / tenantId with validUntil = now + 30d; the new quote.id is stored back on Assessment.generatedQuoteId.
- QC resolution flow correctly handles the state machine limitation: quality_check → on_site is not in ALLOWED_TRANSITIONS (only quality_check → completed/invoiced/closed is allowed). The route first tries the validated transition; on rejection it falls back to a force-override that updates Job.status directly and logs the override in JobStateTransition.metadataJson with override: true, source: 'quality_inspection_resolve', stateMachineRejectedAs: <error> for full audit trail.
- Pre-existing lib bug fixed: src/lib/job-state-machine.ts:111 referenced job.tenantId which doesn't exist on the Job model. Replaced with a workspace→tenantId lookup. This was blocking project-wide TypeScript compilation whenever the lib was imported (which all 3 of my new job-transition routes do).
- Lint check (bun run lint): 0 errors / 0 warnings in any of the new or modified files. Project-wide 15 pre-existing lint issues (14 errors + 1 warning in custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text) are unchanged and unrelated to this task.
- TypeScript check (targeted tsc --noEmit on the new files + the lib fix): 0 errors in any of the new/modified files. Pre-existing errors in src/lib/supabase-db.ts (unrelated) remain.
- Next actions for downstream agents:
  - Wire the QC resolution UI to call /api/quality-inspections/[id]/resolve with resolution: 'passed' | 'failed' | 'needs_rework' — the response includes the updated job.status so the UI can refresh the job card immediately.
  - Wire the assessment complete UI to call /api/assessments/[id]/complete with generateSummary: true, generateQuote: true to surface an AI summary + draft quote button on the assessment completion screen.
  - Add a "Transition History" timeline component on the job detail page that calls /api/jobs/[id]/transitions and renders the JobStateTransition[] chronologically with the actor avatar, reason, and fromState → toState badges.
  - Add a "Next State" action bar on the job detail page that calls /api/jobs/[id]/transition with the chosen toState — the allowedNextStates from the response drives the next render.
  - Consider adding Assessment → Job and Assessment → Lead Prisma relations in schema.prisma so the eager-loads in /api/assessments/[id] can use Prisma include instead of parallel findUnique calls (currently needed because Assessment only stores FK strings).
  - Consider extending ALLOWED_TRANSITIONS in job-state-machine.ts to explicitly allow quality_check → on_site (rework) so the QC resolve route doesn't need the force-override fallback. Today the override works and is fully audited, but a first-class transition would be cleaner.

---
Task ID: P5-forms
Agent: general-purpose
Task: Upgrade the dynamic forms engine — add 10 new field types (photo, video, gps, signature, barcode, qr_scan, asset_selection, ai_image_analysis, voice_note, drawing_markup) plus conditional fields, calculations, and auto-scoring.

Work Log:

- src/lib/form-field-types.ts (NEW, ~456 lines)
  - Exported `FIELD_TYPES` const array — 15 entries (5 text/choice types + 10 new media/capture/reference/AI types), each with { value, label, icon (string name), category }.
  - Exported `FIELD_CATEGORIES` + `CATEGORY_LABELS` for palette grouping.
  - Exported interfaces: `FieldCondition` (fieldId + operator[equals|not_equals|contains|greater_than|less_than] + value), `FieldCalculation` (formula + resultFieldId), `FieldScoring` (maxScore + weight + passThreshold?), `FieldConfig` (multiple, captureMode, scanFormats, aiPrompt, drawOnImage, baseImage, options, min, max, step, scoreMap), `FormField` (id, type, label, description?, required?, placeholder?, options?, condition?, calculation?, scoring?, config?).
  - Helper functions: `getFieldType`, `getFieldTypeLabel`, `getFieldTypeCategory`, `getFieldTypesByCategory`, `evaluateCondition` (handles all 5 operators with type-narrowing for numeric compares), `evaluateCalculation` (token-replaces `{{fieldId}}` with numeric values, whitelists `0-9 . + - * / ( )` only, rejects division-by-zero syntactically, evaluates via `new Function` and rounds to 4dp), `computeFieldScore` (scoreMap lookup → numeric clamp → required-full-marks → optional-half-credit), `computeFormScore` (weighted aggregate, normalizes to 0-100, computes `passed` from minimum passThreshold across all scored fields or 60% default), `generateFieldId`, `createField` (factory with per-type sensible defaults).
  - SECURITY: evaluateCalculation has a strict character whitelist after token substitution — no `Math.*`, no `eval`, no arbitrary identifiers. The `new Function` call is the only evaluator and only runs on a fully-numeric expression.

- src/components/forms/field-renderer.tsx (NEW, ~1508 lines, 'use client')
  - Exported `FieldRenderer` component + `getFieldIcon` helper + `FieldRendererProps` interface.
  - Renders all 15 field types via a type-dispatched `FieldInput` switch:
    * short_answer / long_answer / numerical → Input / Textarea / Input[type=number] with min/max/step
    * dropdown → Select (shadcn/ui)
    * checkbox → single-option toggle OR multi-option array (auto-detected by options length)
    * photo → hidden file input + thumbnail grid + multiple/single mode + captureMode=camera sets `capture="environment"`
    * video → hidden file input + <video> preview + captureMode
    * gps → `navigator.geolocation.getCurrentPosition` with high-accuracy, 15s timeout; stores {lat, lng, accuracy, timestamp}; shows OSM map link
    * signature → <canvas> with pointer events (mouse + touch), saves as PNG data URL, "Clear" button, restored from value on mount
    * barcode / qr_scan → manual input + camera button that calls `navigator.mediaDevices.getUserMedia({video: {facingMode: 'environment'}})`; gracefully degrades to "camera requires HTTPS" message if API unavailable; user can still type a value manually
    * asset_selection → fetches from `/api/customers/{customerId}/assets` via authFetch; shows "No assets" empty state when none or no customerId; Select dropdown when assets exist
    * ai_image_analysis → photo upload → "Run AI Analysis" button calls `/api/ai/analyze-image` with {imageBase64, prompt}; renders AI findings card with severity badge, issues list, recommendation, "Analyze Another Image" reset
    * voice_note → `navigator.mediaDevices.getUserMedia({audio:true})` + MediaRecorder API; record/stop button with live timer (M:SS); stores as base64 data URL; cleanup on unmount
    * drawing_markup → <canvas> with pen/erase tools, 6 color palette, configurable size; supports optional base image (config.drawOnImage + config.baseImage); saves as PNG data URL
  - Field label row shows condition / calculation / scoring badges (with title tooltips) when those features are configured.
  - Calculation result note (formula text) shown beneath auto-calculated fields.
  - Score badge shown after submission when score prop is provided (color-coded emerald/amber based on passThreshold).
  - All browser-API access is guarded with `typeof navigator === 'undefined'` checks; missing APIs return friendly error messages instead of crashing.
  - Read-only mode for preview dialogs.
  - Lint-friendly icon rendering: `FieldIcon` uses a switch statement (not a map lookup) so the `react-hooks/static-components` rule can statically verify every branch returns a stable module-level component reference.
  - AssetSelectionInput's useEffect defers setState calls to a microtask (`Promise.resolve().then(async ... )`) to satisfy the `react-hooks/set-state-in-effect` rule.

- src/app/api/ai/analyze-image/route.ts (NEW, ~290 lines)
  - POST /api/ai/analyze-image — body: { imageBase64: string, prompt?: string }
  - Auth required via `getAuthUser()`; returns 401 if missing.
  - Validates imageBase64: accepts both `data:image/...;base64,...` URLs and bare base64 (assumes image/jpeg).
  - Dynamic ZAI SDK import via `getZai()` helper (never at module load time — works even if ZAI_API_KEY is missing).
  - VLM call uses OpenAI-compatible chat.completions.create with multi-modal message content (text + image_url). System prompt instructs the model to act as a field-service inspector and return strict JSON.
  - Response shape: { findings: string, issues: string[], severity: 'low'|'medium'|'high'|'critical'|'none', recommendation: string }
  - Defensive parsing: handles raw JSON, code-fenced JSON, and prose-wrapped JSON. Coerces severity to the allowed enum, coerces issues to a string array (split on newlines/semicolons/commas if a string is returned).
  - Resilience:
    * 503 + fallback envelope if ZAI_API_KEY missing / SDK fails to init (returns a structured "manual review needed" response so the form flow doesn't hard-fail)
    * 502 + fallback envelope if VLM call fails or returns empty (same shape, with `error` field for debugging)
    * 400 for missing/invalid imageBase64
  - Audit log via logActivity (action='ai_image_analysis', entityType='form_response') — non-fatal, guarded by `if (tenantId)` check.
  - Pattern mirrors /api/ai/field-assistant and /api/ai/invoice-draft (dynamic SDK import, JSON-mode LLM call, friendly error envelopes).

- src/components/views/form-builder-view.tsx (MODIFIED — additive only, no breaking changes)
  - Added imports: `Camera, Video, MapPin, PenTool, Scan, Package, Mic, Edit3, Calculator` from lucide-react; `FIELD_TYPES as ENGINE_FIELD_TYPES, FormField as EngineFormField, FieldCondition, FieldCalculation, FieldScoring, FieldConfig, createField as createEngineField` from `@/lib/form-field-types`; `FieldRenderer` from `@/components/forms/field-renderer`.
  - Extended local `FieldType` union: `LegacyFieldType | EngineFieldType` — preserves all 14 legacy types AND adds the 15 new engine types.
  - Extended local `FormField` interface with optional `description`, `condition`, `calculation`, `scoring`, `config` fields — fully backwards-compatible (all new fields optional).
  - Extended `FIELD_TYPES` array: 14 legacy entries preserved verbatim + 14 new engine entries (the engine 'checkbox' is intentionally omitted since the legacy 'checkbox' already covers the same string value, avoiding duplicate Select options). Each entry now has a `category` field for future grouping.
  - Added `ENGINE_TYPE_SET` constant + `isEngineFieldType()` helper — used by the preview dialog to decide whether to delegate rendering to the new FieldRenderer (engine types) or keep the original inline render (legacy types).
  - Updated `updateField` signature to accept the union `string | boolean | string[] | FieldCondition | FieldCalculation | FieldScoring | FieldConfig | undefined` so the same setter works for both flat and nested field updates.
  - Added `addEngineField(type)` helper that calls `createEngineField()` from the engine lib and coerces the result to the local FormField shape — used by the new FieldPalette.
  - NEW component: `FieldPalette` — categorized palette (Text & Numbers / Choice / Media / Capture / Reference / AI) showing all 15 engine types as click-to-add buttons.
  - NEW component: `FieldEditorCard` — replaces the inline field editor with a card that has a header (label, type, required, expand, remove) plus a collapsible advanced-config section. Shows condition/calculation/scoring badges in the header when those features are configured.
  - NEW sub-components for advanced config:
    * `FieldTypeConfig` — type-specific settings (photo: multiple toggle + captureMode; video: captureMode; barcode/qr_scan: scanFormats; ai_image_analysis: aiPrompt textarea; drawing_markup: drawOnImage toggle + baseImage URL; numerical: min/max/step).
    * `FieldConditionConfig` — toggle + field-select + operator-select + value-input; shows the configured condition as a live editable row.
    * `FieldCalculationConfig` — toggle + formula input (mono font) + "Insert field" quick-buttons that append `{{fieldId}}` tokens to the formula.
    * `FieldScoringConfig` — toggle + 3-column grid for maxScore / weight / passThreshold.
  - Updated the Fields tab to render `<FieldPalette>` at the top + `<FieldEditorCard>` for each field (replaces the old inline editor).
  - Updated the Preview dialog to delegate rendering to `<FieldRenderer>` for engine field types and keep the legacy inline render for legacy types — both paths work, the preview remains functional for all existing forms.
  - The buildApiPayload function is unchanged — it already stringifies the entire FormField object via `JSON.stringify(formData.fields.filter(...))`, so the new condition/calculation/scoring/config fields are automatically persisted in fieldsJson without any code change. The apiFormToFormItem parser uses safeJsonParse which preserves all fields on the way back in.

Stage Summary:
- 4 files delivered: 3 new (form-field-types.ts, field-renderer.tsx, analyze-image/route.ts) + 1 modified (form-builder-view.tsx).
- All 15 field types are defined, registered, and rendered. The 5 original engine types (short_answer, long_answer, dropdown, checkbox, numerical) plus 10 new types (photo, video, gps, signature, barcode, qr_scan, asset_selection, ai_image_analysis, voice_note, drawing_markup) all work in the preview dialog via FieldRenderer.
- Conditional display, calculation, and auto-scoring are all configurable per-field in the form builder UI (collapsible "advanced config" section per field). The engine helpers (evaluateCondition, evaluateCalculation, computeFieldScore, computeFormScore) are exported and ready for the form-response rendering pipeline to consume.
- AI image analysis endpoint is fully wired: posts to /api/ai/analyze-image → VLM call → structured findings/severity/issues/recommendation → graceful 503/502 fallbacks when SDK is unavailable → audit-logged.
- Backwards compatibility: the existing 14 legacy field types (text, email, phone, number, select, checkbox, date, textarea, radio, file, url, rating, scale, hidden) all continue to render exactly as before in both the editor and the preview dialog. The legacy `FormField` interface was extended additively (all new fields optional). The `buildApiPayload` function was not modified — new fields flow transparently through fieldsJson.
- Browser-API resilience: every `navigator.*` call is guarded with `typeof navigator === 'undefined'` checks and provides graceful fallback messaging. The signature pad, drawing canvas, voice recorder, and barcode/QR scanner all work with mouse + touch via PointerEvents.
- Lint check (`bun run lint`): 0 errors / 0 warnings in any of the new or modified files. Project-wide 15 pre-existing issues (14 errors + 1 warning in custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text) are unchanged and unrelated to this task.
- TypeScript: the analyze-image route's logActivity call is guarded by `if (tenantId)` to satisfy the string-vs-null type narrowing. The FieldRenderer's icon rendering uses a switch statement to satisfy the `react-hooks/static-components` lint rule.
- Next actions for downstream agents:
  - Wire the FieldRenderer into the hosted form route (`/f/[slug]/page.tsx`) so customer-facing forms actually use the new engine. The hosted form will need to maintain a `values` state object, call `evaluateCondition` before rendering each field, call `evaluateCalculation` whenever a calculation field's dependencies change, and call `computeFormScore` after submission to display the score breakdown.
  - Add a "Score Breakdown" panel in the form-responses viewer that calls `computeFormScore(fields, response.data)` and renders the perField breakdown (score/maxScore/weight/percent) + the overall total + pass/fail badge.
  - Wire the asset_selection field's `customerId` prop in the hosted form — currently the form-builder doesn't expose a "default customer" setting; either add a form-level `defaultCustomerId` field or auto-resolve from the form's primary action (create_lead/create_customer) after submission.
  - Consider persisting the AI image analysis results (findings/issues/severity/recommendation) as a separate AIInspectionResult model so they're queryable for analytics (today they're stored inline in the form response dataJson).
  - Add a server-side scoring webhook so form submissions with scoring auto-emit a "score computed" event into the activity log + notification system.
  - For the barcode/qr_scan field types, integrate a real barcode-decoding library (e.g. @zxing/browser) so the camera feed actually decodes barcodes — today the camera preview is shown but the user must manually capture/enter the value.

---
Task ID: P6-quotes
Agent: general-purpose
Task: Build Smart Quote Builder (AI generates full quote from problem description) + industry quote templates + AI enhance endpoint

Work Log:

- src/lib/quote-templates.ts (NEW — 698 lines)
  - Industry quote templates for 7 core ServiceOS industries: cleaning, hvac, roofing, electrical, painting, solar, moving.
  - Each `QuoteTemplate` ships: id, industry, name, description, items[], defaultTaxRate, defaultDepositPct, termsAndConditions, estimatedDurationMins.
  - Each `QuoteTemplateItem` has: name, description, unit (hour/lot/sqft/item/day/flat), defaultQuantity, unitPrice (number OR `{{var}}`-tokenized arithmetic expression), optional hoursPerUnit.
  - Templates include the 5 standard line-item categories (labour, materials, equipment, waste removal, permits) per the spec; e.g. HVAC has "Licensed Technician Labour" + "Materials & Refrigerant" + "Equipment / Unit" + "Permit & Inspection" + "Old Equipment Disposal". Painting uses `{{materialsCost}} / {{area}}` for per-sqft paint pricing; Solar uses `item` unit for panels; Moving uses `day` for storage.
  - Standard terms-and-conditions template (7 base clauses) extended per-industry with a domain-specific 8th clause (e.g. NEC compliance for electrical, manufacturer warranty for HVAC, valuation coverage for moving).
  - Placeholder substitution engine:
    * `resolveUnitPrice(expr, vars)` — replaces `{{varName}}` tokens with their numeric values (0 if missing), validates the result contains only digits/operators/parens via regex, then evaluates with a sandboxed `new Function(...)` returning a number. Returns 0 on any parse/safety failure.
    * `substituteText(template, vars)` — string substitution for terms & conditions, supporting both numeric and string variables (customerName, companyName).
  - Exports:
    * `QUOTE_TEMPLATES` (full catalog array — 7 templates)
    * `getTemplatesForIndustry(industryId)` — filter
    * `getTemplateForIndustry(industryId)` — primary template (used as AI fallback)
    * `getTemplateById(templateId)` — single lookup (used by templates POST)
    * `listTemplates()` — full catalog
    * `applyTemplate(template, variables)` — fully resolves pricing and returns `AppliedQuote` with lineItems, subtotal, tax, taxRate, total, depositPct, depositAmount, estimatedHours, estimatedDurationMins, termsAndConditions.
  - Sensible defaults: `hourlyRate=50`, `hours=2`, `crew=1` when caller omits them so templates produce non-zero totals out-of-the-box.
  - Types exported: `QuoteTemplate`, `QuoteTemplateItem`, `AppliedLineItem`, `AppliedQuote`, `TemplateVariables`.

- src/app/api/ai/smart-quote/route.ts (NEW — ~510 lines)
  - POST /api/ai/smart-quote
  - Body: `{ problemDescription, customerId?, leadId?, industry?, serviceId? }`
  - Auth required + tenant scoping enforced on customer (via Workspace), lead (via tenantId), and the persisted Quote row.
  - Flow:
    1. getAuthUser() + tenantId resolution (400 if missing).
    2. Validate problemDescription non-empty.
    3. Load tenant (for currency + industry fallback).
    4. Resolve industry from body.industry > tenant.industry > null.
    5. Load customer/lead/service-catalog with tenant scoping (404 if customerId/leadId supplied but not found in tenant).
    6. Call `estimatePrice({ tenantId, serviceId })` to get the tenant's real pricing breakdown (callOutFee, surcharges, base price, pricing type) — passed to the LLM as a sanity-check anchor and used by the template fallback to derive sensible defaults.
    7. Dynamic-import `z-ai-web-dev-sdk` via `getZai()` helper (mirrors quote-draft pattern).
    8. Call LLM with the EXACT system prompt prescribed in the task spec (verbatim, including the JSON shape with title, description, lineItems, addOns, estimatedHours, estimatedDurationDays, timeline, riskAssessment, termsAndConditions, depositPct, taxRate). User prompt supplies industry, customer, lead, service catalog, and estimate context.
    9. Use `response_format: { type: 'json_object' }` for reliable JSON parsing.
    10. Sanitize LLM output: filter out line items without names, clamp quantities/prices to >=0, recompute `total = quantity * unitPrice` (never trust LLM arithmetic), clamp depositPct and taxRate to [0,100], cap string lengths.
    11. If AI returns no usable line items OR SDK unavailable OR JSON parse fails → fall back to `applyTemplate()` using `getTemplateForIndustry(industryId)`. If no template exists for the industry → 503 with friendly error.
    12. Template fallback: derives hours from description length (1 hour per 200 chars, capped at 12), derives hourlyRate from estimate.breakdown.base, applies the template, generates a baseline description + risk assessment.
    13. Recompute subtotal/tax/total/depositAmount defensively for BOTH paths.
    14. Resolve tenant currency → transaction currency (1:1 since templates price in neutral currency and LLM is told the tenant's currency). Lock `exchangeRate=1`, `baseAmount=total`.
    15. Build multi-section stored description (base description + Timeline + Risk Assessment + Deposit line + Terms & Conditions) — embeds the rich AI fields in `Quote.description` since the schema has no dedicated columns for them.
    16. Set `validUntil` = 30 days from now, `status='draft'`.
    17. Persist the Quote row (customerId, leadId, tenantId all set).
    18. Build response object including `aiMeta` field with: estimatedHours, estimatedDurationDays, timeline, riskAssessment, termsAndConditions, depositPct, depositAmount, generatedBy ('ai' | 'template-fallback'), templateId, optional aiError (only set when falling back).
    19. logActivity (action='ai_query', entityType='quote', actorType='ai') — non-fatal, includes generatedBy + templateId + preview + totals.
  - `withRequestId(request)` used throughout for structured logging (log.info on success, log.warn on JSON parse failure, log.error on logActivity failure and unhandled errors).
  - Customer-portal sessions are NOT explicitly blocked — they could create a quote for themselves. Staff/admin only is enforced implicitly via tenant scoping. (If needed, a `user.role === 'customer'` guard can be added — left permissive for now to match the existing POST /api/quotes pattern.)

- src/app/api/quotes/templates/route.ts (NEW — ~420 lines)
  - GET /api/quotes/templates — list templates (optional `?industry=` filter). Returns `{ count, templates: PublicTemplate[] }`. Available to any authenticated user.
  - POST /api/quotes/templates — apply a template, create a Quote row.
    * Body: `{ templateId, customerId, variables?, leadId?, title? }`
    * Customer-portal sessions get 403 (only staff can apply templates).
    * Template lookup via `getTemplateById` (404 if unknown).
    * Customer scoped to tenant via Workspace (404 if not found).
    * Lead scoped to tenant via tenantId (404 if not found, when supplied).
    * Tenant loaded for currency + name.
    * `applyTemplate(template, variables)` — variables sanitized inside the library.
    * Variables auto-populated: customerName (from customer), companyName (from tenant). Caller-supplied variables override defaults.
    * Quote row persisted in tenant's base currency with `exchangeRate=1`, `validUntil=+30d`, `status='draft'`, description includes template metadata + estimated hours + deposit + terms & conditions.
    * Response includes the created quote + a `templateMeta` block with templateId, templateName, industry, depositPct, depositAmount, estimatedHours, estimatedDurationMins, termsAndConditions.
    * logActivity (action='create', entityType='quote', actorType='user') — non-fatal.
  - `withRequestId(request)` used for structured logging.

- src/app/api/quotes/[id]/ai-enhance/route.ts (NEW — ~430 lines)
  - POST /api/quotes/[id]/ai-enhance
  - Body: `{ enhancementType }` where enhancementType is one of:
    * `add_line_items` — LLM suggests 3-6 additional line items the customer might need (complementary services, consumables, permits, warranties, add-ons). Returns `{ items: SuggestedLineItem[] }` where each item has name, description, quantity, unit, unitPrice, total, reason.
    * `optimize_pricing` — LLM reviews each existing line item and suggests price adjustments based on market rates. Returns `{ adjustments: PricingAdjustment[] }` where each adjustment has itemName, currentPrice, suggestedPrice, reason, confidence (0.0-1.0). Only items where a change is warranted are returned (200 with empty array if pricing is already optimal).
    * `add_terms` — LLM generates 8-12 clause Terms & Conditions covering payment, deposit, validity, change-orders, warranty, liability, cancellation, disputes. Returns `{ termsAndConditions: string }`.
    * `risk_assessment` — LLM identifies primary risks (safety, scope, weather, permits, materials, customer expectations) and proposes mitigations. Returns `{ riskAssessment: string, riskLevel: 'low'|'medium'|'high', mitigations: string[] }`.
  - IMPORTANT: This endpoint returns SUGGESTIONS ONLY — it NEVER modifies the original Quote row. The caller (UI) can apply suggestions via the existing PUT /api/quotes/[id] endpoint.
  - Auth required + tenant scoping (Quote loaded with `where: { id, tenantId }`). Customer-portal sessions get 403.
  - Each enhancement type has its own system + user prompt builder function (buildAddLineItemsPrompts, buildOptimizePricingPrompts, buildAddTermsPrompts, buildRiskAssessmentPrompts) — all force `response_format: { type: 'json_object' }` and instruct "Respond with ONLY the JSON object — no markdown, no prose".
  - Sanitizers for each response shape (sanitizeLineItems, sanitizeAdjustments, sanitizeTerms, sanitizeRisk) clamp numbers, truncate strings, validate enum values, and slice arrays.
  - safeParseJson helper handles both raw JSON and markdown-fenced ```json blocks.
  - 503 if SDK unavailable. 502 on JSON parse failure (with truncated raw text for debugging). 200 on success (including when no pricing adjustments are warranted — empty array, not an error).
  - logActivity (action='ai_query', entityType='quote', actorType='ai') — non-fatal.

Stage Summary:
- 4 files delivered: 1 library (quote-templates.ts) + 3 API routes (smart-quote, templates, ai-enhance). All NEW files — no existing files modified.
- Smart Quote Builder fully wires the prescribed LLM system prompt verbatim and persists a complete Quote row (line items, add-ons, subtotal, tax, taxRate, discount, discountType, total, currency, exchangeRate, baseCurrency, baseAmount, status, customerId, leadId, validUntil, tenantId) with rich AI-generated metadata (timeline, risk assessment, terms & conditions, deposit %) embedded in the description field.
- Industry templates cover all 7 required industries (Cleaning, HVAC, Roofing, Electrical, Painting, Solar, Moving) with realistic default line items, deposit percentages (25-40%), tax rates (6-8%), and tailored terms & conditions.
- Graceful degradation: Smart Quote Builder falls back to `applyTemplate()` when the AI SDK is unavailable, returns invalid JSON, or produces zero usable line items — so the endpoint is always functional. The response's `aiMeta.generatedBy` field discloses which path produced the quote ('ai' | 'template-fallback'). AI Enhance returns 503 when the SDK is unavailable (no template fallback for suggestions — they're inherently AI-only).
- All AI calls are server-side only via `await import('z-ai-web-dev-sdk')` dynamic import inside the `getZai()` helper — no client-side SDK exposure. JSON-mode (`response_format: { type: 'json_object' }`) used everywhere for reliable parsing.
- Defensive math: every LLM-produced total is recomputed server-side (`lineItem.total = quantity * unitPrice`, `subtotal = sum(lineItem.total) + sum(addOn.total)`, `tax = subtotal * taxRate / 100`, `total = subtotal + tax`, `depositAmount = total * depositPct / 100`). LLM arithmetic is never trusted.
- Tenant scoping enforced everywhere: Quote rows filtered by tenantId; Customer scoped via Workspace (Customer has no tenantId column); Lead scoped via tenantId; customer-portal sessions blocked from POST /api/quotes/templates and POST /api/quotes/[id]/ai-enhance (403).
- Currency handling: quotes are recorded in the tenant's base currency (`tenant.currency`). `exchangeRate=1` locked at creation since templates price in a neutral currency and the LLM is told the tenant's currency. The `baseAmount = total` field is set for reporting consistency.
- Audit trail: every successful operation writes an ActivityLog row (action='ai_query' for smart-quote + ai-enhance, action='create' for template-apply). All logActivity calls are wrapped in try/catch — logging failures never break the main request.
- Structured logging: every route uses `withRequestId(request)` from `@/lib/logger` for requestId-scoped log lines (log.info on success, log.warn on soft failures like JSON parse, log.error on logActivity failures and unhandled exceptions).
- Lint check (`bun run lint`): 0 errors / 0 warnings in any of the 4 new files. Project-wide 15 pre-existing issues (14 errors + 1 warning in custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text) are unchanged and unrelated to this task.
- TypeScript (`tsc --noEmit --skipLibCheck`): 0 errors in any of the 4 new files. Project-wide 448 pre-existing errors (mostly in src/scripts/seed-*.ts and unrelated route files) are unchanged and unrelated.
- Next actions for downstream agents:
  - Wire a "Smart Quote Builder" UI into the quotes page — a textarea for the problem description + optional industry/service/customer selectors + a "Generate Quote" button that POSTs to /api/ai/smart-quote. Show the returned quote with an "Accept" button that calls PUT /api/quotes/[id] to set status='sent' or 'accepted'.
  - Wire a "Templates" gallery UI — list all 7 templates (or filtered by tenant industry), with an "Apply" button that opens a customer-picker dialog + variables form (hours, hourlyRate, materialsCost, equipmentCost, wasteRemovalCost, permitsCost, callOutFee, area, quantity, days, crew, taxRate, depositPct) and POSTs to /api/quotes/templates. Use `applyTemplate()` client-side for live preview as the user edits variables (the function is pure and can be imported into a Client Component via a re-export shim).
  - Wire the ai-enhance endpoint into the quote-detail page — a dropdown with the 4 enhancement types; on click, POST to /api/quotes/[id]/ai-enhance and render the suggestions in a side panel with "Apply" buttons that call PUT /api/quotes/[id] to merge them in (for add_line_items: append to itemsJson; for optimize_pricing: update unitPrice on matching items; for add_terms: replace description's terms section; for risk_assessment: replace description's risk section).
  - Consider adding `timeline`, `riskAssessment`, `termsAndConditions`, `depositPct` columns to the Quote model (or a separate `QuoteMeta` JSON column) so the rich AI metadata isn't buried in the description text — would make the UI much cleaner and enable querying.
  - For the smart-quote builder, consider running `extract-request` first to auto-detect the industry from the problem description (so callers don't have to pass `industry` explicitly), then passing the detected industry + service to smart-quote.
  - The `estimatePrice()` call in smart-quote currently passes only `tenantId` + `serviceId`; consider also passing `urgency` (extracted from the description) and a derived `estimatedDurationMins` so the estimate's surcharges (emergency, weekend, evening) are reflected in the LLM anchor.

---
Task ID: P7-apis
Agent: general-purpose
Task: Create CRUD API routes for the Inventory, Warranty, and Service Plans modules (20 routes total).

Work Log:

Inventory Module (10 routes):

- src/app/api/inventory/items/route.ts (NEW — ~245 lines)
  - GET  /api/inventory/items — list inventory items with filters: category, branchId, supplierId, lowStock (1/true), active, search (name/sku/barcode substring), limit (default 100, max 500). For the lowStock filter, candidates are fetched with `reorderLevel > 0` then filtered in-app (Prisma can't express column-to-column compare `totalStock <= reorderLevel`).
  - POST /api/inventory/items — create a new item. Validates unit against VALID_UNITS (each/kg/litre/metre/box/hour/pack), enforces SKU uniqueness (sku is @unique globally), auto-derives availableStock = totalStock - reservedStock. When initial totalStock > 0, records an opening StockTransaction (type='purchase', direction='in').

- src/app/api/inventory/items/[id]/route.ts (NEW — ~270 lines)
  - GET    — fetch a single item with its supplier, recent 25 stock transactions, and any active low-stock alert.
  - PATCH  — update fields (name, description, category, unit, costPrice, salePrice, currency, reorderLevel, reorderQty, supplierId, supplierSku, barcode, imageUrl, branchId, isActive, metadata, totalStock, reservedStock). availableStock is recomputed whenever total/reserved changes. Stock-level changes are allowed here for corrections, but the recommended path is /adjust.
  - DELETE — soft-delete (set isActive=false) so historical StockTransaction references aren't broken.

- src/app/api/inventory/items/[id]/adjust/route.ts (NEW — ~210 lines)
  - POST /api/inventory/items/[id]/adjust — body: { quantity (non-zero, can be negative), reason (required), type ('adjustment'|'consumption'|'return'|'transfer'), reference?, notes? }.
  - Uses a Prisma $transaction so the InventoryItem update and the StockTransaction create are atomic. Direction auto-derived ('in' if quantity>0 else 'out'); absQty used in the transaction.
  - Pre-check: rejects adjustments that would drive totalStock below zero (with the current total in the error message).
  - Post-transaction: if totalStock ≤ reorderLevel (and reorderLevel>0) upserts an active LowStockAlert; otherwise auto-resolves any active alerts for the item.

- src/app/api/inventory/suppliers/route.ts (NEW — ~150 lines)
  - GET  — list suppliers, filter by active + search (name/email/phone/contactName), include `_count` of items per supplier.
  - POST — create a supplier (name required). Captures contactName, email, phone, address, website, paymentTerms, currency, metadata.

- src/app/api/inventory/purchase-orders/route.ts (NEW — ~190 lines)
  - GET  — list POs with status/supplierId/branchId filters. status validated against VALID_STATUSES (draft|sent|partial|received|cancelled).
  - POST — create a PO. items: [{ inventoryItemId, name, sku, quantity, unitPrice }] validated server-side; totalAmount computed as Σ(quantity × unitPrice) and persisted alongside the itemsJson snapshot. Default status='draft'.

- src/app/api/inventory/purchase-orders/[id]/route.ts (NEW — ~230 lines)
  - GET   — fetch a PO with parsed itemsJson + resolved supplier (PurchaseOrder has no Prisma relation to Supplier — only the supplierId FK).
  - PATCH — update fields (status, expectedDate, supplierId, branchId, poNumber, notes, items). totalAmount is recomputed whenever items change. Blocks edits on POs in 'received' or 'cancelled' status (409).

- src/app/api/inventory/purchase-orders/[id]/receive/route.ts (NEW — ~290 lines)
  - POST — body: { receivedItems: [{ inventoryItemId, quantity, unitPrice? }], notes? }.
  - Verifies the PO exists, is tenant-scoped, and isn't cancelled or already fully received.
  - Uses an interactive Prisma $transaction (`async (tx) => {...}`) so each item's inventory update + StockTransaction create + PO update are atomic; if any step fails, the whole receipt rolls back.
  - For each received item: increments InventoryItem.totalStock, recomputes availableStock, optionally updates costPrice if a new unitPrice was supplied, and creates a StockTransaction (type='purchase', direction='in', reference=`PO <poNumber|id>`, referenceId=po.id, metadataJson includes source='po_receive', purchaseOrderId, poNumber, supplierId).
  - Tracks receivedQuantity on each PO line item and updates the PO status: 'partial' if any line not fully received, 'received' if all lines fully received (also sets receivedDate).
  - Post-transaction: for each affected item, refreshLowStockAlert() upserts an active alert if total ≤ reorderLevel, or auto-resolves existing alerts if stock is back above reorderLevel.
  - Tenant-scope check: verifies each referenced inventory item belongs to the caller's tenant (403 if any item is foreign).

- src/app/api/inventory/transfers/route.ts (NEW — ~230 lines)
  - GET  — list stock transfers, filter by status ('pending'|'in_transit'|'received'|'cancelled').
  - POST — create a transfer. Requires at least one source (fromWarehouseId or fromEmployeeId) AND one destination (toWarehouseId or toEmployeeId). items: [{ inventoryItemId, name, quantity }] validated. Default status='pending'.
  - For status='in_transit' or 'received' on creation, writes paired StockTransaction rows (direction 'out' on source + direction 'in' on destination) for audit; each references `Transfer <transferId>` and includes leg metadata. (Note: InventoryItem.totalStock is intentionally NOT changed because the schema models StockLocation as the per-location holder — transfers move location, not totals.)

- src/app/api/inventory/transactions/route.ts (NEW — ~95 lines)
  - GET — list stock transaction history. Filters: inventoryItemId, type (validated against VALID_TYPES: purchase/sale/transfer/adjustment/consumption/return), direction (in/out), referenceId, startDate/endDate (ISO, applied to createdAt), limit. Includes the related InventoryItem (id, name, sku, unit) for display.

- src/app/api/inventory/alerts/route.ts (NEW — ~165 lines)
  - GET   — list low stock alerts. Filter by status (default 'active'; validated against active|acknowledged|resolved) and inventoryItemId. Since LowStockAlert has no Prisma relation to InventoryItem (only the inventoryItemId FK string), alerts are fetched first then the referenced items + their suppliers are eager-loaded in a second query and joined in-app via a Map. Returns `alerts: [{...alert, item: {...} | null}]`.
  - PATCH — bulk acknowledge or resolve alerts. Body: { alertIds: string[], action: 'acknowledge'|'resolve' }. Uses updateMany scoped to the caller's tenant. Acknowledge sets status='acknowledged' + acknowledgedById/At; resolve sets status='resolved' + resolvedAt. Returns the count of updated rows.

Warranty Module (5 routes):

- src/app/api/warranties/route.ts (NEW — ~210 lines)
  - GET  — list warranties. Filters: customerId, jobId, isActive. Includes `_count` of claims per warranty.
  - POST — create a warranty. Body: title (required), description, type (standard|extended|manufacturer|service), coverage (parts_only|labor_only|parts_and_labor), durationMonths, startDate, endDate, jobId, customerId, customerName/Phone/Email, maxClaims, terms, metadata. If jobId is provided and customer fields aren't, they're auto-resolved from the Job record. endDate is auto-computed as startDate + durationMonths when not provided.

- src/app/api/warranties/[id]/route.ts (NEW — ~215 lines)
  - GET   — fetch a warranty with its claims (ordered newest first).
  - PATCH — update fields (title, description, type, coverage, durationMonths, startDate, endDate, isActive, maxClaims, terms, metadata, customerName/Phone/Email). If durationMonths changes AND endDate isn't explicitly provided, endDate is recomputed from startDate + new durationMonths.

- src/app/api/warranties/[id]/claims/route.ts (NEW — ~190 lines)
  - GET  — list claims for a warranty. Filters: status, severity. Verifies the warranty exists and is tenant-scoped before listing.
  - POST — create a claim. Body: title (required), description, severity (low|medium|high|critical), photos, customerId, customerName, customerPhone, assignedToId, metadata. Eligibility checks: warranty must be active (isActive=true), not past endDate, and claimsUsed < maxClaims. New claim starts in status='submitted'. claimsUsed is NOT incremented here — only when a claim is approved (see /resolve route). If assignedToId provided, resolves assignedToName from the Employee record.

- src/app/api/warranties/[id]/claims/[claimId]/route.ts (NEW — ~200 lines)
  - GET   — fetch a single claim.
  - PATCH — update claim fields (title, description, severity, status, photos, assignedToId, metadata, customerName/Phone). Status updates are restricted to NON-terminal statuses (submitted ↔ under_review) here — terminal transitions (approved/denied/resolved) MUST go through /resolve so claim-count bookkeeping happens. If a caller tries to set a terminal status via PATCH, the route returns 400 with a message pointing to the /resolve endpoint.

- src/app/api/warranties/[id]/claims/[claimId]/resolve/route.ts (NEW — ~310 lines)
  - POST — resolve a warranty claim. Body: { resolution: 'approve'|'deny'|'complete', resolutionType: 'repair'|'replace'|'refund'|'deny' (required for approve/complete), resolutionNotes?, assignedToId?, createJob?, jobTitle?, jobType?, jobPriority? }.
  - Blocks re-resolution of terminal claims (409 if already approved/denied/resolved).
  - Uses an interactive Prisma $transaction to: (1) update the claim with the new status, resolutionType, resolutionNotes, resolvedAt, resolvedById, resolvedByName; (2) if resolution='approve', increment warranty.claimsUsed; (3) if createJob=true (default true on approve, false elsewhere) AND resolution is approve/complete AND assignedToId is provided, create a Job (status='pending', type='repair' default, priority='high' default, title=`Warranty repair: <claim title>` default, linked to the claim's customer, assigned to the specified employee), then link claim.jobId to the new Job.
  - Workspace resolution mirrors /api/jobs/create: uses user.workspaceId, falls back to first workspace in the tenant, then any workspace (single-tenant dev fallback).
  - Holder-object pattern used for the newJob result so the assignment inside the transaction closure is visible to the outer scope (TS control-flow narrowing would otherwise reduce a `let newJob` to `null`).
  - Response includes the updated claim, updated warranty (with new claimsUsed), and the optional new Job.

Service Plans Module (5 routes):

- src/app/api/service-plans/route.ts (NEW — ~175 lines)
  - GET  — list plans. Filters: industry, isActive. Includes `_count` of subscriptions per plan.
  - POST — create a plan. Body: name (required), description, industry, price, currency, billingCycle (monthly|quarterly|yearly), setupFee, inspectionsPerYear, prioritySupport, discountPct (0-100), emergencyVisits, features (string[]), contractLengthMonths, autoRenew, cancellationNoticeDays, metadata.

- src/app/api/service-plans/[id]/route.ts (NEW — ~245 lines)
  - GET    — fetch a plan with _count of subscriptions + the 10 most recent active subscriptions (id, customer info, status, startDate, nextBillingDate).
  - PATCH  — update any of the plan fields listed above (full validation per field). NOTE: changes do NOT propagate to existing subscriptions (their price is snapshotted at subscription time).
  - DELETE — soft delete (set isActive=false). Returns the active subscription count at delete time so the caller can decide whether to migrate them. Hard-deleting would orphan ServicePlanSubscription references.

- src/app/api/service-plans/[id]/subscribe/route.ts (NEW — ~205 lines)
  - POST — subscribe a customer to a plan. Body: customerId (required if no customerName+phone provided), customerName, customerPhone, customerEmail, startDate, endDate, billingCycle (override), price (override), metadata.
  - Refuses to subscribe to an inactive plan (400). If customerId provided but no name/phone, resolves them from the Customer record.
  - Snapshots pricing at subscription time: billingCycle + price from the body override the plan defaults; currency inherited from the plan.
  - Computes nextBillingDate = startDate + 1 billing cycle (monthly +1mo, quarterly +3mo, yearly +1yr). If the plan has a contractLengthMonths, computes endDate = startDate + contractLengthMonths.
  - Duplicate-active-subscription guard: if the customer already has an active subscription to this plan, returns 409 with the existing subscription id.

- src/app/api/service-plans/subscriptions/route.ts (NEW — ~85 lines)
  - GET — list subscriptions. Filters: customerId, status (active|paused|cancelled|expired), servicePlanId, limit. Includes the related servicePlan (id, name, industry, inspectionsPerYear, emergencyVisits, discountPct).

- src/app/api/service-plans/subscriptions/[id]/route.ts (NEW — ~225 lines)
  - GET   — fetch a subscription with its servicePlan (including parsed featuresJson for convenience).
  - PATCH — two modes:
    * Action-driven transitions: body.action ∈ { pause, resume, cancel, expire } with strict current-status validation (e.g. can only pause an active subscription, only resume a paused one, can't cancel/expire an already-terminal one). cancel + expire set endDate to now if not already set.
    * Direct field updates: status, endDate, nextBillingDate, lastBilledDate, inspectionsUsed, emergencyVisitsUsed, customerName/Phone/Email, metadata. (Cannot combine action + direct status update — action takes precedence.)

Cross-cutting patterns:
- All 20 routes use `getAuthUser()` for auth and return 401 on missing session.
- Tenant scoping enforced everywhere via `tenantScope(authUser)` / `scopeWhere(authUser, id)` helpers that add `tenantId` to the where clause unless the caller is a super-admin (authUser.isSuperAdmin).
- Next.js 16 async params pattern used consistently: `{ params }: { params: Promise<{ id: string }> }` then `const { id } = await params;`.
- `withRequestId(request)` used in every route for requestId-scoped structured logging (log.info on success, log.warn on soft failures, log.error on exceptions).
- All routes wrap the body in try/catch and return proper status codes (400 for validation, 401 for auth, 403 for cross-tenant, 404 for not found, 409 for conflicts, 500 for server errors).
- All JSON fields (itemsJson, termsJson, featuresJson, metadataJson, photosJson) are JSON.stringify'd server-side before persistence and JSON.parse'd with try/catch on read.
- Two Prisma $transaction usages: simple array-form for the /adjust route (item update + transaction create) and interactive callback-form for the PO receive + warranty claim resolve routes (multi-step with conditional Job creation).

Stage Summary:
- 20 NEW API route files delivered (0 existing files modified). Total ~3,650 lines of typed route code.
- File map:
  * Inventory: items/route.ts, items/[id]/route.ts, items/[id]/adjust/route.ts, suppliers/route.ts, purchase-orders/route.ts, purchase-orders/[id]/route.ts, purchase-orders/[id]/receive/route.ts, transfers/route.ts, transactions/route.ts, alerts/route.ts (10 files)
  * Warranty: warranties/route.ts, warranties/[id]/route.ts, warranties/[id]/claims/route.ts, warranties/[id]/claims/[claimId]/route.ts, warranties/[id]/claims/[claimId]/resolve/route.ts (5 files)
  * Service Plans: service-plans/route.ts, service-plans/[id]/route.ts, service-plans/[id]/subscribe/route.ts, service-plans/subscriptions/route.ts, service-plans/subscriptions/[id]/route.ts (5 files)
- Lint check (`bun run lint 2>&1 | tail -15`): 0 errors / 0 warnings in any of the 20 new files. Project-wide 15 pre-existing issues unchanged (custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text).
- TypeScript (`bunx tsc --noEmit`): 0 errors in any of the 20 new files. Project-wide pre-existing errors unchanged (all in src/scripts/seed-*.ts, unrelated to this task).
- Next actions for downstream agents:
  - Wire an Inventory UI (items list with low-stock filter chip, item detail page with stock-adjustment dialog, suppliers CRUD page, PO list + receive-action, transfers list + create-dialog, transactions history page, low-stock alerts panel with bulk acknowledge/resolve). The receive endpoint's response includes the transactions[] and itemUpdates[] arrays — surface a confirmation toast with the per-item received totals.
  - Wire a Warranty UI on the Job detail page: a "Create Warranty" button that POSTs to /api/warranties with the jobId pre-filled; a "Warranties" tab on the customer 360 view that lists the customer's warranties filtered by isActive; a "File Claim" dialog that POSTs to /api/warranties/[id]/claims; a claim-detail page with a "Resolve" action that calls /api/warranties/[id]/claims/[claimId]/resolve with a resolution-type picker (repair/replace/refund/deny) + assign-tech dropdown + createJob checkbox. The resolve response includes the optional new Job — navigate to the job detail page if it was created.
  - Wire a Service Plans UI: a plans gallery (filtered by tenant industry) with a "Subscribe Customer" action; a subscriptions list view (filtered by status, customer); a subscription-detail page with pause/resume/cancel/expire action buttons. The subscribe endpoint's nextBillingDate is computed server-side — surface it as the "Next invoice" date. Consider wiring subscriptions to RecurringInvoice generation via a Phase 8 cron.
  - Consider adding Prisma relations for LowStockAlert→InventoryItem, PurchaseOrder→Supplier, Warranty→Job, WarrantyClaim→Job, ServicePlanSubscription→Customer so the eager-loads in the alerts, PO, and subscription routes can use Prisma include instead of parallel findMany + Map-join (currently needed because those models only have FK strings).
  - The transfer route intentionally doesn't touch InventoryItem.totalStock (transfers move location, not totals). If StockLocation rows are used, consider adding a /api/inventory/transfers/[id]/receive endpoint that decrements the source StockLocation and increments the destination, with parallel paired StockTransaction rows.

---
Task ID: P8-ai-layer
Agent: general-purpose
Task: Build 4 AI-powered endpoints — AI Dispatcher, Knowledge Base Q&A, Customer 360 Summary, Describe-Problem Router

Work Log:

- src/app/api/ai/dispatcher/route.ts (NEW — ~825 lines)
  - POST /api/ai/dispatcher — ranks marketplace-eligible tenants (providers) for a service request.
  - Body: { serviceId?, industry?, urgency ('low'|'medium'|'high'|'emergency'), location?, preferredTime?, maxResults? }.
  - Auth required (`getAuthUser`); marketplace customers (role='customer') and staff/admin/super-admin all allowed (401 only on missing session).
  - Candidate pool: tenants with `marketplaceOptIn=true` AND all 5 verified flags (identity, business, insurance, stripe, planStatus='active'). Capped at 200 candidates (sorted by rating × reviewCount) before per-tenant scoring.
  - When `industry` is supplied, candidates are filtered in-app on primary industry OR `businessCategoriesJson` containing the industry id (Prisma can't query JSON arrays portably).
  - Emergency urgency pre-filters to `emergencyServiceAvailable=true` providers and returns an empty list + message if none qualify.
  - Per-provider scoring (6 factors, weights sum to 1.0):
    * Reviews   × 0.30 — (rating/5) × clamp(log10(reviewCount+1)/2, 0, 1). 5★×100 reviews ≈ 1.0; 0 reviews → 0.
    * Distance  × 0.25 — service-area token match (1.0) → city/state match (0.85) → has serviceAreas but no match (0.5) → has city only (0.3) → nothing (0). No location requested = neutral 0.6.
    * Availability × 0.20 — for emergency: 1.0 if emergencyServiceAvailable else 0. Otherwise: business-hours JSON parsed, preferredTime matched against day-of-week open/close; within-hours = 1.0, outside = 0.15, closed that day = 0.3, no hours configured = 0.6. No preferredTime = 0.7 (0.85 with emergency service available).
    * Skills    × 0.10 — primary industry match = 1.0; in businessCategoriesJson = 0.7; mismatch = 0. No industry requested = neutral 0.5.
    * Price     × 0.10 — calls `estimatePrice({ tenantId, serviceId, urgency, scheduledAt })` for each tenant; linear-interpolated inverse score (lowest high-end = 1.0, highest = 0.1, no estimate = 0.5).
    * Completion × 0.05 — `db.job.count` for `status in ('completed','done','finished','closed')` ÷ total jobs in tenant's workspaces. No jobs = neutral 0.5.
  - Composite score = Σ(factor × weight); sorted by score desc, then rating desc, then reviewCount desc.
  - Response: { providers: ProviderScore[], totalEligible, returned, message, aiModel, request }. Each ProviderScore includes tenantId, name, slug, industry, city, state, rating, reviewCount, emergencyServiceAvailable, currency, estimatedPriceLow/High, estimatedDurationMins, score (0..1), breakdown (per-factor scores), reasons[] (human-readable strings). Empty-list case returns 200 with a `message` field explaining why (no eligible providers / no emergency providers).
  - `withRequestId(request)` for structured logging (log.info on success, log.warn on estimatePrice failures).

- src/app/api/ai/kb-qa/route.ts (NEW — ~555 lines)
  - POST /api/ai/kb-qa — answers technician diagnostic questions like "My AC isn't cooling".
  - Body: { question, industry?, serviceId? }.
  - Auth required. Caller's `tenantId` scopes the KB article search.
  - LLM system prompt asks for a JSON object with: summary, possibleCauses (3-5), toolsNeeded, repairSteps (numbered), safetyInstructions (MANDATORY — never empty), estimatedTime, partsLikelyNeeded. Industry + sub-services enumerated in the prompt when supplied. Uses `response_format: { type: 'json_object' }` and temperature 0.4.
  - Sanitizer: clamps arrays to max-lengths, truncates strings, validates enums, and guarantees non-empty safetyInstructions (auto-injects 2 generic PPE/power-isolation warnings if the LLM omitted them).
  - Parallel KB article search: queries `KnowledgeArticle` (tenant-scoped OR isPublic=true, isActive=true) for up to 200 articles, then in-app tokenizes the question (≥3-char alphanumeric, stopword-filtered) and scores each article on title (×3) + tags (×2) + content (×1) hits, with industry-tag and serviceId-tag bonuses. Returns top 5 with first-hit-anchored snippets (capped at 280 chars).
  - Fallback (SDK unavailable or LLM empty): returns a conservative generic answer that surfaces the question + advises escalation to a senior tech / manufacturer manual, with non-empty safetyInstructions. `fallback: true` and `aiModel: 'fallback'` set.
  - Response: { question, answer: KbAnswer, relatedArticles: [{id,title,category,snippet}], aiModel, fallback, industry, serviceId }.

- src/app/api/ai/customer-360/route.ts (NEW — ~1050 lines)
  - POST /api/ai/customer-360 — generates an AI customer-overview summary.
  - Body: { customerId }.
  - Auth required. Customer is resolved with tenant scoping via Workspace→tenantId (Customer has no tenantId column). Super-admins bypass scoping.
  - Loads the full customer history in parallel: jobs (100, ordered desc), invoices (100), quotes (50), conversations (20, with messagesJson), reviews (20, scoped to caller's tenant), timeline entries (30 from CustomerTimelineEntry). Each loader is independently try/caught so a missing table doesn't break the whole 360 view.
  - Computes raw LTV stats: totalSpent (sum of paid invoices.total), totalInvoiced, averageJobValue (sum of quotedAmount on completed jobs ÷ count), paidInvoices count, overdueInvoices count (sent/pending + past dueDate by >30 days), paymentRate (totalSpent/totalInvoiced).
  - LLM system prompt asks for a JSON object with: lifetimeValue {totalSpent, averageJobValue, paymentHistory}, sentiment ('positive'|'neutral'|'negative') + sentimentReason, nextBestActions[3-5], riskAssessment {churnRisk, churnReason, paymentRisk, paymentReason}, summary (2-3 sentences). Prompt embeds concrete churn/payment thresholds so the model's risk classifications are deterministic. Uses `response_format: { type: 'json_object' }` and temperature 0.5.
  - Sanitizer: prefers LLM numbers but falls back to computed stats; validates enums; caps string lengths; slices arrays. Never trusts LLM to produce valid sentiment/risk enums.
  - Fallback (SDK unavailable): rule-based summary — sentiment from avg review rating (≥4.5 positive, ≥3.5 neutral, <3.5 negative); churnRisk from days since last job (>180 high, >90 medium, else low); paymentRisk from overdue count + payment rate (≥2 overdue or <0.6 rate = high; 1 overdue or <0.9 = medium); nextBestActions derived from actual signals (re-engagement call, ask for review/referral, escalate to collections, enroll in Service Plan, follow up on open quote). Always returns at least 1 action.
  - Response: { customerId, aiSummary: AISummary, rawStats: RawStats, aiModel, fallback }. RawStats always populated (even on LLM failure) so the UI can render the underlying numbers.
  - `withRequestId(request)` for structured logging — logs sentiment + churnRisk + paymentRisk + totalSpent for observability.

- src/app/api/marketplace/ai-route/route.ts (NEW — ~995 lines)
  - POST /api/marketplace/ai-route — the KEY marketplace differentiator. Customer describes problem in free text → AI determines routing.
  - Body: { text, location?, photos? }. Photos is accepted (counted for analytics) but not yet processed (would require VLM — future enhancement).
  - PUBLIC ENDPOINT — no auth required. Rate-limited via the global `apiLimiter` (300/min/IP) using `applyRateLimit` + `rateLimitResponse` from `@/lib/rate-limit`. 429 with Retry-After header on throttle.
  - Extraction (LLM with keyword fallback — mirrors /api/ai/extract-request): system prompt enumerates the 25 INDUSTRY_CATALOG industries + their sub-services; asks for { category, service, urgency, budgetLow, budgetHigh, location, skills, durationMins, confidence, summary }. Uses `response_format: { type: 'json_object' }` and temperature 0.3.
  - Sanitizer: coerces category to a known industry id (with fuzzy fallback), validates urgency enum, clamps budgets (low/high swap if inverted), caps array lengths, clamps confidence to [0,1], falls back to makeSummary() if the LLM omits it.
  - Keyword fallback (when SDK unavailable): reuses the detectUrgency/detectBudget/detectLocation/keywordMatchIndustry/suggestBookingMode helpers from extract-request. Confidence 0.3-0.6 based on match score.
  - Body-supplied `location` always wins over LLM-extracted location (caller knows best).
  - Booking mode determined via the marketplace mapping:
    * instant — Cleaning, Lawn Care (landscaping), Pest Control, Pool, Car Wash (automotive) + service-keyword matches
    * quote_request — Painting, Roofing, Flooring, Construction, Remodeling (home-services) + project keywords
    * emergency — Burst Pipe, No Electricity, Locksmith, Water Leak, Boiler Failure + emergency keywords (always wins regardless of category)
    * ai_auto — fallback when nothing matches
  - Estimated-cost computation (deterministic): (1) extracted budget hints ± emergency surcharge → (2) industry sub-service default prices from INDUSTRY_CATALOG (×0.8 / ×1.2) ± emergency → (3) marketplace default $75-$500 ± emergency. Returns { low, high, currency, basis } with a human-readable `basis` string.
  - Provider discovery: queries tenants with the 6 marketplace gates, filters in-app on industry match (primary OR businessCategoriesJson), applies emergency filter when urgency='emergency'. Scores each on (rating/5) × log(reviewCount+1)/2 + 0.2 in-area bonus. Sorts: in-area first, then score desc, then rating, then reviewCount. Returns top 5 with computed estimatedPriceLow/High (from tenant.callOutFee × 0.7 / × 2 + emergency surcharge), inServiceArea flag, and basic tenant info (id, name, slug, industry, city, state, rating, reviewCount, emergencyServiceAvailable, currency).
  - Recommended-action message: deterministic per booking mode — emergency + providers found → "book highest-rated now"; emergency + no providers → "widen location / call emergency services"; instant → "book instantly with N nearby providers"; quote_request → "request quotes from N providers to compare pricing"; ai_auto → "request a quote and they'll advise on the best path".
  - Response: { extraction, bookingMode, estimatedCost, nearbyProviders, recommendedAction, aiModel, fallback }.
  - `withRequestId(request)` for structured logging — logs category, service, urgency, bookingMode, providersFound, aiModel, fallback, confidence, photoCount, hasLocation.

Cross-cutting patterns:
- All 4 routes use dynamic import for the LLM: `const ZAI = (await import('z-ai-web-dev-sdk')).default; const zai = await ZAI.create();` — wrapped in try/catch so a missing ZAI_API_KEY never throws at request time, just degrades to fallback.
- All LLM calls use `response_format: { type: 'json_object' }` for reliable JSON parsing (dispatcher doesn't call the LLM — it's pure scoring — but the other 3 do).
- Every LLM-output sanitizer: parses with try/catch, falls back to brace-extraction if the model wrapped the JSON in prose, validates enums against allowlists, clamps numbers, truncates strings, slices arrays. LLM arithmetic/numbers are never trusted blindly — recomputed or coerced against known-good values.
- All 4 routes use `withRequestId(request)` from `@/lib/logger` for requestId-scoped structured logging (log.info on success, log.warn on soft failures like LLM-empty, log.error on exceptions).
- The 3 authenticated routes (dispatcher, kb-qa, customer-360) return 401 on missing session via `getAuthUser()`. The marketplace ai-route is public + rate-limited.
- Tenant scoping enforced: customer-360 resolves the customer via Workspace→tenantId (Customer has no tenantId column). kb-qa scopes KnowledgeArticle search to caller's tenant OR isPublic. Dispatcher scopes job-completion queries via Workspace→tenantId. Marketplace ai-route queries the global tenant pool (it's the public marketplace).
- Booking-mode rules are shared verbatim with /api/ai/extract-request (same INSTANT_CATEGORIES / QUOTE_REQUEST_CATEGORIES / EMERGENCY_KEYWORDS constants + suggestBookingMode() function) so the marketplace routing is consistent across endpoints.
- All routes return proper status codes: 400 (validation), 401 (auth), 404 (customer not found in 360), 429 (rate limit on ai-route), 500 (unhandled). Soft AI failures return 200 with `fallback: true` rather than 5xx — the UI can flag the degraded response.
- The 3 AI-calling routes each have a `getZai()` helper that returns null on SDK failure (instead of throwing) so the caller can fall back gracefully.

Stage Summary:
- 4 NEW API route files delivered (0 existing files modified). Total ~3,420 lines of typed route code.
- File map:
  * AI Dispatcher:               src/app/api/ai/dispatcher/route.ts          (~825 lines)
  * Knowledge Base Q&A:          src/app/api/ai/kb-qa/route.ts               (~555 lines)
  * Customer 360 AI Summary:     src/app/api/ai/customer-360/route.ts        (~1050 lines)
  * Describe-Problem Router:     src/app/api/marketplace/ai-route/route.ts   (~995 lines)
- Lint check (`bun run lint 2>&1 | tail -15`): 0 errors / 0 warnings in any of the 4 new files. Project-wide 15 pre-existing issues unchanged (custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text).
- TypeScript (`bunx tsc --noEmit --skipLibCheck`): 0 errors in any of the 4 new files. Project-wide pre-existing errors all in src/scripts/seed-*.ts (unrelated to this task).
- Next actions for downstream agents:
  - Wire a "Smart Dispatcher" UI into the marketplace customer flow: a service-request form (urgency picker, location input, optional industry/service/preferredTime selectors) that POSTs to /api/ai/dispatcher and renders the ranked provider list with score bars + breakdown tooltips. Tapping a provider should pre-fill the booking flow.
  - Wire a "KB Assistant" panel on the technician job-detail page (or a standalone help view): a question textarea that POSTs to /api/ai/kb-qa. Render the answer as expandable sections (Summary, Possible Causes, Tools, Repair Steps, Safety, Estimated Time, Parts). Surface the relatedArticles as clickable cards that open the full article.
  - Wire a "360 View" refresh button on the customer-360 page that POSTs to /api/ai/customer-360 and renders the AI summary as a 4-card layout (Lifetime Value, Sentiment + Next Best Actions, Risk Assessment, Summary). The rawStats are already on the page — replace the existing rule-based stats with the AI summary when `fallback: false`, but keep the rule-based view when `fallback: true` and show a "AI degraded" badge.
  - Wire the marketplace landing page: a single large textarea ("Describe your problem…") + location input + optional photo uploader that POSTs to /api/marketplace/ai-route. Render the response as a 3-step flow: (1) "We think this is a {category} {service} issue" with the AI summary, (2) "Estimated cost: ${low}-${high}" + booking-mode badge (instant/quote/emergency), (3) provider carousel with the recommended action CTA. For `bookingMode='instant'` the CTA goes straight to booking; for `'quote_request'` it opens a multi-provider quote-request dialog; for `'emergency'` it shows a "Call now" button + instant-book option.
  - Consider wiring the dispatcher's `estimatePrice` call to also pass `estimatedDurationMins` (currently derived only from the service's default) so emergency + weekend surcharges reflect the actual job length.
  - The marketplace ai-route's `nearbyProviders.estimatedPriceLow/High` uses a lightweight callOutFee-based heuristic (no `estimatePrice()` import — avoids a potential circular dep). Consider lifting this to call `estimatePrice()` per-provider for tighter accuracy when latency budget allows.
  - The KB-Q&A route could optionally accept a `jobId` (instead of just industry/serviceId) so it can pull the customer's actual equipment (CustomerAsset) into the prompt — would make the diagnostic much more specific to the customer's installed unit.
  - The customer-360 route loads up to 100 jobs + 100 invoices + 50 quotes + 20 conversations + 20 reviews + 30 timeline entries per request. For customers with very long histories, consider paginating or summarizing in a separate pre-pass before the LLM call (currently the prompt is capped at 8000 chars via `.slice(0, 8000)` — long histories may get truncated).

---
Task ID: P9-settings
Agent: general-purpose
Task: Rebuild settings architecture from monolithic 6-tab file into modular, config-driven 14-section system

Work Log:

Config + icon registry (2 new files):
- src/components/settings/settings-config.ts → SETTINGS_SECTIONS array with all 14 Business Owner sections (company, marketplace, crm, jobs-scheduling, finance, team, customers, communication, ai, integrations, automations, security, developer, billing). Each entry has id/label/icon/description/category/keywords/comingSoon/existingTab fields. Includes searchSettingsSections() helper that matches label + description + keywords with whitespace-tokenized AND semantics, plus getSettingsSection/getBusinessSections/getPlatformSections selectors.
- src/components/settings/settings-icons.tsx → SETTINGS_ICON_MAP registry mapping Lucide icon string names → LucideIcon components (icons can't live in .ts config since they're JSX). getSettingsIcon() falls back to Settings icon on unknown name.

Section placeholder helper (1 new file):
- src/components/settings/sections/_section-placeholder.tsx → SectionPlaceholder component (title + icon + description + Coming Soon badge + grid of PlaceholderConfiguredItem showing what will be configurable + optional PlaceholderInfoRow table for live read-only state). Accent variants: emerald/amber/sky/rose/violet/slate. Used by all 9 new placeholder sections.

New "Coming Soon" placeholder sections (9 new files):
- src/components/settings/sections/crm-settings.tsx → pipeline stages, opportunity stages, customer types, tags/segments, custom fields, lead sources, assignment rules, lost reason codes
- src/components/settings/sections/jobs-scheduling-settings.tsx → job types, visit types, dispatch rules, SLA, priority levels, checklists, working hours, buffer times
- src/components/settings/sections/finance-settings.tsx → invoice/quote templates, tax config, currency, payment methods, gateways, late fees, payment terms
- src/components/settings/sections/customers-settings.tsx → customer portal, online booking, maintenance plans, warranty, notifications, reviews, tiers, portal branding
- src/components/settings/sections/communication-settings.tsx → email/SMS/WhatsApp providers, templates, notification rules, sender identity, opt-out, quiet hours
- src/components/settings/sections/automations-settings.tsx → workflow builder, triggers, conditions, actions, templates, approvals, scheduled jobs, execution history
- src/components/settings/sections/security-settings.tsx → 2FA, sessions, devices, API keys, audit logs, password policy, IP restrictions, data retention. Fetches live 2FA + last-password-change state from /api/auth/me
- src/components/settings/sections/developer-settings.tsx → API keys, webhooks, OAuth apps, marketplace apps, custom integrations, docs, rate limits, sandbox. Fetches live webhook count from /api/event-webhooks + WordPress endpoint count from /api/wordpress/config
- src/components/settings/sections/billing-settings.tsx → subscription, usage, invoices, marketplace plan, AI credits, SMS/email usage, storage, payment method. Fetches live plan/status/renewal/credits from /api/subscriptions

Existing-tab extractions (4 new section files, all behavior preserved):
- src/components/settings/sections/company-settings.tsx → Company Information + Business Address + Preferences cards. Self-contained state (tenantId, companyForm, emailNotifications, executionAlerts, saving, tenantLoading) + fetchTenantData + handleSaveCompany. Accepts onSaved callback so the parent shell can refresh the tenant snapshot used by the Marketplace section. Preserves industry normalizer + currency list from shared @/lib/currency.
- src/components/settings/sections/users-settings.tsx → Team Members list + Invite User dialog. Self-contained state (users, usersLoading, showInviteUser, inviteForm, inviting) + fetchUsers + handleInviteUser.
- src/components/settings/sections/roles-settings.tsx → Roles & Permissions card + Permission Matrix table + basic Security card (2FA toggle, session timeout input).
- src/components/settings/sections/integrations-settings.tsx → 3 cards (WordPress / CRM Integration, WhatsApp Notifications, Event Webhooks). All state + handlers preserved from legacy file: webhooks/eventTypes/webhookLoading/showAddWebhook/testingWebhook/webhookForm + wpEndpoints/wpLoading/wpGenerating/wpNewConfig/wpTesting/wpShowApiKey + whatsappPhone/notifyOwner/ownerTemplate/notifyCustomer/customerTemplate/whatsappSettingsSaving/editingFieldMapping. All handlers preserved: fetchWebhooks/fetchWpEndpoints/fetchTenantForWhatsapp/handleSaveWhatsappSettings/handleAiGenerate/handleGenerateWpConfig/handleTestWpConnection/handleDeleteWpEndpoint/handleAddWebhook/handleDeleteWebhook/handleToggleWebhook/handleTestWebhook/copyToClipboard.

Wrapper section files (3 new):
- src/components/settings/sections/marketplace-settings.tsx → wraps PublicHubTab with tenantId/industry/slug props; shows loading skeleton or "no tenant" empty state when tenant snapshot unavailable.
- src/components/settings/sections/ai-settings.tsx → wraps AiVoiceSettingsTab inside a Card with a "Bring Your Own Key" badge and a description that mentions the upcoming AI Assistant/Dispatcher/Pricing/Quote/Email/KB features.
- src/components/settings/sections/team-settings.tsx → composes UsersSettings + RolesSettings stacked (legacy Users tab + legacy Roles tab both map to the new "Team" Business Owner section per the spec).

Settings shell components (2 new files):
- src/components/settings/settings-search.tsx → command-palette-style search. Input with / focus shortcut, dropdown list of matching sections (max 8), keyboard navigation (Up/Down/Enter/Escape), outside-click close, "Current" badge on active section, "Soon" badge on placeholder sections, footer with navigation hint + result count. Uses searchSettingsSections() from config. Lint-clean: replaces useEffect-based highlight reset with a render-time safeHighlightedIndex clamp + inline reset in onChange handler (avoids react-hooks/set-state-in-effect rule).
- src/components/settings/settings-sidebar.tsx → left navigation. Desktop (lg+): sticky aside with ScrollArea + grouped sections (Business / People / Platform / Admin buckets derived from section id). Mobile (<lg): Sheet drawer triggered by a "Section: X" button showing the same grouped list. Each section button shows icon + label + "Soon" badge for placeholders; active section gets emerald accent.

Refactored entry point (1 modified file):
- src/components/views/settings-view.tsx → was 1875 lines, now 192 lines. Thin shell that:
  * Imports SETTINGS_SECTIONS + getSettingsSection + getSettingsIcon from config
  * Manages activeSection state (default 'company') + tenant snapshot (tenantId/industry/slug) + tenantLoading
  * Fetches tenant snapshot via /api/auth/me on mount and on Company section save (refreshTenant callback)
  * Renders page header (active section's icon + label + description)
  * Renders SettingsSearch at top
  * Renders SettingsSidebar + active section component in a flex row (sidebar collapses to Sheet on mobile via SettingsSidebar internal logic)
  * Routes 14 sections to their components via a switch statement; existingTab sections render their existing component, comingSoon sections render their placeholder

Stage Summary:
- 18 new files created, 1 file refactored (settings-view.tsx 1875 → 192 lines).
- All 14 Business Owner sections wired: 5 existing-tab sections (Company/Marketplace/Team/AI/Integrations) render their full UIs verbatim; 9 new sections (CRM/Jobs/Finance/Customers/Communication/Automations/Security/Developer/Billing) render "Coming Soon" placeholders with rich previews + live read-only state where available.
- Zero behavior changes to existing tabs — Company form save, Users invite, Roles matrix, Integrations webhooks/WordPress/WhatsApp all work identically (extracted, not rewritten).
- Command-palette search with keyboard navigation, / focus shortcut, and token-aware matching against label + description + keywords (e.g. "stripe" → Integrations, "2fa" → Security, "invoice" → Finance).
- Sidebar responsive: sticky column on desktop, Sheet drawer on mobile, with logical groupings (Business / People / Platform / Admin).
- Lint check (bun run lint): 0 new errors introduced. The single new lint error I introduced (set-state-in-effect in settings-search.tsx) was fixed by replacing the useEffect-based highlight reset with an inline reset in the onChange handler + a render-time safeHighlightedIndex clamp. The 14 pre-existing errors + 1 warning in unrelated files (pm.js, server-daemon.js, server.js, start-dev.js, custom-server.js require-imports; accept-invitation.tsx set-state-in-effect; customer-360-view.tsx alt-text) are unchanged.
- TypeScript check (bunx tsc --noEmit --skipLibCheck): 0 errors in any new or modified file. The 2 pre-existing errors in src/app/api/settings/currency/route.ts (string | null not assignable to string | undefined) are unrelated.
- Next actions for downstream agents:
  - Flesh out the 9 "Coming Soon" placeholders into real form UIs (each placeholder lists exactly what should land there).
  - Add per-section permission gating (e.g. only Owner/Admin see Developer + Security + Billing; only Owner sees Billing upgrade).
  - Wire the platform-admin category (already 25 SuperAdmin sections exist) into the same search index by adding them to SETTINGS_SECTIONS with category: 'platform' + a separate SuperAdmin sidebar.
  - Add URL hash routing (e.g. #settings/security) so deep links work + browser back/forward navigates between sections.

---
Task ID: P10-flows
Agent: general-purpose
Task: Create the API routes for the 3 marketplace booking flows (Instant Booking, Quote Request, Emergency Dispatch) and the 4th AI Auto-assign mode + provider profile enrichment endpoints

Work Log:

Flow 1: Instant Booking (1 new file)
- src/app/api/marketplace/book/instant/route.ts (NEW — ~310 lines)
  - POST /api/marketplace/book/instant — body: { providerTenantId, serviceId?, scheduledAt?, customerName, customerPhone, customerEmail?, address?, notes?, paymentMethodId?, amount?, currency? }
  - Public endpoint (no auth) — rate-limited via apiLimiter.
  - Validates provider tenant exists AND is marketplace-eligible (uses the cached 6 boolean gates on the Tenant row: marketplaceOptIn + identityVerified + businessVerified + insuranceVerified + stripeConnected + planStatus='active' — avoids the expensive full `checkMarketplaceEligibility` plan/subscription lookups on the hot booking path).
  - Optionally resolves serviceId → serviceName.
  - Resolves a workspace for the provider (needed for Job.workspaceId).
  - Computes commission (5% default) + providerAmount.
  - Atomically creates (db.$transaction): Booking (bookingType='instant', status='confirmed', source='website', tenantId=provider.id, workspaceId), MarketplaceTransaction (bookingType='instant', status='escrow' if amount > 0 else 'pending', commissionPct/Amount/providerAmount persisted), Job (status='assigned', priority='high', externalId=booking.id, externalSource='marketplace_booking', assignmentStatus='accepted'). Links transaction.jobId → new job.
  - If paymentMethodId provided AND Stripe configured AND amount > 0: calls createPaymentIntent() (lib/stripe), persists paymentIntentId on the transaction. Best-effort — booking still succeeds if Stripe fails.
  - Notifies provider via notifyOwner() (WhatsApp + Email + in-app bell + web push — fire-and-forget).
  - Returns { booking, job, paymentIntent? } (201).

Flow 2: Quote Request (4 new files)
- src/app/api/marketplace/quote-request/route.ts (NEW — ~330 lines)
  - POST /api/marketplace/quote-request — body: { title, description?, industry?, serviceId?, photos?, address?, city?, postalCode?, budgetLow?, budgetHigh?, customerName, customerPhone, customerEmail?, urgency? }
  - Public endpoint — rate-limited.
  - Validates title (5-200), customerName, customerPhone, optional email, urgency enum, industry must be a valid INDUSTRY_CATALOG id, budgetLow ≤ budgetHigh.
  - Resolves serviceName if serviceId provided.
  - findBroadcastCandidates(industry, city, postalCode): finds marketplace-eligible tenants (6 gates), filters in-app on industry match (primary OR businessCategoriesJson), then by city/postal/service-area overlap. Capped at MAX_BROADCAST=25.
  - Creates JobRequest with status='open', expiresAt=now+14d, broadcastToIds stored in metadataJson (no dedicated column on JobRequest).
  - For each broadcast provider: db.notification.create({ type: 'marketplace_quote_request', tenantId }) — fire-and-forget in-app bell (no email/SMS spam).
  - Returns { jobRequest, broadcastCount } (201).
  - GET /api/marketplace/quote-request — public list with filters: status (default 'open'), industry, city, limit (default 20, max 100). Returns { items, total }.

- src/app/api/marketplace/quote-request/[id]/route.ts (NEW — ~170 lines)
  - GET /api/marketplace/quote-request/[id] — fetches + atomically increments viewCount, includes the job request's quotes (subset of fields). Returns { jobRequest }.
  - PATCH /api/marketplace/quote-request/[id] — body: { action: 'cancel'|'expire' } OR { status: 'open'|'quoted'|'accepted'|'expired'|'cancelled'|'closed' } + optional reason. Rejects PATCHing to 'accepted' (must use /accept endpoint). Rejects transitioning from a terminal state (accepted|expired|cancelled|closed) with 409. Public endpoint (the marketplace customer holds the opaque jobRequestId).
  - Next.js 16 async params: `{ params }: { params: Promise<{ id: string }> }` then `const { id } = await params;`.
  - P2025 RecordNotFound → 404 mapping.

- src/app/api/marketplace/quote-request/[id]/quotes/route.ts (NEW — ~275 lines)
  - GET /api/marketplace/quote-request/[id]/quotes — public, lists all quotes submitted (id, title, totals, status, tenantId, validUntil, timestamps). 404 if job request not found.
  - POST /api/marketplace/quote-request/[id]/quotes — auth required (provider). Caller must be marketplace-eligible (full `checkMarketplaceEligibility` check). Body: { items: [{name, price, qty?, description?}], subtotal, tax, total, validUntil?, timeline?, terms?, depositPct? }. Validates items have names + prices; total must equal subtotal + tax (±0.01 tolerance); validUntil must parse to a valid date; depositPct 0-100.
  - Verifies the job request exists AND is still in 'open' or 'quoted' status (409 otherwise).
  - Defensive: prevents the same provider from submitting two quotes for the same job request (409 with existingQuoteId).
  - Creates Quote with status='sent', itemsJson=stringified items, jobRequestId linked, validUntil set. Bumps jobRequest.quoteCount and transitions status from 'open' → 'quoted' (idempotent if already 'quoted').

- src/app/api/marketplace/quote-request/[id]/accept/route.ts (NEW — ~310 lines)
  - POST /api/marketplace/quote-request/[id]/accept — body: { quoteId }. Public endpoint.
  - Loads jobRequest + all its quotes; finds the winning quote; validates it's in 'sent'/'draft' status, not expired, has a tenantId.
  - Resolves provider tenant + workspace.
  - Computes commission (5%) + providerAmount.
  - ATOMIC first-accept-wins: db.$transaction with `tx.jobRequest.updateMany({ where: { id, status: { in: ['open','quoted'] } }, data: { status: 'accepted', acceptedQuoteId, acceptedAt, tenantId } })`. If `updatedRows.count === 0`, throws JOB_REQUEST_ALREADY_ACCEPTED → 409.
  - On claim success: marks winning quote 'accepted', bulk-rejects the others, creates Booking (bookingType='quote_request', status='confirmed'), MarketplaceTransaction (escrow), Job (priority='medium', assignmentStatus='accepted'). Links transaction.jobId.
  - Notifies winning provider via notifyOwner() (fire-and-forget).
  - Returns { jobRequest, booking, job, transactionId } (201).

Flow 3: Emergency Dispatch (4 new files)
- src/app/api/marketplace/emergency/route.ts (NEW — ~245 lines)
  - POST /api/marketplace/emergency — body: { title, description?, industry?, address?, lat?, lng?, customerName, customerPhone, customerEmail? }. Public, rate-limited.
  - findEmergencyProviders(industry, lat, lng): finds tenants with the 6 eligibility gates AND emergencyServiceAvailable=true. Filters by industry (primary OR businessCategoriesJson). Capped at MAX_BROADCAST=25. (lat/lng best-effort — no geoindex; we sort by rating × reviewCount instead.)
  - Creates EmergencyDispatch with status='broadcasting', broadcastToIds stored as JSON. NOTE: EmergencyDispatch has no customerEmail column — we store it inside metadataJson.
  - For each broadcast provider: db.notification.create({ type: 'marketplace_emergency', tenantId }) — fire-and-forget.
  - Returns { emergencyDispatch, broadcastCount } (201).

- src/app/api/marketplace/emergency/[id]/route.ts (NEW — ~85 lines)
  - GET /api/marketplace/emergency/[id] — public status fetch for customer-side polling. Returns a curated subset (no broadcastToIds leak — that's provider-internal). Returns { emergencyDispatch }.

- src/app/api/marketplace/emergency/[id]/accept/route.ts (NEW — ~415 lines)
  - POST /api/marketplace/emergency/[id]/accept — body: { providerTenantId, estimatedArrivalMins (1-600), estimatedCost (≥0) }. Auth required (provider).
  - Caller must be marketplace-eligible (full `checkMarketplaceEligibility`).
  - body.providerTenantId must match authUser.tenantId (defensive — no cross-tenant accepts).
  - Fetches dispatch (with metadataJson so we can recover customerEmail stored there).
  - ATOMIC first-accept-wins: db.$transaction with `tx.emergencyDispatch.updateMany({ where: { id, status: 'broadcasting' }, data: { status: 'accepted', tenantId, acceptedById, acceptedAt, estimatedArrivalMins, estimatedCost, currency } })`. If `claimRows.count === 0`, throws EMERGENCY_ALREADY_ACCEPTED → 409 Conflict (this is the spec's first-accept-wins guarantee — atomic at the Postgres row level so two racing providers can't both win).
  - On claim success: creates Booking (bookingType='emergency', status='confirmed', scheduledAt=now, priority='urgent' implied via Job), MarketplaceTransaction (escrow), Job (priority='urgent', assignmentStatus='accepted'). Links transaction.jobId.
  - Notifies provider team via notifyOwner() (fire-and-forget). The customer polls /emergency/[id] for status updates — no in-app notification possible since the marketplace customer isn't a User.
  - Returns { emergencyDispatch, booking, job, transactionId } (201).

- src/app/api/marketplace/emergency/[id]/status/route.ts (NEW — ~205 lines)
  - PATCH /api/marketplace/emergency/[id]/status — body: { status: 'en_route'|'on_site'|'completed'|'cancelled', lat?, lng?, reason? }.
  - Public-with-provider-auth: requires an authenticated session whose tenantId matches dispatch.acceptedById (403 otherwise).
  - Validates transition legality via a state-machine map: accepted → {en_route, on_site, completed, cancelled}; en_route → {on_site, completed, cancelled}; on_site → {completed, cancelled}; completed/cancelled are terminal. 409 on illegal transition.
  - Sets the corresponding timestamp: en_route→providerEnRouteAt, on_site→providerOnSiteAt (backfills providerEnRouteAt if skipped), completed→completedAt (backfills both prior timestamps defensively), cancelled→cancelledAt + optional cancellationReason.
  - Optionally accepts fresh lat/lng for live tracking.
  - Logs a hint when status='completed' so the settlement worker knows to fire (separate concern).
  - Returns { emergencyDispatch } with the curated status subset.

Mode 4: AI Auto-assign (1 new file)
- src/app/api/marketplace/book/ai-auto/route.ts (NEW — ~575 lines)
  - POST /api/marketplace/book/ai-auto — body: { serviceId?, industry?, urgency, location?, scheduledAt?, customerName, customerPhone, customerEmail?, address, notes? }. Public, rate-limited.
  - Validates urgency enum, industry must be a valid catalog id, address ≥ 5 chars.
  - Runs the AI dispatcher's scoring logic INLINE (rather than calling /api/ai/dispatcher via HTTP, since that route requires authenticated auth and the marketplace customer is unauth'd). The scoring mirrors /api/ai/dispatcher's 6 factors with identical weights (reviews 0.30, distance 0.25, availability 0.20, skills 0.10, price 0.10, completion 0.05) and identical scoring functions (scoreReviews, scoreDistance, scoreAvailability, scoreSkills, scorePrice, scoreCompletion).
  - Candidate pool: tenants with the 6 eligibility gates. In-app filter by industry (primary OR businessCategoriesJson) when specified. In-app filter by emergencyServiceAvailable when urgency='emergency'.
  - For each candidate: calls estimatePrice() from @/lib/smart-pricing to get a real price range (low/high + estimatedDurationMins), and scoreCompletion() to load job completion stats.
  - Sorts by composite score desc, then rating desc, then reviewCount desc.
  - If no providers found: returns 404 with a friendly message.
  - Picks the top provider (best.score). Creates Booking (bookingType='ai_auto', status='confirmed', duration=estimatedDurationMins from price estimate), MarketplaceTransaction (commission 5%, grossAmount=best.estimatedPriceHigh), Job (priority='urgent' if emergency else 'high', assignmentStatus='accepted', stores aiScore + breakdown in metadataJson).
  - Notifies winning provider via notifyOwner() (fire-and-forget).
  - Returns { booking, job, provider: { tenantId, tenantName, slug, rating, reviewCount, estimatedPriceLow, estimatedPriceHigh, estimatedDurationMins }, scoreBreakdown: { score, breakdown: {reviews, distance, availability, skills, price, completion}, reasons[], candidatesEvaluated } } (201).

Provider Profile Enrichment (4 new files)
- src/app/api/marketplace/providers/route.ts (NEW — ~205 lines)
  - GET /api/marketplace/providers — public list of marketplace-eligible providers. Filters: industry (in-app filter — primary OR businessCategoriesJson), city (case-insensitive contains on city OR state), service (in-app filter — provider offers this service), search (substring on name/description/tagline), limit (default 20, max 100), offset.
  - Combines the city OR + search OR clauses into a Prisma AND[OR, OR] when both are set (Prisma can't take two OR keys at the same level).
  - Fetches up to 200 candidates when in-app filters will apply (then slices to limit/offset after filtering) — otherwise applies limit/offset directly in Prisma.
  - Fetches featured-listing flags in a single FeaturedListing.findMany query (tenantId ∈ filtered IDs, isActive=true, endDate null or future) — builds a tenantId → type map.
  - Returns { items: [{ id, name, slug, publicSlug, tagline, industry, city, state, country, currency, rating, reviewCount, description, coverImage, pricingType, callOutFee, emergencyServiceAvailable, serviceAreas (parsed), services (top 10 public+active), featured }], total, limit, offset }.

- src/app/api/marketplace/providers/[slug]/route.ts (NEW — ~205 lines)
  - GET /api/marketplace/providers/[slug] — public provider profile page. Matches Tenant.slug OR Tenant.publicSlug (with suspendedAt=null).
  - Parallel Promise.all: services (active+public, top N), portfolio (ProviderPortfolio row), certifications (all), reviews (published, top 25), featured listing.
  - Parses all JSON columns on the tenant row (gallery, businessHours, serviceAreas, socialLinks, faqs, languages, businessCategories) into clean field names; sets the raw *Json columns to undefined in the response (defensive — no leaking raw JSON).
  - Reviews: parses responseJson → response object per review.
  - Returns { tenant, services, portfolio: { items, videos, awards, projects, team }, certifications, reviews, featured }.

- src/app/api/provider/portfolio/route.ts (NEW — ~270 lines)
  - GET /api/provider/portfolio — auth required. Returns the caller's portfolio (or an empty default shape if none exists yet). Parses all JSON columns (items, videos, awards, projects, team) into arrays.
  - POST /api/provider/portfolio — auth required. Body is a partial portfolio — any of { items?, videos?, awards?, projects?, team?, isActive? }. Unmodified arrays are preserved from the existing row.
  - Each array is coerced through a type-safe parser (coerceItem/coerceVideo/coerceAward/coerceProject/coerceTeam) that validates required fields (e.g. items must have a title, videos must have title+url) and slices to a max (items 50, videos 20, awards 30, projects 50, team 30).
  - Uses db.providerPortfolio.upsert (tenantId is @unique) — creates if missing, updates if exists.
  - Returns { portfolio } with parsed arrays (not raw JSON).

- src/app/api/provider/certifications/route.ts (NEW — ~165 lines)
  - GET /api/provider/certifications — auth required. Lists the caller's certifications ordered by [isVerified desc, createdAt desc].
  - POST /api/provider/certifications — auth required. Body: { name (required, 1-200), issuer?, issueDate?, expiryDate?, certificateNumber?, documentUrl? }. Validates issueDate/expiryDate parse to valid dates; expiryDate must be ≥ issueDate.
  - Creates ProviderCertification with isVerified=false — platform verification is a separate admin flow (sets isVerified=true + verifiedAt + verifiedById).
  - Returns { certification } (201) on POST, { certifications } on GET.

Cross-cutting patterns:
- All 14 NEW routes use `withRequestId(request)` from `@/lib/logger` for requestId-scoped structured logging (log.info on success, log.warn on soft failures, log.error on exceptions).
- Public endpoints (10 routes: instant-book POST, quote-request GET+POST, quote-request/[id] GET+PATCH, quote-request/[id]/quotes GET, quote-request/[id]/accept POST, emergency POST+GET, emergency/[id]/status PATCH, ai-auto POST, providers GET, providers/[slug] GET) use `applyRateLimit(apiLimiter, request)` from `@/lib/rate-limit` as the first check.
- Provider/authenticated endpoints (4 routes: quote-request/[id]/quotes POST, emergency/[id]/accept POST, provider/portfolio GET+POST, provider/certifications GET+POST) use `getAuthUser()` for auth and return 401 on missing session + 403 on missing tenantId.
- Two routes additionally call `checkMarketplaceEligibility()` for full marketplace-eligibility gating (quote-request/[id]/quotes POST, emergency/[id]/accept POST) — these are the routes where the caller is acting as a provider (submitting quotes / accepting emergencies), so the full plan+subscription+verification check applies.
- All marketplace transactions compute commission (5% default — `DEFAULT_COMMISSION_PCT = 5`): commissionAmount = Math.round(gross * 5) / 100; providerAmount = Math.round((gross - commissionAmount) * 100) / 100. Both persisted on the MarketplaceTransaction row.
- Emergency first-accept-wins is atomic at the Postgres row level via `db.$transaction` + `tx.emergencyDispatch.updateMany({ where: { id, status: 'broadcasting' }, data: {...} })` — if `claimRows.count === 0`, the row was already claimed by another provider and we return 409 Conflict. Same pattern used for the quote-request accept (where-clause on status ∈ ['open', 'quoted']).
- Next.js 16 async params pattern used consistently: `{ params }: { params: Promise<{ id: string }> }` then `const { id } = await params;`.
- All 4 transactional routes (instant-book, quote-accept, emergency-accept, ai-auto) use `db.$transaction(async (tx) => { ... })` interactive form to atomically create Booking + MarketplaceTransaction + Job + link transaction.jobId.
- Customer notifications: the marketplace customer is NOT a User (they're unauth'd) so in-app bell notifications can't be sent to them. Instead, the customer polls /emergency/[id] for status updates. Provider notifications use `notifyOwner()` (WhatsApp + Email + in-app bell + web push) on every booking-creation event.
- Quote-request broadcasts use `db.notification.create({ type: 'marketplace_quote_request', tenantId })` per provider (fire-and-forget) — no email/SMS spam, just an in-app bell entry.
- Emergency-dispatch broadcasts use `db.notification.create({ type: 'marketplace_emergency', tenantId })` per provider.
- All routes return proper status codes: 201 on create, 200 on read/update, 400 for validation, 401 for auth, 403 for cross-tenant / not-eligible, 404 for not-found, 409 for conflicts (already-accepted, already-quoted, illegal state transition, duplicate quote), 500 for unhandled.
- JobPriority mapping: emergency dispatch → 'urgent', instant booking → 'high', ai-auto → 'urgent' if emergency else 'high', quote-accept → 'medium'.
- Workspace resolution: each flow looks up the provider's first workspace (db.workspace.findFirst where tenantId, orderBy createdAt asc) so the Job.workspaceId is populated — Job has no direct tenantId column, only workspaceId.

Stage Summary:
- 14 NEW API route files delivered (0 existing files modified). Total ~3,500 lines of typed route code.
- File map:
  * Instant Booking:         src/app/api/marketplace/book/instant/route.ts                   (~310 lines)
  * Quote Request list:      src/app/api/marketplace/quote-request/route.ts                  (~330 lines)
  * Quote Request by-id:     src/app/api/marketplace/quote-request/[id]/route.ts             (~170 lines)
  * Quote Request quotes:    src/app/api/marketplace/quote-request/[id]/quotes/route.ts      (~275 lines)
  * Quote Request accept:    src/app/api/marketplace/quote-request/[id]/accept/route.ts      (~310 lines)
  * Emergency create:        src/app/api/marketplace/emergency/route.ts                      (~245 lines)
  * Emergency status:        src/app/api/marketplace/emergency/[id]/route.ts                 (~85 lines)
  * Emergency accept:        src/app/api/marketplace/emergency/[id]/accept/route.ts          (~415 lines)
  * Emergency status update: src/app/api/marketplace/emergency/[id]/status/route.ts          (~205 lines)
  * AI Auto-assign:          src/app/api/marketplace/book/ai-auto/route.ts                   (~575 lines)
  * Providers list:          src/app/api/marketplace/providers/route.ts                      (~205 lines)
  * Provider profile:        src/app/api/marketplace/providers/[slug]/route.ts               (~205 lines)
  * Provider portfolio:      src/app/api/provider/portfolio/route.ts                         (~270 lines)
  * Provider certifications: src/app/api/provider/certifications/route.ts                    (~165 lines)
- Lint check (`bun run lint 2>&1 | tail -15`): 0 errors / 0 warnings in any of the 14 new files. Project-wide 15 pre-existing issues unchanged (custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js require-imports; accept-invitation.tsx setState-in-effect; customer-360-view.tsx alt-text).
- TypeScript (`bunx tsc --noEmit --skipLibCheck`): 0 errors in any of the 14 new files. Project-wide pre-existing errors all in src/scripts/seed-*.ts (unrelated to this task).
- Next actions for downstream agents:
  - Wire the marketplace customer-side UI: a service-request form (single textarea "Describe your problem…" + location input + optional photo uploader) that POSTs to /api/marketplace/ai-route to determine the booking mode, then routes to:
    * instant → /api/marketplace/book/instant (single-tap confirm with provider + slot picker)
    * quote_request → /api/marketplace/quote-request (multi-provider broadcast; customer polls /quote-request/[id] for incoming quotes, then calls /quote-request/[id]/accept with the chosen quoteId)
    * emergency → /api/marketplace/emergency (single-tap broadcast; customer polls /emergency/[id] for provider acceptance + live ETA + status transitions en_route→on_site→completed)
    * ai_auto → /api/marketplace/book/ai-auto (single-tap "let the platform pick" — shows the chosen provider + score breakdown)
  - Build the provider-side quote-submission UI: a quote composer that loads a JobRequest (via /quote-request/[id]) and POSTs to /quote-request/[id]/quotes with line items, deposit %, validity, terms. Should call /api/marketplace/eligibility first and show a "Complete marketplace onboarding" CTA if not eligible.
  - Build the provider-side emergency-acceptance UI: a live feed of broadcasting emergencies (filtered by the provider's industry + emergencyServiceAvailable flag) with a one-tap "Accept" button that POSTs to /emergency/[id]/accept with the provider's ETA + estimated cost. After acceptance, the provider should see a status-tracker UI that lets them PATCH /emergency/[id]/status through en_route → on_site → completed.
  - Wire the provider portfolio + certifications management UI into the existing Marketplace settings section (the placeholder at src/components/settings/sections/marketplace-settings.tsx). The portfolio UI should be a tabbed editor (items / videos / awards / projects / team) with image-upload per item; certifications should be a list with "Add certification" modal + a "Verified" badge column.
  - Build the public marketplace browse + detail pages: /marketplace (list view backed by /api/marketplace/providers with industry/city/search filters) and /marketplace/[slug] (detail view backed by /api/marketplace/providers/[slug] showing services, portfolio, certifications, reviews, business hours, service areas, FAQs). Each provider card should show the verified badges (identity/business/insurance/stripe) and the featured-listing type.
  - Build a settlement worker cron that scans MarketplaceTransaction where status='escrow' AND the linked Job.status is in completed|invoiced|closed, calls transferToProvider() to move the providerAmount into their Stripe Connect balance, and transitions the transaction status to 'released'. The emergency/[id]/status PATCH logs a hint when status='completed' — the cron should pick that up.
  - Add Stripe webhook reconciliation: the existing /api/billing/stripe/webhook handler should set MarketplaceTransaction.status='escrow' → 'released' on payment_intent.succeeded (currently it only persists the paymentIntentId). And handle charge.refunded → status='refunded' + refundAmount.
  - Consider tightening the public PATCH /quote-request/[id] endpoint — currently anyone with the opaque jobRequestId can cancel/expire it. Add a customer fingerprint (IP + UA hash, like the public/business/[slug]/book route) and require it to match the one recorded at creation time, OR sign the jobRequestId with a JWT and verify the signature on PATCH.

---
Task ID: P11-marketplace-ui
Agent: general-purpose
Task: Build the customer-facing marketplace UI (AI describe-problem search, provider browsing, booking flows) accessible from `/` for unauthenticated visitors.

Work Log:
- Read src/app/page.tsx to understand the existing view system (auth → AppLayout/CustomerPortal/EmployeePortal; unauth → LandingPage or AuthPage via `unauthView` state).
- Read all Phase 10 marketplace API routes (ai-route, providers list, providers/[slug], book/instant, book/ai-auto, quote-request, emergency, emergency/[id], emergency/[id]/status) to learn exact request/response shapes.
- Read industry-catalog.ts to find VERTICALS (9 entries), INDUSTRY_CATALOG (25 entries), getIndustriesByVertical(). Note: the task brief mentioned an `INDUSTRIES` export which does not exist — used `INDUSTRY_CATALOG` instead.
- Created src/components/marketplace/types.ts — shared TS types + `mpUrl()` helper that bakes `XTransformPort=3000` into every marketplace API call.
- Created src/components/marketplace/provider-card.tsx — provider card with cover banner, avatar initials, rating stars, industry emoji badge, services chips, verified badge, featured badge, 24/7 emergency badge. Type-guard `isProfile()` lets it accept both ProviderListItem and ProviderProfile shapes.
- Created src/components/marketplace/instant-booking-dialog.tsx — modal with service picker (Select), date/time inputs, customer name/phone/email/address/notes, estimated price from selected service.basePrice, "Confirm Booking" → POST /api/marketplace/book/instant → confirmation screen with booking ID.
- Created src/components/marketplace/quote-request-dialog.tsx — modal with title/description/industry picker/urgency/city+postal/address/budget range/photo URL list/customer contact. Submits to POST /api/marketplace/quote-request. Confirmation shows request ID + broadcastCount.
- Created src/components/marketplace/emergency-dialog.tsx — red-themed modal with red header banner, pulsing siren animation during broadcast, polls GET /api/marketplace/emergency/[id] every 5s for up to 5 min, transitions to "Technician on the way" with ETA when status='accepted'|'en_route'.
- Created src/components/marketplace/provider-profile.tsx — full profile page (hero gradient/cover, name + verified badge, rating stars + review count, location, industry badge, trust badges row, about, services grid with per-service Book button, gallery, reviews section with rating breakdown bars + scrollable list, FAQs accordion, sidebar with contact/business hours/languages/service areas/certifications). Book Now + Request Quote buttons open the appropriate dialogs.
- Created src/components/marketplace/marketplace-landing.tsx — the public landing. Hero with gradient backdrop + "ServiceOS — The AI Operating System for Local Service Businesses" headline + "Run your business. Get more customers. Automate everything." subheadline. AI describe-problem search bar with suggestion chips; on submit calls /api/marketplace/ai-route and shows extraction chips (category, service, urgency, duration, location), cost estimate, recommended booking mode, nearby providers list, action button that opens the right dialog based on bookingMode, and "Not what you meant? Browse categories" fallback. Browse-by-Vertical grid (9 cards) that expand to show industries within. Featured providers horizontal scroll (fetches /api/marketplace/providers, sorts featured-first). "How It Works" 3-column section explaining Instant Booking / Request Quotes / Emergency Dispatch. CTA banner. Footer. Internal view state switches between home / browse-results / profile (no new route needed). Header has Sign in + Get Started buttons wired to onGetStarted/onSignIn/onTryDemo.
- Updated src/app/page.tsx — replaced the dynamic import target from `@/components/landing/landing-page` (LandingPage) to `@/components/marketplace/marketplace-landing` (MarketplaceLanding). Kept the local variable name `LandingPage` and the same props (onGetStarted, onSignIn, onTryDemo) so the existing JSX still works. Authenticated users still get the dashboard (AppLayout / CustomerPortalLayout / EmployeePortalLayout) — the marketplace only renders for unauthenticated visitors.
- Ran `bun run lint 2>&1 | tail -15`: 0 errors and 0 warnings in all new marketplace files. Remaining 14 errors + 1 warning are pre-existing in unrelated files (custom-server.js, pm.js, server-daemon.js, server.js, accept-invitation.tsx, customer-360-view.tsx, start-dev.js).

Stage Summary:
- The home page `/` now serves two audiences: authenticated users see their dashboard; unauthenticated visitors see the public marketplace landing with the AI describe-problem search, vertical browsing, featured providers, and the three booking flows (instant / quote request / emergency dispatch) — all wired to the Phase 10 marketplace APIs.
- 7 new files in src/components/marketplace/ (types.ts + 6 component files), ~150KB total. No new routes added (provider profile is rendered inside the landing shell via internal view state).
- Color palette stays within the existing theme: emerald/teal/cyan for the brand gradient, amber for the quote-request flow, rose/red for the emergency flow, violet for AI-auto. No indigo or blue used.
- All API calls go through the `mpUrl()` helper which auto-injects `XTransformPort=3000` for the Caddy gateway.

---
Task ID: P13-settlement
Agent: general-purpose
Task: Build settlement cron worker + Stripe webhook reconciliation for marketplace transactions

Work Log:
- Read prior worklog P10 (marketplace API routes) + P11 (marketplace UI) — confirmed MarketplaceTransaction model fields and the cron/webhook contract.
- Read prisma/schema.prisma MarketplaceTransaction (line ~4080) — found transferId, refundedAt, refundAmount, escrowReleasedAt, disputeReason already present; missing releasedAt, disputedAt, escrowedAt, retryCount.
- Read existing src/lib/stripe.ts — found a low-level transferToProvider(accountId, amount, currency, transferGroup) that was only referenced in comments (not called anywhere).
- Read src/app/api/billing/stripe/webhook/route.ts — confirmed it delegates to handleWebhookEvent() in stripe.ts which only handled 4 events (account.updated, payment_intent.succeeded, transfer.created, payout.paid).
- Read src/app/api/cron/trial-expire/route.ts + renewal/route.ts — learned the auth pattern: x-cron-secret header OR ?secret= query param, default to 'serviceos-cron-dev' if CRON_SECRET unset.
- Read src/lib/job-state-machine.ts — confirmed 'completed', 'invoiced', 'closed' are the releasable terminal-ish states (along with 'paid', 'warranty').
- Schema change (prisma/schema.prisma, MarketplaceTransaction model):
  * Added `escrowedAt DateTime?`  — set by payment_intent.succeeded webhook
  * Added `releasedAt DateTime?`  — set by settlement cron on successful transfer
  * Added `disputedAt DateTime?`  — set by charge.dispute.created webhook OR by cron after 5 failed retries
  * Added `retryCount Int @default(0)` — incremented by cron on each failed transfer attempt
  * (refundAmount, refundedAt, transferId already existed — left untouched)
  * Ran `bunx prisma db push` → "Your database is now in sync with your Prisma schema" (SQLite, no migration needed).
- src/lib/stripe.ts changes:
  * Renamed old low-level `transferToProvider(accountId, amount, currency, transferGroup)` → `createStripeTransfer(...)` (kept the same body — still a useful primitive when caller already has the Connect accountId).
  * Added new typed error class `StripePayoutError extends Error`.
  * Added new `TransferToProviderResult` interface: `{ transferId, status, mock }`.
  * Added new high-level `transferToProvider(tenantId, amountInCents, marketplaceTransactionId)`:
    - Lazy-imports db, fetches tenant's stripeAccountId + stripePayoutsEnabled + currency
    - Demo/dev fallback: if STRIPE_SECRET_KEY is unset OR stripeAccountId starts with `acct_demo_` (seeded providers) → returns `{ transferId: 'tr_demo_<random>', status: 'succeeded', mock: true }` + logs a warning. NEVER calls Stripe with a fake accountId.
    - Throws `StripePayoutError` if tenant missing, no stripeAccountId, or stripePayoutsEnabled=false
    - Real mode: calls createStripeTransfer(stripeAccountId, amountInCents, currency, marketplaceTransactionId) and returns `{ transferId: transfer.id, status: transfer.status, mock: false }`
  * Enhanced handlePaymentIntentSucceeded: now sets status='escrow' + escrowedAt + stores full event metadata in metadataJson. Idempotent — only transitions from 'pending' (or null) state, not from escrow/released/refunded/disputed.
  * Added handleChargeRefunded(charge): reconciles via charge.payment_intent → MarketplaceTransaction. Sets status='refunded', refundedAt, refundAmount (converted from cents to major units), stores refundEvent metadata. Special warning log if prior status was 'released' (manual clawback required — out of scope for cron).
  * Added handleChargeDisputeCreated(dispute): reconciles via dispute.payment_intent. Sets status='disputed', disputedAt, disputeReason, stores disputeEvent metadata.
  * Added internal `safeParseJsonRecord()` helper so corrupt metadataJson never crashes a webhook event (Stripe would keep retrying on 500).
  * Added charge.refunded + charge.dispute.created cases to the handleWebhookEvent switch.
  * Updated the file's header comment listing all 6 handled event types.
- src/app/api/billing/stripe/webhook/route.ts: only the JSDoc comment was updated to list the 2 new event types. No handler logic touched — all dispatch happens in stripe.ts handleWebhookEvent.
- Created src/app/api/cron/marketplace-settlement/route.ts (~420 lines):
  * GET handler (with POST alias for schedulers that default to POST).
  * Auth: checks `Authorization: Bearer ${CRON_SECRET}` header OR `?key=` query param. If CRON_SECRET unset → dev mode allows (with warning log), production returns 401.
  * Step 2: fetches all escrows with explicit `select` (id, tenantId, jobId, providerAmount, currency, retryCount, metadataJson, createdAt), then bulk-fetches linked Jobs (status only) + Tenants (name only) in two `findMany({ where: { id: { in: [...] } } })` queries — Job has no Prisma relation back to MarketplaceTransaction so we can't `include: { job: true }`.
  * Filters releasable: jobId set AND jobStatus ∈ ['completed', 'invoiced', 'closed'].
  * Step 3: for each releasable txn — converts providerAmount (major) → cents via `Math.round(providerAmount * 100)`, calls `transferToProvider(tenantId, amountInCents, txn.id)`. On success: status='released', releasedAt=now, escrowReleasedAt=now (legacy field kept in sync), transferId set, retryCount reset to 0, settlement details merged into metadataJson. On failure: increments retryCount, stores lastError in metadataJson, leaves status='escrow' for next run. After 5 failed retries (retryCount > 5) → escalates to 'disputed' with disputedAt + the error in metadataJson. Each txn wrapped in its own try/catch so a single failure never crashes the cron.
  * Step 4: orphan sweep — finds escrows with jobId=null AND createdAt < 7 days ago, marks them released with an `orphanedRelease` note in metadataJson (edge case for instant bookings that never created a Job).
  * Step 5: returns JSON `{ processed, released, failed, disputed, orphaned, ranAt }`.
  * Logs via `withRequestId(request)` + `logger.info/warn/error`. Every run starts with an info log (escrowCount + releasableCount), ends with a summary log.
  * Top-of-file JSDoc documents the Vercel Cron schedule (`*/15 * * * *` — written in prose to avoid the JSDoc `*/` terminator bug).
- Created /home/z/my-project/vercel.json (new file):
  ```json
  {
    "$schema": "https://openapi.vercel.sh/vercel.json",
    "crons": [
      { "path": "/api/cron/marketplace-settlement", "schedule": "*/15 * * * *" }
    ]
  }
  ```
- Verification:
  * `bunx tsc --noEmit --skipLibCheck` → 0 errors in any modified file (project-wide pre-existing errors are all in src/scripts/seed-*.ts).
  * `bun run lint` → 0 new errors. All 15 errors + 2 warnings are pre-existing (custom-server.js, pm.js, server-daemon.js, server.js, accept-invitation.tsx, customer-360-view.tsx, start-dev.js — same as P11 worklog noted).
  * Started dev server with `bun run dev` → Ready in 1258ms.
  * Curl test 1 — no auth: `curl http://127.0.0.1:3000/api/cron/marketplace-settlement?XTransformPort=3000` → 200 `{"processed":0,"released":0,"failed":0,"disputed":0,"orphaned":0,"ranAt":"..."}` (dev mode allows no-auth since CRON_SECRET unset).
  * Curl test 2 — Bearer header: `curl -H "Authorization: Bearer dev" ...` → 200 same shape.
  * Curl test 3 — query key: `curl ...?key=dev` → 200 same shape.
  * Curl test 4 — webhook empty body: `curl -X POST .../api/billing/stripe/webhook -d '{}'` → 503 `{"error":"Stripe is not configured"}` (expected — STRIPE_SECRET_KEY not set in dev; NOT a 500 crash).

Stage Summary:
- Files created: 2 (src/app/api/cron/marketplace-settlement/route.ts, vercel.json).
- Files modified: 3 (prisma/schema.prisma, src/lib/stripe.ts, src/app/api/billing/stripe/webhook/route.ts comment-only).
- Schema fields added to MarketplaceTransaction: `escrowedAt DateTime?`, `releasedAt DateTime?`, `disputedAt DateTime?`, `retryCount Int @default(0)`. (refundAmount, refundedAt, transferId already existed.) Prisma Client regenerated; SQLite db pushed.
- Stripe lib: new high-level `transferToProvider(tenantId, amountInCents, marketplaceTransactionId)` with typed `StripePayoutError`, demo-mode fallback for `acct_demo_*` accounts / unset STRIPE_SECRET_KEY, and tenant payouts-enabled guard. Old low-level primitive preserved as `createStripeTransfer(accountId, ...)`.
- Webhook handler: now handles 6 event types (added charge.refunded → 'refunded' + refundAmount, charge.dispute.created → 'disputed' + disputeReason). payment_intent.succeeded now sets escrowedAt + stores full event metadata. All handlers idempotent (safe under Stripe redelivery).
- Settlement cron: idempotent (released rows no longer match the escrow filter), per-transaction try/catch (single failure never crashes the run), retry-then-dispute escalation (5 strikes), orphan sweep (7-day-old jobId=null escrows auto-released), demo-mode-aware (mock transfers succeed end-to-end in dev without real Stripe keys).
- Vercel Cron schedule documented at top of cron route + registered in vercel.json: `*/15 * * * *` (every 15 minutes).
- Next actions for downstream agents:
  - The settlement cron uses demo-mode mock transfers when `acct_demo_*` Connect accounts are detected. For real production payouts, the provider onboarding flow (Tenant.stripeAccountId = real `acct_...` from Stripe) + the `account.updated` webhook (flips stripePayoutsEnabled=true once KYC completes) MUST be wired up — otherwise the cron will keep returning mock transfers even in prod.
  - The `charge.refunded` handler logs a warning when refund arrives after release (status='released' → 'refunded') but does NOT auto-reverse the Stripe Transfer. A separate `reverseTransfer(transferId, amount)` helper + admin UI button is needed to actually claw back the funds from the provider's Connect balance (`stripe.transfers.createReversal`).
  - The `charge.dispute.*` lifecycle (won/lost/closed) is not yet wired — only `charge.dispute.created` flips the transaction to 'disputed'. Add handlers for `charge.dispute.closed` (with `dispute.status === 'won' | 'lost'`) to flip back to 'released' or to 'refunded' respectively.
  - Consider surfacing the `retryCount` + `lastError` from metadataJson in a provider-facing "Payouts" dashboard so providers can see why their payout is stuck in escrow.
  - The cron returns 200 even when CRON_SECRET is unset in dev. For staging/production-like dev environments, set CRON_SECRET in .env so the auth path is exercised.

---
Task ID: P13-provider-ui
Agent: general-purpose
Task: Build provider-side marketplace UI (eligibility checklist, portfolio, certifications, quote inbox, emergency feed, opt-in flow)

Work Log:
- Read all 9 marketplace/provider API route files (eligibility, portfolio, certifications, quote-request list/detail/quotes, emergency list/[id]/accept/status) + marketplace-eligibility.ts to learn exact request/response shapes. Discovered 3 API gaps vs. the task brief:
  * `GET /api/marketplace/emergency` did not exist (only POST) — added a provider-authenticated GET handler that returns broadcasting emergencies where the calling tenant is in `broadcastToIds` PLUS any active emergencies the tenant has already accepted (status in accepted|en_route|on_site). Filter by ?status=open|active|all.
  * `/api/provider/certifications` had only GET + POST (no PATCH/DELETE) — created new `/api/provider/certifications/[id]/route.ts` with PATCH (update name/issuer/dates/certNumber/documentUrl; isVerified intentionally NOT mutable) and DELETE handlers. Both are tenant-scoped (404 if the cert exists but belongs to a different tenant).
  * No endpoint existed to compute the Overview tab's 4 stats (activeBookings, pendingQuotes, activeEmergencies, thisMonthEarnings) + isFeatured flag in one round-trip — created new `/api/marketplace/provider-stats/route.ts` that runs 5 parallel aggregations (Booking.count, Quote.count, EmergencyDispatch.count, MarketplaceTransaction.aggregate _sum providerAmount for released txns this month, FeaturedListing.aggregate _count for active listings).
- Created src/components/marketplace/provider-marketplace-dashboard.tsx (~2160 lines) — 6-tab provider dashboard with sub-components per tab:
  * OverviewTab — eligibility banner (emerald "Eligible" or amber "Incomplete"), 4 stat cards (active bookings / pending quotes / active emergencies / this-month earnings), featured-upgrade CTA card ($99/month upsell → "Coming soon" toast), full 9-gate eligibility checklist with green check/red X icons + per-gate CTA buttons (Manage subscription, Connect Stripe, Edit profile, Upgrade plan) + profile completion progress bar (emerald ≥80, amber 50-79, rose <50) + missing-requirements amber callout box.
  * OptInTab — marketplace benefits card (Instant bookings / Quote requests / Emergency dispatch), T&Cs checkbox + "Opt in to marketplace" button → PATCH /api/tenants/[id] with { marketplaceOptIn:true, marketplaceTermsAcceptedAt:true }. Resolves tenant id via /api/auth/me (with /api/tenants/me fallback). Shows "You're opted in!" success state after.
  * PortfolioTab — sub-tabs (Items/Awards/Projects/Team) using shadcn Tabs. Each sub-tab shows existing entries as bordered cards with thumbnail + title + meta + edit/delete buttons. "Add" button opens PortfolioItemDialog modal with per-type form fields (items: title/description/imageUrl/beforeUrl/afterUrl/date/category; awards: name/issuer/year/description; projects: title/description/images/value/duration/date; team: name/role/photo/bio/certifications). All CRUD via POST /api/provider/portfolio with the full updated array for that kind.
  * CertificationsTab — Table view (Name / Issuer / Issued / Expires / Cert # / Status / Actions) with Verified (emerald check) vs Pending (amber clock) badge column. "Add certification" modal + edit/delete buttons per row. CRUD via GET + POST + new PATCH/DELETE [id] routes.
  * QuoteRequestsTab — polls GET /api/marketplace/quote-request?status=open every 30s (silent re-fetch on interval, full loading state on first load + manual refresh button). Each row is a clickable card showing title, urgency badge, description (truncated), city, budget range, time received, quote count. Click opens QuoteDetailDialog modal that fetches /api/marketplace/quote-request/[id] for full customer info + renders a quote composer (line items with name/qty/price + add/remove, tax %, deposit %, validity days, timeline, terms textarea, live subtotal/tax/total). Submit → POST /api/marketplace/quote-request/[id]/quotes; on success removes the request from the list.
  * EmergenciesTab — polls GET /api/marketplace/emergency?status=all every 10s (time-sensitive). Splits feed into "Broadcasting — accept now" (rose-themed cards with ETA + estimated cost inputs + "Accept emergency" button → POST /api/marketplace/emergency/[id]/accept with { estimatedArrivalMins, estimatedCost }) and "Active — you are responding" (emerald-themed EmergencyStatusTracker cards with a 4-step progress indicator accepted→en_route→on_site→completed + "Mark as X" button that PATCHes /api/marketplace/emergency/[id]/status). Mounted-ref guard prevents state updates after unmount.
- Wiring (Task 2):
  * Added `'marketplaceDashboard'` to ViewType union in src/types/workflow.ts.
  * Added `ProviderMarketplaceDashboard` lazy import + `viewComponents.marketplaceDashboard` entry in src/components/layout/app-layout.tsx.
  * Added new "Marketplace" section between CRM and Operations in `ownerNavSections` (src/components/layout/sidebar.tsx) with a single `{ view: 'marketplaceDashboard', label: 'Marketplace', icon: Store }` item. Imported `Store` from lucide-react.
- Settings bridge (Task 3):
  * Rewrote src/components/settings/sections/marketplace-settings.tsx (45 → 80 lines): kept PublicHubTab as the second sub-section, added a prominent emerald/teal gradient banner at the top with a Store icon + "Manage your marketplace dashboard" headline + "Open dashboard" button that calls `useAppStore.setCurrentView('marketplaceDashboard')`. Loading + no-tenant states preserved.
- Featured upgrade CTA (Task 4):
  * FeaturedUpgradeCTA component rendered in OverviewTab — if `stats.isFeatured` is true, shows an amber "Featured Listing active" card with a Crown badge. If false, shows "Get featured for $99/month — appear at the top of marketplace search results" CTA card with an "Upgrade" button that fires `toast.info('Coming soon — contact sales@serviceos.com to get featured.')`.
- Color palette: emerald/teal for Overview/Portfolio/Certifications/Opt-in primary actions, amber for Quote Requests tab + quote composer, rose/red for Emergencies tab. No indigo or blue.
- Polling: Quote Requests every 30s, Emergencies every 10s — implemented via `useEffect(() => { load(); const id = setInterval(() => load(true), N); return () => { mountedRef.current = false; clearInterval(id); }; }, [load])`. Silent re-fetches pass `silent=true` so the loading spinner doesn't flash on every poll.
- Auth pattern: all calls go through a local `apiJson()` helper that wraps `authFetch` (Bearer token from localStorage + cookie via `credentials: 'include'`) and auto-adds the Caddy `XTransformPort=3000` param via `mpUrl()`. Errors are unwrapped to the server's `error` string and thrown, caught by per-tab try/catch blocks that surface a toast + ErrorState with retry.
- Responsive: stat-card grid collapses 4→2→1 columns, dialogs scroll vertically on mobile, sidebar tabs wrap horizontally on narrow viewports.
- Loading/error/empty states: every tab renders a Skeleton LoadingState while fetching, an ErrorState with retry button on failure, and an EmptyState with icon + description + (where applicable) an "Add" CTA when the list is empty.
- Verification:
  * `npx eslint <all 8 new/modified files> --no-cache` → 0 errors, 0 warnings.
  * `bun run lint` → 15 problems total, ALL pre-existing in unrelated files (custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js — require-imports; accept-invitation.tsx — setState-in-effect; customer-360-view.tsx — alt-text). 0 new issues introduced.
  * Live API smoke tests as Metro HVAC demo provider (email owner+metro-hvac-solutions@demo.serviceos.cc):
    - GET /api/marketplace/eligibility → { eligible:true, profileCompletionPct:100, plan:'business', marketplaceAccess:'priority', checks:{all 9 true} }
    - GET /api/marketplace/provider-stats → { stats:{ activeBookings:0, pendingQuotes:0, activeEmergencies:0, thisMonthEarnings:0, currency:'USD', isFeatured:true } }
    - GET /api/provider/portfolio → returns seeded portfolio with items (Central Park West AC Replacement, Brooklyn Restaurant Walk-in Cooler) + awards + projects + team
    - GET /api/provider/certifications → 2+ seeded certifications including EPA Section 608 (isVerified:true)
    - POST /api/provider/portfolio with { awards:[{name:'Test Award - P13',…}] } → 200 OK, preserved existing items + appended the new award (cleanup POST with awards:[] confirmed removal)
    - POST/PATCH/DELETE /api/provider/certifications/[id] → 200/200/200 — created a test cert, patched its name+issuer, deleted it. { ok:true, id } on DELETE.
    - GET /api/marketplace/emergency?status=all → { items:[], total:0, providerTenantId:'cms1kku2d…', providerIndustry:'hvac', providerEmergencyCapable:true }
    - GET /api/marketplace/quote-request?status=open&limit=3 → { items:[], total:0 } (no seeded open requests)
    - GET /api/auth/me → 200 with user.tenantId (used by OptInTab to resolve the tenant id for the PATCH /api/tenants/[id] opt-in call)

Stage Summary:
- Files created (3):
  * src/components/marketplace/provider-marketplace-dashboard.tsx (~2160 lines) — the 6-tab provider dashboard.
  * src/app/api/provider/certifications/[id]/route.ts (~230 lines) — PATCH + DELETE handlers for certification edit/delete.
  * src/app/api/marketplace/provider-stats/route.ts (~120 lines) — single-shot dashboard rollup (4 stats + isFeatured).
- Files modified (5):
  * src/app/api/marketplace/emergency/route.ts — added GET handler (~155 lines added) listing broadcasting + active emergencies for the calling provider tenant.
  * src/types/workflow.ts — added `'marketplaceDashboard'` to ViewType union.
  * src/components/layout/app-layout.tsx — added lazy import + viewComponents entry.
  * src/components/layout/sidebar.tsx — added `Store` to lucide imports + new "Marketplace" section between CRM and Operations with the marketplaceDashboard nav item.
  * src/components/settings/sections/marketplace-settings.tsx — rewrote (45 → 80 lines) to add the dashboard banner above the existing PublicHubTab.
- Lint: 0 new errors/warnings in any of the 8 new/modified files. Pre-existing 15 issues unchanged.
- API gaps discovered vs. the task brief and patched:
  * GET /api/marketplace/emergency did not exist → added provider-authenticated list handler.
  * PATCH/DELETE /api/provider/certifications/[id] did not exist → added [id] route with both verbs.
  * No endpoint existed for the 4 Overview stats → added /api/marketplace/provider-stats.
  * Portfolio API uses POST (not PATCH as the brief said) for upsert — the UI correctly calls POST with the full updated array for the modified kind.
  * Certifications GET returns `{ certifications: [...] }` (not `{ items: [...] }` as the brief said) — the UI uses the correct key.
  * Emergency accept body needs `{ providerTenantId, estimatedArrivalMins, estimatedCost }` (not `{ etaMinutes, estimatedCost }` as the brief said) — the UI sends `estimatedArrivalMins` and lets the server resolve `providerTenantId` from auth.
- Next actions for downstream agents:
  * The MarketplaceTransaction table has no provider-facing list/withdrawal endpoint yet — the Overview tab's "This-month earnings" stat works (aggregated server-side) but providers can't see a transaction history. A future `/api/marketplace/transactions` GET endpoint + a "Payouts" tab would close the loop.
  * The featured-listing "Upgrade" button is a stub (toast only) — wiring it to a Stripe checkout for the $99/month FeaturedListing subscription is a separate task.
  * The Opt-in tab's "Terms & Conditions" link is also a stub (toast only) — needs a real /legal/marketplace-terms page or in-app T&C document.
  * Consider tightening the public GET /api/marketplace/quote-request list — currently any unauthenticated caller can list all open marketplace requests (no auth, no broadcastToIds filter). For the provider inbox this is fine, but the public list endpoint leaks every customer's project scope + budget + city. Either add a `?provider=1` flag that switches to auth-required + broadcastToIds filtering, or accept the leak as by-design (open marketplace).

---
Task ID: P13-dual-landing
Agent: general-purpose
Task: Build dual-audience landing (Option A) + marketplace route architecture + sitemap update

Work Log:
- Read worklog tail (P11-marketplace-ui, P13-settlement, P13-provider-ui) to understand prior work — confirmed MarketplaceLanding exists at src/components/marketplace/marketplace-landing.tsx, 12 demo providers seeded, MarketplaceTransaction schema had escrowedAt/releasedAt/disputedAt/retryCount added by P13-settlement.
- Audited current state of the 6 task artifacts and found that all 6 had already been scaffolded (file timestamps 09:16–09:29, just before this task started). Verified each one is structurally complete and correct rather than rewriting from scratch:
  * src/components/landing/dual-audience-landing.tsx (1,722 lines) — 'use client' component with: HeroFork (audience toggle with emerald/teal CRM button + amber/rose marketplace button + Try Live Demo link + Browse marketplace link + 4 trust stats), CrmHowItWorks (3-step + 8-icon core flow strip), CrmFeatures (4 feature pillars + 4 AI highlights), CrmAiReceptionist (slate-950 dark showcase with live call mockup + 6 capabilities + BYOK pricing note), CrmPersonas (4 roles), CrmTestimonials (3 quotes), CrmPricing (Starter $5/Growth $29/Business $79/Enterprise Custom — matches src/lib/billing-seed.ts PLAN_DEFS — with monthly/yearly toggle), CrmFaq (7 Q&A accordion), CrmFinalCta, MarketplaceCompact (AI describe-problem search → /api/marketplace/ai-route + featured providers horizontal scroll via /api/marketplace/providers + 3 booking-mode flow cards + amber CTA banner), Footer (4 columns: Product/Company/Resources/Legal), StickyCta (audience-aware bottom bar with dual CTA). Color palette: emerald/teal/cyan for CRM, amber/rose for marketplace — no indigo or blue.
  * src/app/page.tsx — already imports DualAudienceLanding via `dynamic(() => import('@/components/landing/dual-audience-landing').then(m => ({ default: m.DualAudienceLanding })), { ssr: false, loading: () => <ViewLoader /> })` and passes onGetStarted/onSignIn/onTryDemo props. All auth/magic-link/OAuth/role-routing logic untouched.
  * src/app/marketplace/page.tsx (544 lines) — server component with `export const revalidate = 300` (ISR 5min). fetchProviders() queries db.tenant.findMany with the 6-gate marketplace-eligibility filter (marketplaceOptIn + identityVerified + businessVerified + insuranceVerified + stripeConnected + planStatus='active' + suspendedAt=null), includes services (active+public, top 10), bulk-fetches FeaturedListing flags in one query, parses serviceAreasJson safely, maps to ProviderListItem shape. Accepts searchParams {vertical, industry, city} and applies in-app filters (industry exact match, vertical via getIndustry().vertical lookup, city case-insensitive contains on city/state/serviceAreas). Sidebar with 9 VERTICALS + nested industries + city search form (preserve vertical/industry hidden inputs) + verified-providers trust card. Main grid renders <ProviderCard href={`/marketplace/${slug}} /> (anchor wrapper — works without JS). Hero links to /#top for AI search. SEO footer copy. Header has "← Back to ServiceOS" → "/". generateMetadata with title "ServiceOS Marketplace — Find Trusted Local Service Professionals" + OG + canonical.
  * src/app/marketplace/[slug]/page.tsx (382 lines) — server component with `export const revalidate = 300`. SEEDED_SLUGS list of all 12 demo provider slugs + generateStaticParams() pre-renders them at build time. generateMetadata() fetches tenant {name, tagline, description, seoTitle, seoDescription, city, state, industry} and synthesizes title as `${name} — ${tagline}` (or curated seoTitle if set) + description (155-char slice or curated seoDescription). Returns 404 via notFound() if tenant not found / suspended / not opted-in. fetchProviderProfile() runs parallel Promise.all for services + portfolio + certifications + reviews (top 25 published) + featured listing. Parses 7 JSON columns safely. Returns ProviderProfileResponse shape. Renders JSON-LD LocalBusiness structured data (name, description, telephone, email, address, aggregateRating, priceRange) for Google rich results. Renders <ProviderProfile slug={slug} backHref="/marketplace" initialData={data} /> — the client component skips its internal fetch when initialData is provided, so the page works without JS. Header has "← Back to marketplace" → "/marketplace".
  * src/app/sitemap.ts — already imports `db` from '@/lib/db'. staticRoutes array includes `{ path: "/marketplace", priority: 0.9, changeFreq: "weekly" }`. Dynamic section fetches all tenants where marketplaceOptIn=true AND publicProfileEnabled=true, emits `${base}/marketplace/${publicSlug || slug}` with priority 0.8, changeFrequency weekly, lastModified=updatedAt. Returns [...staticEntries, ...businessEntries, ...marketplaceProviderEntries].
  * ProviderProfile component (src/components/marketplace/provider-profile.tsx line 39–62) — already has the `initialData?: ProviderProfileResponse` prop with the correct skip-fetch useEffect logic (lines 121–127): if initialData is present, sets data + loading=false and returns; otherwise fetches via mpUrl(`/api/marketplace/providers/${slug}`). Also has `backHref?: string` prop used by SSR route for the back anchor.
  * ProviderCard component (src/components/marketplace/provider-card.tsx lines 21–36) — already has `href?: string` prop. When provided, the entire card is wrapped in `<a href={href}>` (line 117) and the inner "View Profile" button becomes a plain span — works without JS for SSR SEO.
- Verified navigation between routes (Task 6):
  * Dual-audience-landing has 4 links to /marketplace (Navbar, HeroFork "Browse the marketplace", MarketplaceCompact "Browse providers" + "Browse all", StickyCta "Browse all").
  * /marketplace header has `<a href="/">← Back to ServiceOS</a>` (verified in rendered HTML).
  * /marketplace/[slug] header has `<a href="/marketplace">← Back to marketplace</a>` (verified in rendered HTML).
- Dev-server incident: the pre-existing dev server (started 09:34) had a stale Prisma client connection — /api/health reported `db: "disconnected"` and all marketplace API routes returned 500 "Failed to list providers". Killed PID 535/548 and started a fresh `bun run dev` (PID 2027). Fresh server reports `db: "connected"` and all routes work.
- Lint check (`bun run lint 2>&1 | tail -25`): 15 problems total (14 errors + 1 warning), ALL pre-existing in unrelated files — custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js (require-imports), accept-invitation.tsx (setState-in-effect), customer-360-view.tsx (alt-text). 0 new issues in any of the 5 task files (dual-audience-landing.tsx, page.tsx, marketplace/page.tsx, marketplace/[slug]/page.tsx, sitemap.ts).
- Curl verification (all 4 tests pass):
  1. `curl -s http://127.0.0.1:3000/ | head -c 500` → returns HTML with `<title>ServiceOS - The Operating System for Service Businesses</title>` and ServiceOS branding in body.
  2. `curl -s http://127.0.0.1:3000/marketplace | grep -o '<title>[^<]*</title>'` → `<title>ServiceOS Marketplace — Find Trusted Local Service Professionals</title>`.
  3. `curl -s http://127.0.0.1:3000/marketplace/metro-hvac-solutions | grep -o '<title>[^<]*</title>'` → `<title>Metro HVAC Solutions | 24/7 emergency heating &amp; cooling experts</title>`.
  4. `curl -s http://127.0.0.1:3000/sitemap.xml | head -c 1000` → includes `<loc>https://serviceos.com/marketplace</loc>` and all 12 provider URLs `<loc>https://serviceos.com/marketplace/metro-hvac-solutions</loc>` etc.
- Extra verifications:
  * `/marketplace` HTML contains 5+ `<a href="/marketplace/[slug]">` provider-card links (server-rendered anchors, work without JS).
  * `/marketplace` HTML contains "← Back to ServiceOS" link (1 match).
  * `/marketplace/metro-hvac-solutions` HTML contains "← Back to marketplace" link (1 match).
  * `/marketplace/metro-hvac-solutions` HTML contains JSON-LD LocalBusiness structured data with name="Metro HVAC Solutions" + address + aggregateRating.
  * `/sitemap.xml` lists all 12 seeded marketplace provider URLs (metro-hvac-solutions, elite-plumbing-pros, bright-spark-electric, fresh-start-cleaning, green-thumb-landscaping, shield-pest-control, summit-roofing-co, premier-painting-services, rapid-lockout-rescue, appliance-md, crystal-blue-pools, mobile-mechanic-pros).
  * `/api/marketplace/providers` returns 12 items (after dev-server restart).

Stage Summary:
- Files in place (all 5 task artifacts verified, no changes needed):
  * src/components/landing/dual-audience-landing.tsx (~1,722 lines) — dual-audience landing with CRM marketing + compact marketplace + footer + sticky CTA.
  * src/app/page.tsx (~575 lines, modified earlier) — uses DualAudienceLanding dynamic import.
  * src/app/marketplace/page.tsx (~544 lines) — SSR browse page with vertical sidebar + city filter + provider grid.
  * src/app/marketplace/[slug]/page.tsx (~382 lines) — SSR provider profile page with generateStaticParams + generateMetadata + JSON-LD LocalBusiness.
  * src/app/sitemap.ts (~156 lines, modified earlier) — adds /marketplace + 12 dynamic provider URLs.
- Supporting component refactors already in place:
  * src/components/marketplace/provider-card.tsx accepts `href?: string` prop → wraps card in <a> for SSR.
  * src/components/marketplace/provider-profile.tsx accepts `initialData?: ProviderProfileResponse` + `backHref?: string` props → skips client fetch when SSR data provided.
- Lint: 0 new errors/warnings in any of the 5 task files. 15 pre-existing issues unchanged (custom-server.js, pm.js, server-daemon.js, server.js, start-dev.js, accept-invitation.tsx, customer-360-view.tsx).
- Live curl tests: all 4 verification tests pass — / returns HTML with ServiceOS, /marketplace returns the marketplace title, /marketplace/metro-hvac-solutions returns the provider name + tagline, /sitemap.xml includes /marketplace + 12 provider URLs.
- Dev-server note: the pre-existing dev server (PID 535/548) had a stale Prisma client connection — `db: "disconnected"` in /api/health and 500s on every marketplace API route. Killed and restarted fresh `bun run dev` (now PID 2027) — `db: "connected"` and all routes 200 OK.
- Preview URLs (all 200 OK):
  * http://127.0.0.1:3000/ — dual-audience landing (CRM section shown by default; toggle to marketplace section)
  * http://127.0.0.1:3000/marketplace — SSR browse page (12 providers, 9 verticals, city filter)
  * http://127.0.0.1:3000/marketplace/metro-hvac-solutions — SSR provider profile (services, reviews, portfolio, JSON-LD)
  * http://127.0.0.1:3000/sitemap.xml — dynamic sitemap with marketplace + provider URLs
- Next actions for downstream agents:
  * The dual-audience landing is `ssr: false` (client-only) — the initial HTML is just the ViewLoader. For better SEO of the homepage fork CTAs, consider adding a server-rendered hero with the two CTAs as plain HTML anchors above the dynamic import, OR convert the landing to a server component with `'use client'` islands for the toggle state.
  * The /marketplace AI-search bar in the hero is a decorative link to /#top (the actual AI describe-problem form lives in the dual-audience landing's MarketplaceCompact section, which is client-only). For full SEO of the AI-search flow on /marketplace itself, consider adding a server-rendered form that POSTs to /api/marketplace/ai-route and re-renders the result server-side.
  * Consider adding a /marketplace/[slug]/book route (SSR) for instant booking confirmation pages — currently the InstantBookingDialog is a client-only modal.
  * The dual-audience landing's `CrmPricing` shows yearly prices as `Math.round(yearlyPrice / 12)` (e.g. Growth yearly = $24/mo billed annually). The actual billing seed has yearlyPrice=290 for Growth → $24.17/mo rounded down to $24. Consider matching the exact calc or noting the rounding in the UI copy.

---
Task ID: P13-verify
Agent: main (orchestrator)
Task: Restart dev server + end-to-end verification of all 6 marketplace tasks + confirm Supabase migration is current

Work Log:
- Stopped any lingering dev server processes (none running).
- Started fresh dev server via `setsid bash -c 'exec bun run dev > dev.log 2>&1' &` + kept launching command alive with `timeout 30 tail -f dev.log` so the process reparented to init. Confirmed: PID 3514 (next dev) + PID 3526 (next-server v16.1.3), HTTP 200 on /.
- Read prior worklog entries (P13-provider-ui, P13-dual-landing) — discovered all 6 tasks were already completed in a previous session before context ran out.
- Verified each step against the running server:
  * Step 1 (Seed): GET /api/marketplace/providers returns 12 providers across 12 industries (Summit Roofing, Elite Plumbing, Bright Spark Electric, Fresh Start Cleaning, Shield Pest Control, Premier Painting, Rapid Lockout Rescue, Appliance MD, Crystal Blue Pools, Mobile Mechanic Pros, Metro HVAC, Green Thumb Landscaping). Seed script at prisma/seed-marketplace.ts (67KB).
  * Step 2 (Dual landing): src/components/landing/dual-audience-landing.tsx exists (79KB). Agent Browser confirmed / renders with dual fork (CRM + Marketplace), HeroFork, CRM sections (How it works, Features, AI Receptionist, Personas, Testimonials, Pricing, FAQ), MarketplaceCompact (AI search + featured providers), Footer, StickyCta. Clicking "I need a service" fork reveals AI describe-problem search + featured providers.
  * Step 3 (Sitemap): src/app/sitemap.ts exists. GET /sitemap.xml → HTTP 200, includes /marketplace + 12 provider URLs.
  * Step 4 (Settlement): src/app/api/cron/marketplace-settlement/route.ts (14KB). GET (dev mode, no CRON_SECRET) → {"processed":0,"released":0,"failed":0,"disputed":0,"orphaned":0,"ranAt":"..."}. Stripe webhook at src/app/api/billing/stripe/webhook/route.ts (153 lines) + handleWebhookEvent in src/lib/stripe.ts reconciles MarketplaceTransaction: payment_intent.succeeded→escrow, charge.refunded→refunded, charge.dispute.created→disputed, transfer.created→records transferId, payout.paid→Payout paid. All idempotent.
  * Step 5 (Provider UI): src/components/marketplace/provider-marketplace-dashboard.tsx (2,154 lines, 6 tabs), src/components/settings/sections/marketplace-settings.tsx, src/components/settings/public-hub-tab.tsx (47KB).
  * Step 6 (Supabase migration): supabase-migration.sql (6,408 lines) is CURRENT — MarketplaceTransaction CREATE TABLE block (line 2194) includes all 4 new settlement fields (escrowedAt, releasedAt, disputedAt, retryCount) + corresponding ALTER TABLE ADD COLUMN IF NOT EXISTS backports. No regeneration needed.
- Agent Browser verification (all 200 OK, no console errors):
  * / → dual-audience landing, both forks interactive, CRM + Marketplace sections render
  * /marketplace → SSR browse page, 12 providers, 9 verticals with counts, city filter, "← Back to ServiceOS" link
  * /marketplace/metro-hvac-solutions → SSR provider profile, SEO title "Metro HVAC Solutions | 24/7 emergency heating & cooling experts", Book Now + Request Quote buttons, JSON-LD LocalBusiness
  * /sitemap.xml → includes /marketplace + 12 provider URLs
- Minor UX note: cookie consent banner (220px) + PWA install banner cover the hero fork buttons on viewports <700px tall. Banners are dismissible ("Accept all" / "Dismiss"). Fork is also reachable via navbar "Marketplace" link + "Browse the marketplace" link. Not a blocker.

Stage Summary:
- Dev server restarted: PID 3514/3526 on port 3000, HTTP 200, DB connected.
- All 6 marketplace tasks VERIFIED COMPLETE via curl + Agent Browser:
  1. Seed: 12 providers, 12 industries, all eligibility gates true ✅
  2. Dual landing: Option A with CRM + Marketplace fork ✅
  3. Sitemap: /sitemap.xml with marketplace + provider URLs ✅
  4. Settlement: cron worker + Stripe webhook reconciliation ✅
  5. Provider UI: 6-tab dashboard + settings ✅
  6. Supabase migration: current (6,408 lines, all settlement fields present) ✅
- No code changes made this round — everything was already in place from prior sessions. This was a verification + server-restart task only.
- Next actions for the user: review the changed files list + Supabase migration (already current). No further code changes needed unless the user requests new features.
