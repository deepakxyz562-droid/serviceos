import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { getAuthUser } from '@/lib/auth'
import { logActivity } from '@/lib/activity-log'

// GET /api/customers — list customers for the authenticated user's tenant
// Scopes results to the logged-in user's workspace/tenant so cross-tenant
// data never leaks. Supports optional ?search= query.
export async function GET(request: NextRequest) {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const search = searchParams.get('search')

    // Scope to the user's workspace. If the user has no direct workspaceId
    // (e.g. super-admin / admin@serviceos.cc), resolve via their tenantId →
    // first workspace in that tenant. If they also have no tenantId, fall
    // back to the first workspace in the system so the UI still works for
    // the demo admin (instead of silently returning an empty list).
    const where: Record<string, unknown> = {}
    if (user.workspaceId) {
      where.workspaceId = user.workspaceId
    } else {
      const fallbackWorkspace = await db.workspace.findFirst({
        where: user.tenantId ? { tenantId: user.tenantId } : undefined,
        orderBy: { createdAt: 'asc' },
        select: { id: true },
      })
      if (fallbackWorkspace) {
        where.workspaceId = fallbackWorkspace.id
      } else {
        return NextResponse.json([])
      }
    }

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { phone: { contains: search } },
        { email: { contains: search } },
        { address: { contains: search } },
      ]
    }

    const customers = await db.customer.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(customers)
  } catch (error) {
    console.error('Error fetching customers:', error)
    return NextResponse.json({ error: 'Failed to fetch customers' }, { status: 500 })
  }
}

// POST /api/customers — create a new customer
// Automatically attaches the customer to the logged-in user's workspace so
// the workspaceId is NEVER null (which was breaking invitation links because
// the slug lookup chain Customer→Workspace→Tenant was broken).
export async function POST(request: NextRequest) {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { name, phone, email, address, whatsappId, preferredCurrency } = body

    if (!name || !phone) {
      return NextResponse.json({ error: 'Name and phone are required' }, { status: 400 })
    }

    // Always use the logged-in user's workspaceId — ignore any workspaceId in
    // the request body. This ensures every customer is properly scoped and
    // the Customer→Workspace→Tenant→slug chain stays intact for invitation
    // link generation.
    const workspaceId = user.workspaceId || null

    const customer = await db.customer.create({
      data: {
        name,
        phone,
        email: email || null,
        address: address || null,
        whatsappId: whatsappId || null,
        workspaceId,
        preferredCurrency: preferredCurrency || 'USD',
      },
    })

    // ─── V1.5 Activity Log ──────────────────────────────────────────
    // Best-effort — never fails the customer creation. Customer uses
    // workspaceId → workspace.tenantId for tenant scoping.
    try {
      let customerTenantId: string | null = user.tenantId || null
      if (!customerTenantId && customer.workspaceId) {
        const ws = await db.workspace.findUnique({
          where: { id: customer.workspaceId },
          select: { tenantId: true },
        })
        customerTenantId = ws?.tenantId ?? null
      }
      if (customerTenantId) {
        await logActivity({
          tenantId: customerTenantId,
          actorId: user.id,
          actorName: user.name || user.email,
          actorType: 'user',
          action: 'create',
          entityType: 'customer',
          entityId: customer.id,
          entityName: customer.name || null,
          description: `Created customer: ${customer.name}`,
          metadataJson: JSON.stringify({
            phone: customer.phone,
            email: customer.email,
            workspaceId: customer.workspaceId,
          }),
          severity: 'info',
        })
      }
    } catch (logErr) {
      console.error('[Customers POST] Failed to log activity:', logErr)
    }

    return NextResponse.json(customer, { status: 201 })
  } catch (error) {
    console.error('Error creating customer:', error)
    return NextResponse.json({ error: 'Failed to create customer' }, { status: 500 })
  }
}

// PUT /api/customers?id=... — update an existing customer
// Verifies the customer belongs to the authenticated user's workspace before
// updating.
export async function PUT(request: NextRequest) {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) {
      return NextResponse.json({ error: 'Customer ID is required' }, { status: 400 })
    }

    // Ownership check: the customer must belong to the user's workspace
    if (user.workspaceId) {
      const existing = await db.customer.findFirst({
        where: { id, workspaceId: user.workspaceId },
        select: { id: true },
      })
      if (!existing) {
        return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
      }
    }

    const body = await request.json()
    const { name, phone, email, address, whatsappId, preferredCurrency } = body

    const customer = await db.customer.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(phone && { phone }),
        ...(email !== undefined && { email }),
        ...(address !== undefined && { address }),
        ...(whatsappId !== undefined && { whatsappId }),
        ...(preferredCurrency !== undefined && { preferredCurrency }),
      },
    })

    return NextResponse.json(customer)
  } catch (error) {
    console.error('Error updating customer:', error)
    return NextResponse.json({ error: 'Failed to update customer' }, { status: 500 })
  }
}

// DELETE /api/customers?id=... — delete a customer
// Verifies ownership before deleting.
export async function DELETE(request: NextRequest) {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) {
      return NextResponse.json({ error: 'Customer ID is required' }, { status: 400 })
    }

    // Ownership check
    if (user.workspaceId) {
      const existing = await db.customer.findFirst({
        where: { id, workspaceId: user.workspaceId },
        select: { id: true },
      })
      if (!existing) {
        return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
      }
    }

    await db.customer.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting customer:', error)
    return NextResponse.json({ error: 'Failed to delete customer' }, { status: 500 })
  }
}
