import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { logger, withRequestId } from '@/lib/logger';
import { applyRateLimit, apiLimiter, rateLimitResponse } from '@/lib/rate-limit';
import {
  createPaymentIntent,
  isStripeConfigured,
  StripeConfigError,
} from '@/lib/stripe';
import { notifyOwner } from '@/lib/owner-notifications';

/**
 * Flow 1: Instant Booking (ServiceOS V1.5 — P10-flows)
 * ------------------------------------------------------------
 * POST /api/marketplace/book/instant
 *
 * A marketplace customer picks a specific provider + service + slot and
 * confirms immediately. No quote comparison, no dispatch — straight to a
 * Booking + MarketplaceTransaction (escrow) + Job for the provider.
 *
 * Body:
 *   {
 *     providerTenantId: string,
 *     serviceId?:        string,
 *     scheduledAt?:      string (ISO),
 *     customerName:      string,
 *     customerPhone:     string,
 *     customerEmail?:    string,
 *     address?:          string,
 *     notes?:            string,
 *     paymentMethodId?:  string,   // if provided, create a Stripe PaymentIntent
 *     amount?:           number,   // gross amount (major currency units)
 *     currency?:         string,   // default USD
 *   }
 *
 * Public endpoint — rate-limited via apiLimiter. The caller is a marketplace
 * visitor, NOT an authenticated user.
 *
 * Returns: { booking, job, paymentIntent? }
 */

const DEFAULT_COMMISSION_PCT = 5;

function isValidPhone(phone: string): boolean {
  const digits = phone.replace(/[^0-9]/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export async function POST(request: NextRequest) {
  const log = withRequestId(request);

  // ── 1. Rate limit (public endpoint — no auth) ──────────────────────
  const limited = applyRateLimit(apiLimiter, request);
  if (limited) {
    log.warn({ ip: limited.ip }, 'marketplace/book/instant: rate limited');
    return rateLimitResponse(limited.resetAtMs);
  }

  // ── 2. Parse + validate body ───────────────────────────────────────
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const providerTenantId =
    typeof body.providerTenantId === 'string'
      ? body.providerTenantId.trim()
      : '';
  const serviceId =
    typeof body.serviceId === 'string' && body.serviceId.trim().length > 0
      ? body.serviceId.trim()
      : null;
  const scheduledAtRaw =
    typeof body.scheduledAt === 'string' && body.scheduledAt.trim().length > 0
      ? body.scheduledAt.trim()
      : null;
  const customerName =
    typeof body.customerName === 'string' ? body.customerName.trim() : '';
  const customerPhone =
    typeof body.customerPhone === 'string' ? body.customerPhone.trim() : '';
  const customerEmail =
    typeof body.customerEmail === 'string' && body.customerEmail.trim().length > 0
      ? body.customerEmail.trim()
      : null;
  const address =
    typeof body.address === 'string' && body.address.trim().length > 0
      ? body.address.trim()
      : null;
  const notes =
    typeof body.notes === 'string' && body.notes.trim().length > 0
      ? body.notes.trim().slice(0, 2000)
      : null;
  const paymentMethodId =
    typeof body.paymentMethodId === 'string' && body.paymentMethodId.trim().length > 0
      ? body.paymentMethodId.trim()
      : null;
  const amount =
    typeof body.amount === 'number' && Number.isFinite(body.amount) && body.amount > 0
      ? body.amount
      : null;
  const currency =
    typeof body.currency === 'string' && body.currency.length === 3
      ? body.currency.toUpperCase()
      : 'USD';

  if (!providerTenantId) {
    return NextResponse.json(
      { error: '`providerTenantId` is required.' },
      { status: 400 },
    );
  }
  if (!customerName || customerName.length < 2 || customerName.length > 200) {
    return NextResponse.json(
      { error: '`customerName` is required (2-200 chars).' },
      { status: 400 },
    );
  }
  if (!customerPhone || !isValidPhone(customerPhone)) {
    return NextResponse.json(
      { error: '`customerPhone` must be a valid phone number.' },
      { status: 400 },
    );
  }
  if (customerEmail && !isValidEmail(customerEmail)) {
    return NextResponse.json(
      { error: '`customerEmail` must be a valid email.' },
      { status: 400 },
    );
  }
  if (scheduledAtRaw && Number.isNaN(new Date(scheduledAtRaw).getTime())) {
    return NextResponse.json(
      { error: '`scheduledAt` must be a valid ISO datetime.' },
      { status: 400 },
    );
  }

  // ── 3. Verify the provider tenant exists and is marketplace-eligible ──
  // Use the cached eligibility gates on the Tenant row for the read path
  // (the full `checkMarketplaceEligibility` function does extra plan +
  // subscription lookups and is too expensive for a hot booking path).
  let provider: {
    id: string;
    name: string;
    slug: string;
    currency: string;
    email: string | null;
    phone: string | null;
    marketplaceOptIn: boolean;
    identityVerified: boolean;
    businessVerified: boolean;
    insuranceVerified: boolean;
    stripeConnected: boolean;
    planStatus: string;
  } | null;
  try {
    provider = await db.tenant.findUnique({
      where: { id: providerTenantId },
      select: {
        id: true,
        name: true,
        slug: true,
        currency: true,
        email: true,
        phone: true,
        marketplaceOptIn: true,
        identityVerified: true,
        businessVerified: true,
        insuranceVerified: true,
        stripeConnected: true,
        planStatus: true,
      },
    });
  } catch (err) {
    log.error({ err, providerTenantId }, 'marketplace/book/instant: DB error fetching provider');
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  }
  if (!provider) {
    return NextResponse.json(
      { error: 'Provider not found.' },
      { status: 404 },
    );
  }
  const eligible =
    provider.marketplaceOptIn &&
    provider.identityVerified &&
    provider.businessVerified &&
    provider.insuranceVerified &&
    provider.stripeConnected &&
    provider.planStatus === 'active';
  if (!eligible) {
    return NextResponse.json(
      { error: 'Provider is not currently eligible for marketplace bookings.' },
      { status: 409 },
    );
  }

  // ── 4. Optionally validate serviceId belongs to this provider ────────
  let serviceName: string | null = null;
  if (serviceId) {
    try {
      const svc = await db.service.findFirst({
        where: { id: serviceId, tenantId: provider.id, isActive: true },
        select: { id: true, name: true },
      });
      if (svc) serviceName = svc.name;
    } catch {
      // Service table missing — soft-fail (booking proceeds without service)
    }
  }

  // ── 5. Resolve a workspace for the provider (needed for Job creation) ─
  let workspaceId: string | null = null;
  try {
    const ws = await db.workspace.findFirst({
      where: { tenantId: provider.id },
      orderBy: { createdAt: 'asc' },
      select: { id: true },
    });
    workspaceId = ws?.id ?? null;
  } catch (err) {
    log.warn({ err, providerTenantId: provider.id }, 'marketplace/book/instant: workspace lookup failed');
  }

  // ── 6. Compute commission + provider amount (if amount provided) ─────
  const grossAmount = amount ?? 0;
  const commissionAmount =
    Math.round(grossAmount * DEFAULT_COMMISSION_PCT) / 100;
  const providerAmount =
    Math.round((grossAmount - commissionAmount) * 100) / 100;

  const scheduledAt = scheduledAtRaw ? new Date(scheduledAtRaw) : null;
  const title = serviceName
    ? `Instant Booking — ${serviceName}`
    : 'Instant Marketplace Booking';
  const description = notes || `Instant booking from marketplace for ${provider.name}`;

  // ── 7. Create Booking + MarketplaceTransaction + Job atomically ─────
  let booking: Record<string, unknown>;
  let job: Record<string, unknown> | null = null;
  let transactionId: string | null = null;

  try {
    const result = await db.$transaction(async (tx) => {
      // 7a. Booking
      const b = await tx.booking.create({
        data: {
          title,
          description,
          bookingType: 'instant',
          status: 'confirmed', // instant bookings are auto-confirmed
          source: 'website',
          customerName,
          customerPhone,
          customerEmail,
          serviceId: serviceId,
          address,
          scheduledAt,
          duration: 60,
          notes,
          confirmedAt: new Date(),
          tenantId: provider.id,
          workspaceId,
          metadataJson: JSON.stringify({
            marketplaceFlow: 'instant',
            providerTenantId: provider.id,
            customerEmail,
            createdAt: new Date().toISOString(),
          }),
        },
      });

      // 7b. MarketplaceTransaction (escrow)
      const txn = await tx.marketplaceTransaction.create({
        data: {
          tenantId: provider.id,
          customerName,
          customerPhone,
          customerEmail,
          bookingId: b.id,
          bookingType: 'instant',
          serviceDescription: serviceName || title,
          totalAmount: grossAmount,
          commissionPct: DEFAULT_COMMISSION_PCT,
          commissionAmount,
          providerAmount,
          currency,
          status: grossAmount > 0 ? 'escrow' : 'pending',
          metadataJson: JSON.stringify({
            flow: 'instant',
            createdAt: new Date().toISOString(),
          }),
        },
      });

      // 7c. Job — link back to the booking via externalId
      const j = await tx.job.create({
        data: {
          title,
          description,
          status: 'assigned',
          priority: 'high',
          type: 'service',
          address,
          scheduledAt,
          estimatedDuration: 60,
          notes,
          customerName,
          customerPhone,
          customerEmail,
          externalId: b.id,
          externalSource: 'marketplace_booking',
          serviceId: serviceId,
          assignmentStatus: 'accepted',
          metadataJson: JSON.stringify({
            marketplaceFlow: 'instant',
            bookingId: b.id,
            transactionId: txn.id,
            providerTenantId: provider.id,
          }),
          workspaceId,
        },
      });

      // Link transaction → job
      await tx.marketplaceTransaction.update({
        where: { id: txn.id },
        data: { jobId: j.id },
      });

      return { booking: b, job: j, transactionId: txn.id };
    });

    booking = result.booking;
    job = result.job;
    transactionId = result.transactionId;
  } catch (err) {
    log.error({ err, providerTenantId: provider.id }, 'marketplace/book/instant: transaction failed');
    return NextResponse.json(
      { error: 'Failed to create booking' },
      { status: 500 },
    );
  }

  // ── 8. Stripe PaymentIntent (if payment method provided) ────────────
  let paymentIntent:
    | { clientSecret: string; paymentIntentId: string }
    | null = null;

  if (paymentMethodId && grossAmount > 0 && isStripeConfigured()) {
    try {
      const stripeAmount = Math.round(grossAmount * 100); // cents
      const pi = await createPaymentIntent(stripeAmount, currency, {
        transactionId: transactionId ?? '',
        providerTenantId: provider.id,
        bookingType: 'instant',
        serviceDescription: serviceName || title,
      });

      // Persist the paymentIntentId on the transaction
      if (transactionId) {
        await db.marketplaceTransaction.update({
          where: { id: transactionId },
          data: { paymentIntentId: pi.paymentIntentId },
        });
      }

      paymentIntent = pi;
      log.info(
        { paymentIntentId: pi.paymentIntentId, transactionId, amount: grossAmount },
        'marketplace/book/instant: PaymentIntent created',
      );
    } catch (err) {
      if (err instanceof StripeConfigError) {
        log.warn({ err: err.message }, 'marketplace/book/instant: Stripe not configured');
      } else {
        log.error(
          { err: err instanceof Error ? err.message : String(err), transactionId },
          'marketplace/book/instant: PaymentIntent failed',
        );
      }
      // Booking still succeeds — payment can be retried separately
    }
  }

  // ── 9. Notify the provider (best-effort, fire-and-forget) ───────────
  notifyOwner(provider.id, {
    eventType: 'marketplace.booking.instant',
    eventLabel: 'Instant Marketplace Booking',
    bookingId: (booking as { id: string }).id,
    actionUrl: '/bookings',
    smsMessage: `New instant booking: ${title}, customer: ${customerName}, scheduled: ${scheduledAt ? scheduledAt.toISOString() : 'TBD'}.`,
    emailSubject: `New Instant Booking: ${title}`,
    emailText: `New instant marketplace booking.\n\nTitle: ${title}\nCustomer: ${customerName}\nPhone: ${customerPhone}\n${customerEmail ? `Email: ${customerEmail}\n` : ''}${address ? `Address: ${address}\n` : ''}Scheduled: ${scheduledAt ? scheduledAt.toISOString() : 'TBD'}\n\n— Sent from ServiceOS`,
    emailHtml: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px"><h2 style="color:#0f172a">New Instant Booking</h2><p>A marketplace customer just booked you instantly.</p><table style="width:100%;border-collapse:collapse;font-size:14px"><tr><td style="padding:8px;background:#f9fafb;font-weight:600">Title</td><td style="padding:8px">${title}</td></tr><tr><td style="padding:8px;background:#f9fafb;font-weight:600">Customer</td><td style="padding:8px">${customerName}</td></tr><tr><td style="padding:8px;background:#f9fafb;font-weight:600">Phone</td><td style="padding:8px">${customerPhone}</td></tr>${customerEmail ? `<tr><td style="padding:8px;background:#f9fafb;font-weight:600">Email</td><td style="padding:8px">${customerEmail}</td></tr>` : ''}${address ? `<tr><td style="padding:8px;background:#f9fafb;font-weight:600">Address</td><td style="padding:8px">${address}</td></tr>` : ''}</table></div>`,
    pushTitle: 'New Instant Booking',
    pushBody: `${customerName} booked ${serviceName || 'a service'} — ${scheduledAt ? scheduledAt.toLocaleString() : 'TBD'}`,
  }).catch((err) => {
    log.warn({ err }, 'marketplace/book/instant: provider notification failed');
  });

  log.info(
    {
      bookingId: (booking as { id: string }).id,
      jobId: job ? (job as { id: string }).id : null,
      transactionId,
      providerTenantId: provider.id,
      hasPayment: !!paymentIntent,
    },
    'marketplace/book/instant: completed',
  );

  return NextResponse.json(
    {
      booking,
      job,
      paymentIntent,
    },
    { status: 201 },
  );
}
